# test client
# database session override
# sample clinic creation
# sample patient creation
"""
Shared pytest fixtures for API tests.

This test setup ensures automated tests use the separate Neon test database
instead of the normal application database.
"""

import os
import sys

from pathlib import Path
# Make project root importable so `from app.main import app` works in pytest.
PROJECT_ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(PROJECT_ROOT))

from collections.abc import AsyncGenerator
import pytest
from dotenv import load_dotenv
from httpx import ASGITransport, AsyncClient
from sqlalchemy.ext.asyncio import AsyncSession, async_sessionmaker, create_async_engine
import uuid
from uuid import uuid4
import pytest_asyncio
from sqlalchemy import select
from app.modules.auth.security import hash_password
from app.modules.clinics.models import Clinic
from app.modules.users.models import Role, User

load_dotenv()

from app.main import app
from app.db.session import get_db
from sqlalchemy.pool import NullPool

TEST_DATABASE_URL = os.getenv("TEST_DATABASE_URL")

if not TEST_DATABASE_URL:
    raise RuntimeError(
        "TEST_DATABASE_URL is missing. Add it to your .env file before running tests."
    )


test_engine = create_async_engine(
    TEST_DATABASE_URL,
    echo=False,
    pool_pre_ping=True,
    poolclass=NullPool
)

TestSessionLocal = async_sessionmaker(
    bind=test_engine,
    expire_on_commit=False,
    autoflush=False,
    autocommit=False,
)


async def override_get_db_session() -> AsyncGenerator[AsyncSession, None]:
    """
    Override app DB dependency so tests use Neon ai_testing database.
    """
    async with TestSessionLocal() as session:
        yield session


@pytest.fixture(scope="session", autouse=True)
def override_database_dependency():
    """
    Apply database dependency override for all API tests.
    """
    app.dependency_overrides[get_db] = override_get_db_session

    yield

    app.dependency_overrides.clear()

@pytest.fixture
async def async_client() -> AsyncGenerator[AsyncClient, None]:
    """
    Async FastAPI test client.

    This calls the FastAPI app in memory without starting uvicorn.
    """
    transport = ASGITransport(app=app)

    async with AsyncClient(
        transport=transport,
        base_url="http://test",
    ) as client:
        yield client

@pytest.fixture(scope="session", autouse=True)
async def dispose_test_engine():
    """
    Dispose test engine after all tests finish.

    This prevents asyncpg connections from leaking after pytest closes.
    """
    yield
    await test_engine.dispose()

@pytest_asyncio.fixture
async def demo_clinic():
    """
    Ensure Demo Clinic exists in the test database.
    """
    async with TestSessionLocal() as session:
        result = await session.execute(
            select(Clinic).where(Clinic.name == "Demo Clinic")
        )
        clinic = result.scalar_one_or_none()

        if clinic is None:
            clinic = Clinic(
                name="Demo Clinic",
                subscription_status="active",
            )
            session.add(clinic)
            await session.commit()
            await session.refresh(clinic)

        return clinic

@pytest_asyncio.fixture
async def auth_roles():
    """
    Ensure default RBAC roles exist in the test database.
    """
    role_names = ["clinic_admin", "doctor", "assistant"]
    roles = {}

    async with TestSessionLocal() as session:
        for role_name in role_names:
            result = await session.execute(
                select(Role).where(Role.name == role_name)
            )
            role = result.scalar_one_or_none()

            if role is None:
                role = Role(
                    name=role_name,
                    description=f"{role_name} role",
                )
                session.add(role)
                await session.flush()

            roles[role_name] = role

        # Ensure user-management permissions exist and are assigned to clinic_admin
        from app.modules.users.models import Permission, RolePermission

        USER_MANAGEMENT_PERMISSIONS = [
            "user:create",
            "user:list",
            "user:read",
            "user:update",
            "user:deactivate",
            "user:activate",
            "user:reset_password",
            "user:assign_roles",
        ]

        # Create permissions if they don't exist and link to clinic_admin
        for code in USER_MANAGEMENT_PERMISSIONS:
            result = await session.execute(select(Permission).where(Permission.code == code))
            perm = result.scalar_one_or_none()
            if perm is None:
                perm = Permission(code=code, description=code)
                session.add(perm)
                await session.flush()

            # assign permission to clinic_admin role if not already assigned
            clinic_admin = roles.get("clinic_admin")
            if clinic_admin is not None:
                # check existing assignment
                result = await session.execute(
                    select(RolePermission).where(
                        (RolePermission.role_id == clinic_admin.id)
                        & (RolePermission.permission_id == perm.id)
                    )
                )
                rp = result.scalar_one_or_none()
                if rp is None:
                    rp = RolePermission(role_id=clinic_admin.id, permission_id=perm.id)
                    session.add(rp)

        await session.commit()

        return roles

async def create_test_user(
    *,
    clinic,
    role,
    email_prefix: str,
    password: str,
) -> str:
    """
    Create a unique test user and return the email.
    """
    email = f"{email_prefix}.{uuid4().hex[:8]}@example.com"

    async with TestSessionLocal() as session:
        user = User(
            clinic_id=clinic.id,
            role_id=role.id,
            full_name=f"{email_prefix.title()} Test User",
            email=email,
            phone=None,
            password_hash=hash_password(password),
            is_active=True,
        )
        user.roles.append(role)
        session.add(user)
        await session.commit()

    return email

@pytest_asyncio.fixture
async def clinic_admin_credentials(demo_clinic, auth_roles):
    email = await create_test_user(
        clinic=demo_clinic,
        role=auth_roles["clinic_admin"],
        email_prefix="clinic.admin",
        password="Admin1234",
    )
    return {"email": email, "password": "Admin1234"}

@pytest_asyncio.fixture
async def doctor_credentials(demo_clinic, auth_roles):
    email = await create_test_user(
        clinic=demo_clinic,
        role=auth_roles["doctor"],
        email_prefix="doctor",
        password="Doctor1234",
    )
    return {"email": email, "password": "Doctor1234"}

@pytest_asyncio.fixture
async def assistant_credentials(demo_clinic, auth_roles):
    email = await create_test_user(
        clinic=demo_clinic,
        role=auth_roles["assistant"],
        email_prefix="assistant",
        password="Assistant1234",
    )
    return {"email": email, "password": "Assistant1234"}

async def login_and_get_token(async_client, credentials: dict) -> str:
    """
    Login test user and return access token.
    """
    response = await async_client.post(
        "/auth/login",
        json=credentials,
    )

    assert response.status_code == 200

    return response.json()["token"]["access_token"]
        
@pytest_asyncio.fixture
async def apollo_clinic():
    """
    Ensure Apollo Clinic exists in the test database.
    """
    async with TestSessionLocal() as session:
        result = await session.execute(
            select(Clinic).where(Clinic.name == "Apollo Clinic")
        )
        clinic = result.scalar_one_or_none()

        if clinic is None:
            clinic = Clinic(
                name="Apollo Clinic",
            )
            session.add(clinic)
            await session.commit()
            await session.refresh(clinic)

        return clinic

@pytest_asyncio.fixture
async def apollo_assistant_credentials(apollo_clinic, auth_roles):
    email = await create_test_user(
        clinic=apollo_clinic,
        role=auth_roles["assistant"],
        email_prefix="apollo.assistant",
        password="Assistant1234",
    )
    return {"email": email, "password": "Assistant1234"}

async def created_patient(async_client, assistant_credentials):
    """
    Create a test patient and return the patient data.
    """
    assistant_token = await login_and_get_token(async_client, assistant_credentials)
    phone_number = "+91"+ str(uuid.uuid4().int)[:10]
    patient_payload ={
        "first_name": "Test",
        "last_name": "Patient",
        "date_of_birth": "1989-05-28",
        "gender": "Male",
        "phone_number": phone_number,
        "email": f"patient_{uuid4().hex[:8]}@example.com",
        "address_line_1": "Bhopal",
        "address_line_2": "MP",
        "city": "Bhopal",
        "state": "MP",
        "postal_code": "763003",
        "country": "India",
        "emergency_contact_name": "Test Patient Emergency",
        "emergency_contact_phone": "+918178765645"
        }
    
    patient_response = await async_client.post(
        "/patients",
        headers={"Authorization": f"Bearer {assistant_token}"},
        json=patient_payload
    )

    assert patient_response.status_code == 201

    patient_body = patient_response.json()
    patient_uid = patient_body["patient_uid"]

    return patient_body