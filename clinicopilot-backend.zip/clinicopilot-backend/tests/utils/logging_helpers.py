import logging

logger = logging.getLogger("test_logger")


def log_step(message: str, *args):
    logger.info("ℹ️ " + message, *args)


def log_pass(message: str, *args):
    logger.info("✅ " + message, *args)


def log_warn(message: str, *args):
    logger.warning("⚠️ " + message, *args)


def log_fail(message: str, *args):
    logger.error("❌ " + message, *args)


def log_debug(message: str, *args):
    logger.debug("🔍 " + message, *args)