import pytest
from tests.conftest import login_and_get_token, created_patient
from tests.utils.logging_helpers import (
    log_step,
    log_pass,
    log_warn,
    log_fail,
    log_debug,
)

pytestmark = pytest.mark.asyncio


async def test_doctor_can_search_patient(
    async_client,
    doctor_credentials,
    assistant_credentials,
):
    log_step("Starting test: Doctor can search patient by uid")

    log_step("Creating patient")
    patient_data = await created_patient(async_client, assistant_credentials)
    log_debug("Created patient data: %s", patient_data)

    assert patient_data is not None, "❌ created_patient returned None"
    assert "patient_uid" in patient_data, f"❌ patient_uid missing in patient_data: {patient_data}"
    assert "id" in patient_data, f"❌ id missing in patient_data: {patient_data}"
    log_pass("Patient created successfully")

    patient_uid = patient_data["patient_uid"]

    intake_payload = {
        "patient_uid": patient_uid,
        "chief_complaint": "Fever and sore throat",
        "symptoms": "Fever, cough, sore throat and fatigue",
        "symptom_duration": "3 days",
        "symptom_onset_date": "2026-05-27",
        "symptom_severity": "moderate",
        "pain_score": 6,
        "current_medications": "Paracetamol 500mg twice daily",
        "allergies": "Penicillin",
        "past_medical_history": "Asthma",
        "surgical_history": "Appendectomy in 2018",
        "family_history": "Father has diabetes",
        "social_history": "Non-smoker, occasional alcohol use",
        "vitals_json": {
            "temperature_f": 101.2,
            "blood_pressure": "120/80",
            "pulse": 88,
            "spo2": 98,
            "height_cm": 172,
            "weight_kg": 70,
        },
        "additional_notes": "Patient reports weakness since morning.",
        "consent_to_treatment": True,
        "consent_to_ai_review": True,
        "status": "submitted",
    }

    log_step("Logging in assistant user")
    assistant_token = await login_and_get_token(async_client, assistant_credentials)
    assert assistant_token, "❌ Assistant token is empty"
    log_pass("Assistant token acquired")

    log_step("Submitting intake")
    intake_response = await async_client.post(
        "/intakes",
        headers={"Authorization": f"Bearer {assistant_token}"},
        json=intake_payload,
    )
    log_debug("Intake response status=%s body=%s", intake_response.status_code, intake_response.text)

    assert intake_response.status_code == 201, (
        f"❌ Expected 201, got {intake_response.status_code}. Response: {intake_response.text}"
    )
    log_pass("Intake created successfully")

    intake_body = intake_response.json()
    assert intake_body["patient_id"] == patient_data["id"], (
        f"❌ Expected patient_id {patient_data['id']}, got {intake_body.get('patient_id')}"
    )
    assert intake_body["status"] == "submitted", (
        f"❌ Expected status 'submitted', got {intake_body.get('status')}"
    )
    log_pass("Intake validation passed")

    log_step("Logging in doctor user")
    doctor_token = await login_and_get_token(async_client, doctor_credentials)
    assert doctor_token, "❌ Doctor token is empty"
    log_pass("Doctor token acquired")

    log_step("Searching patient by uid=%s", patient_uid)
    response = await async_client.get(
        f"/patients/search?query={patient_uid}",
        headers={"Authorization": f"Bearer {doctor_token}"},
    )
    log_debug("Search response status=%s body=%s", response.status_code, response.text)

    assert response.status_code == 200, (
        f"❌ Expected 200, got {response.status_code}. Response: {response.text}"
    )

    data = response.json()
    assert isinstance(data, list), f"❌ Expected list response, got {type(data)}"
    assert len(data) >= 1, f"❌ Expected at least 1 result, got {len(data)}"
    assert data[0]["patient_uid"] == patient_uid, (
        f"❌ Expected patient_uid={patient_uid}, got {data[0].get('patient_uid')}"
    )
    log_pass("Patient search using patient uid validation passed")

    log_step("Starting test: Doctor can search patient by first name")

    log_step("Searching patient by first name=%s", patient_data["first_name"])
    response = await async_client.get(
        f"/patients/search?query={patient_data['first_name']}",
        headers={"Authorization": f"Bearer {doctor_token}"},
    )
    log_debug("Search response status=%s body=%s", response.status_code, response.text)

    assert response.status_code == 200, (
        f"❌ Expected 200, got {response.status_code}. Response: {response.text}"
    )

    data = response.json()
    assert isinstance(data, list), f"❌ Expected list response, got {type(data)}"
    assert len(data) >= 1, f"❌ Expected at least 1 result, got {len(data)}"
    assert data[0]["first_name"] == patient_data["first_name"], (
        f"❌ Expected first_name={patient_data['first_name']}, got {data[0].get('first_name')}"
    )
    log_pass("Patient search using patient first name validation passed")

    log_step("Starting test: Doctor can search patient by phone number")

    log_step("Searching patient by phone number=%s", patient_data["phone_number"])
    response = await async_client.get(
        f"/patients/search?query={patient_data['phone_number']}",
        headers={"Authorization": f"Bearer {doctor_token}"},
    )
    log_debug("Search response status=%s body=%s", response.status_code, response.text)

    assert response.status_code == 200, (
        f"❌ Expected 200, got {response.status_code}. Response: {response.text}"
    )

    data = response.json()
    assert isinstance(data, list), f"❌ Expected list response, got {type(data)}"
    assert len(data) >= 1, f"❌ Expected at least 1 result, got {len(data)}"
    assert data[0]["phone_number"] == patient_data["phone_number"], (
        f"❌ Expected phone_number={patient_data['phone_number']}, got {data[0].get('phone_number')}"
    )
    log_pass("Patient search using patient phone number validation passed")

    log_pass("Test completed successfully")