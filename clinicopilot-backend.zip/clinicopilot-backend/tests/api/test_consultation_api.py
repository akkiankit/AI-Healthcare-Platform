# tests/api/test_consultation_api.py

"""
API tests for Feature 03 - Consultation Workflow.

These tests validate the complete workflow:

Patient Registration
    ↓
Patient Intake Submission
    ↓
Consultation Creation
    ↓
Consultation Completion
"""

import pytest

import pytest
from uuid import UUID
from uuid import uuid4
from tests.conftest import login_and_get_token


def unique_patient_payload(
    *,
    first_name: str,
    last_name: str,
    gender: str = "male",
) -> dict:
    """
    Create unique patient payload for repeatable API tests.

    Why:
    - Test database persists between pytest runs.
    - Patients table has unique constraints on:
        clinic_id + email
        clinic_id + phone_number
    - Using random values prevents duplicate-record failures.
    """

    unique_value = uuid4().hex[:8]

    return {
        "first_name": first_name,
        "last_name": last_name,
        "date_of_birth": "1995-01-01",
        "gender": gender,
        "phone_number": f"9{unique_value}",
        "email": f"{first_name.lower()}.{last_name.lower()}.{unique_value}@example.com",
    }


@pytest.mark.asyncio
async def test_create_consultation_returns_201(async_client, assistant_credentials, doctor_credentials):
    """
    Create patient, submit intake, then create consultation.
    """
    assistant_token = await login_and_get_token(async_client, assistant_credentials)
    doctor_token = await login_and_get_token(async_client, doctor_credentials)

    patient_response = await async_client.post(
        "/patients",
        headers={"Authorization": f"Bearer {assistant_token}"},
        json=unique_patient_payload(
            first_name="John",
            last_name="Consult",
            gender="male"
        )
    )

    assert patient_response.status_code == 201
    patient_uid = patient_response.json()["patient_uid"]

    intake_response = await async_client.post(
        "/intakes",
        headers={"Authorization": f"Bearer {assistant_token}"},
        json={
            "patient_uid": patient_uid,
            "chief_complaint": "Fever and cough",
            "symptoms": "Fever, cough, sore throat",
            "symptom_severity": "moderate",
            "pain_score": 4,
            "consent_to_treatment": True,
            "consent_to_ai_review": True,
            "status": "submitted",
        },
    )

    assert intake_response.status_code == 201
    intake_id = intake_response.json()["id"]

    consultation_response = await async_client.post(
        "/consultations",
        headers={"Authorization": f"Bearer {doctor_token}"},
        json={
            "patient_uid": patient_uid,
        },
    )

    print(f"Consultation API response: {consultation_response.status_code} - {consultation_response.json()} ")
    assert consultation_response.status_code == 201

    data = consultation_response.json()

    assert data["consultation_number"].startswith("CON-")
    assert data["status"] == "in_progress"
    assert data["patient_id"] == intake_response.json()["patient_id"]
    assert data["intake_id"] == intake_id

    updated_intake_response = await async_client.get(
        f"/intakes/{intake_id}",
        headers={"Authorization": f"Bearer {assistant_token}"}
    )

    assert updated_intake_response.status_code == 200
    assert updated_intake_response.json()["status"] == "consultation_in_progress"


@pytest.mark.asyncio
async def test_create_consultation_without_submitted_intake_returns_404(async_client, assistant_credentials, doctor_credentials):
    """
    Consultation cannot be created if patient has no submitted intake.
    """
    assistant_token = await login_and_get_token(async_client, assistant_credentials)
    doctor_token = await login_and_get_token(async_client, doctor_credentials)

    patient_response = await async_client.post(
        "/patients",
        headers={"Authorization": f"Bearer {assistant_token}"},
        json=unique_patient_payload(
            first_name="No",
            last_name="Intake",
            gender="female"
        )
    )

    assert patient_response.status_code == 201
    patient_uid = patient_response.json()["patient_uid"]

    consultation_response = await async_client.post(
        "/consultations",
        headers={"Authorization": f"Bearer {doctor_token}"},
        json={
            "patient_uid": patient_uid,
        },
    )

    assert consultation_response.status_code == 404
    assert consultation_response.json()["detail"] == (
        "No submitted intake found for this patient"
    )


@pytest.mark.asyncio
async def test_duplicate_consultation_for_same_intake_is_not_allowed(async_client, assistant_credentials, doctor_credentials):
    """
    Once consultation starts, the submitted intake moves to consultation_in_progress.

    A second consultation request for same patient should not find another submitted intake.
    """
    assistant_token = await login_and_get_token(async_client, assistant_credentials)
    doctor_token = await login_and_get_token(async_client, doctor_credentials)

    patient_response = await async_client.post(
        "/patients",
        headers={"Authorization": f"Bearer {assistant_token}"},
        json=unique_patient_payload(
            first_name="Duplicate",
            last_name="Consult",
            gender="male"
        )
    )

    assert patient_response.status_code == 201
    patient_uid = patient_response.json()["patient_uid"]

    intake_response = await async_client.post(
        "/intakes",
        headers={"Authorization": f"Bearer {assistant_token}"},
        json={
            "patient_uid": patient_uid,
            "chief_complaint": "Headache",
            "symptoms": "Severe headache since morning",
            "symptom_severity": "severe",
            "pain_score": 8,
            "consent_to_treatment": True,
            "consent_to_ai_review": True,
            "status": "submitted",
        },
    )

    assert intake_response.status_code == 201

    first_consultation_response = await async_client.post(
        "/consultations",
        headers={"Authorization": f"Bearer {doctor_token}"},
        json={"patient_uid": patient_uid},
    )

    assert first_consultation_response.status_code == 201

    second_consultation_response = await async_client.post(
        "/consultations",
        headers={"Authorization": f"Bearer {doctor_token}"},
        json={"patient_uid": patient_uid},
    )

    assert second_consultation_response.status_code == 404
    assert second_consultation_response.json()["detail"] == (
        "No submitted intake found for this patient"
    )


@pytest.mark.asyncio
async def test_complete_consultation_moves_intake_to_consulted(async_client, assistant_credentials, doctor_credentials):
    """
    Completing consultation should move linked intake to consulted.
    """
    assistant_token = await login_and_get_token(async_client, assistant_credentials)
    doctor_token = await login_and_get_token(async_client, doctor_credentials)

    patient_response = await async_client.post(
        "/patients",
        headers={"Authorization": f"Bearer {assistant_token}"},
        json=unique_patient_payload(
            first_name="Complete",
            last_name="Consult",
            gender="female"
        )
    )

    assert patient_response.status_code == 201
    patient_uid = patient_response.json()["patient_uid"]

    intake_response = await async_client.post(
        "/intakes",
        headers={"Authorization": f"Bearer {assistant_token}"},
        json={
            "patient_uid": patient_uid,
            "chief_complaint": "Back pain",
            "symptoms": "Lower back pain",
            "symptom_severity": "moderate",
            "pain_score": 6,
            "consent_to_treatment": True,
            "consent_to_ai_review": True,
            "status": "submitted",
        },
    )

    assert intake_response.status_code == 201
    intake_id = intake_response.json()["id"]

    consultation_response = await async_client.post(
        "/consultations",
        headers={"Authorization": f"Bearer {doctor_token}"},
        json={"patient_uid": patient_uid},
    )

    assert consultation_response.status_code == 201
    consultation_number = consultation_response.json()["consultation_number"]

    update_response = await async_client.patch(
        f"/consultations/{consultation_number}",
        headers={"Authorization": f"Bearer {doctor_token}"},
        json={
            "clinical_notes": "Patient examined by doctor.",
            "diagnosis_notes": "Likely muscular strain.",
            "status": "completed",
        },
    )

    assert update_response.status_code == 200
    assert update_response.json()["status"] == "completed"

    updated_intake_response = await async_client.get(
        f"/intakes/{intake_id}",
        headers={"Authorization": f"Bearer {assistant_token}"}
    )

    assert updated_intake_response.status_code == 200
    assert updated_intake_response.json()["status"] == "consulted"

# to run this test file: pytest tests/api/test_consultation_api.py -v