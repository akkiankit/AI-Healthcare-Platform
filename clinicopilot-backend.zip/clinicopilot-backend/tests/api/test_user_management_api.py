import pytest
from uuid import uuid4

from tests.conftest import login_and_get_token


@pytest.mark.asyncio
async def test_clinic_admin_can_create_doctor_user(async_client, clinic_admin_credentials):
    token = await login_and_get_token(async_client, clinic_admin_credentials)

    test_email = f"new.doctor.{uuid4().hex[:8]}@example.com"
    response = await async_client.post(
        "/users",
        headers={"Authorization": f"Bearer {token}"},
        json={
            "email": test_email,
            "full_name": "New Doctor",
            "roles": ["doctor"],
            "password": "Doctor1234",
        },
    )

    assert response.status_code == 201
    payload = response.json()
    assert payload["email"] == test_email
    assert "doctor" in payload["roles"]
    assert payload["is_active"] is True
    assert payload["clinic_id"] is not None


@pytest.mark.asyncio
async def test_clinic_admin_can_list_users(async_client, clinic_admin_credentials):
    token = await login_and_get_token(async_client, clinic_admin_credentials)

    first_email = f"list.doctor.{uuid4().hex[:8]}@example.com"
    first_response = await async_client.post(
        "/users",
        headers={"Authorization": f"Bearer {token}"},
        json={
            "email": first_email,
            "full_name": "List Doctor",
            "roles": ["doctor"],
            "password": "Doctor1234",
        },
    )
    assert first_response.status_code == 201
    first_user = first_response.json()

    second_email = f"list.assistant.{uuid4().hex[:8]}@example.com"
    second_response = await async_client.post(
        "/users",
        headers={"Authorization": f"Bearer {token}"},
        json={
            "email": second_email,
            "full_name": "List Assistant",
            "roles": ["assistant"],
            "password": "Assistant1234",
        },
    )
    assert second_response.status_code == 201
    second_user = second_response.json()

    list_response = await async_client.get(
        "/users",
        headers={"Authorization": f"Bearer {token}"},
    )

    assert list_response.status_code == 200
    payload = list_response.json()
    user_ids = {user["id"] for user in payload["users"]}
    assert first_user["id"] in user_ids
    assert second_user["id"] in user_ids


@pytest.mark.asyncio
async def test_doctor_cannot_create_user(async_client, doctor_credentials):
    token = await login_and_get_token(async_client, doctor_credentials)

    response = await async_client.post(
        "/users",
        headers={"Authorization": f"Bearer {token}"},
        json={
            "email": f"blocked.user.{uuid4().hex[:8]}@example.com",
            "full_name": "Blocked User",
            "roles": ["assistant"],
            "password": "Assistant1234",
        },
    )

    assert response.status_code == 403


@pytest.mark.asyncio
async def test_clinic_admin_can_reset_user_password(async_client, clinic_admin_credentials):
    admin_token = await login_and_get_token(async_client, clinic_admin_credentials)

    create_email = f"reset.doctor.{uuid4().hex[:8]}@example.com"
    create_response = await async_client.post(
        "/users",
        headers={"Authorization": f"Bearer {admin_token}"},
        json={
            "email": create_email,
            "full_name": "Reset Doctor",
            "roles": ["doctor"],
            "password": "Doctor1234",
        },
    )
    assert create_response.status_code == 201
    user_id = create_response.json()["id"]

    reset_response = await async_client.patch(
        f"/users/{user_id}/reset-password",
        headers={"Authorization": f"Bearer {admin_token}"},
        json={"password": "NewDoctor1234"},
    )

    assert reset_response.status_code == 200
    assert reset_response.json()["id"] == user_id

    login_response = await async_client.post(
        "/auth/login",
        json={
            "email": create_email,
            "password": "NewDoctor1234",
        },
    )

    assert login_response.status_code == 200
    assert login_response.json()["user"]["email"] == create_email
