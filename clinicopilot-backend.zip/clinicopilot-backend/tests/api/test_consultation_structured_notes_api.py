
import pytest

import pytest
from uuid import UUID
from uuid import uuid4
from tests.conftest import login_and_get_token

async def test_doctor_can_complete_consultation_with_structured_notes(
    async_client,
    doctor_token,
    created_consultation,
):
    consultation_number = created_consultation["consultation_number"]

    payload = {
        "clinical_notes": "Final clinical note.",
        "diagnosis_notes": "Final diagnosis note.",
        "examination_notes": "Chest clear. No respiratory distress.",
        "assessment": "Improving viral URTI.",
        "treatment_plan": "Continue symptomatic management.",
        "follow_up_instructions": "Return if fever persists beyond 5 days.",
        "consultation_summary": "Consultation completed. Patient stable.",
    }

    response = await async_client.patch(
        f"/api/v1/consultations/{consultation_number}/complete",
        json=payload,
        headers={"Authorization": f"Bearer {doctor_token}"},
    )

    assert response.status_code == 200, response.text

    data = response.json()

    assert data["status"] == "completed"
    assert data["assessment"] == payload["assessment"]
    assert data["consultation_summary"] == payload["consultation_summary"]




async def test_doctor_can_complete_consultation_with_structured_notes(
    async_client,
    doctor_token,
    created_consultation,
):
    consultation_number = created_consultation["consultation_number"]

    payload = {
        "clinical_notes": "Final clinical note.",
        "diagnosis_notes": "Final diagnosis note.",
        "examination_notes": "Chest clear. No respiratory distress.",
        "assessment": "Improving viral URTI.",
        "treatment_plan": "Continue symptomatic management.",
        "follow_up_instructions": "Return if fever persists beyond 5 days.",
        "consultation_summary": "Consultation completed. Patient stable.",
    }

    response = await async_client.patch(
        f"/api/v1/consultations/{consultation_number}/complete",
        json=payload,
        headers={"Authorization": f"Bearer {doctor_token}"},
    )

    assert response.status_code == 200, response.text

    data = response.json()

    assert data["status"] == "completed"


    response = await async_client.get(
        f"/api/v1/consultations/dashboard/patient/{patient_uid}",
        headers={"Authorization": f"Bearer {doctor_token}"},
    )

    assert response.status_code == 200
    data = response.json()

    assert data["active_consultation"]["assessment"] == payload["assessment"]
    assert data["active_consultation"]["consultation_summary"] == payload["consultation_summary"]


    assert data["assessment"] == payload["assessment"]
    assert data["consultation_summary"] == payload["consultation_summary"]