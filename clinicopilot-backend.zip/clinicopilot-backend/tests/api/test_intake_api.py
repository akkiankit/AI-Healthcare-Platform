"""
API tests for patient intake endpoints.
"""

import pytest
import uuid
from tests.conftest import login_and_get_token

async def create_test_patient_and_intake(async_client, assistant_credentials=None):
    """Create a test patient and intake for testing."""
    if assistant_credentials is None:
        # Default: use test credentials if not provided
        raise ValueError("assistant_credentials required")
    
    assistant_token = await login_and_get_token(async_client, assistant_credentials)
    unique_digits = str(uuid.uuid4().int)[:10]
    unique_email = uuid.uuid4().hex[:8]

    patient_payload = {
        "first_name": "Test",
        "last_name": "Patient",
        "date_of_birth": "1992-05-14",
        "gender": "male",
        "phone_number": f"+91{unique_digits}",
        "email": f"test.patient.{unique_email}@example.com",
        "address_line_1": "123 Test Street",
        "address_line_2": "Near Test Metro",
        "city": "Bengaluru",
        "state": "Karnataka",
        "postal_code": "560001",
        "country": "India",
        "emergency_contact_name": "Test Contact",
        "emergency_contact_phone": f"+918{unique_digits[:9]}",
    }

    patient_response = await async_client.post(
        "/patients",
        headers={"Authorization": f"Bearer {assistant_token}"},
        json=patient_payload
    )
    assert patient_response.status_code == 201

    patient_body = patient_response.json()

    intake_payload = {
        "patient_uid": patient_body["patient_uid"],
        "chief_complaint": "Fever and sore throat",
        "symptoms": "Fever, cough and fatigue",
        "symptom_duration": "3 days",
        "symptom_severity": "moderate",
        "pain_score": 6,
        "consent_to_treatment": True,
        "consent_to_ai_review": True,
        "status": "submitted",
    }

    intake_response = await async_client.post(
        "/intakes",
        headers={"Authorization": f"Bearer {assistant_token}"},
        json=intake_payload
    )
    assert intake_response.status_code == 201

    return patient_body, intake_response.json()

@pytest.mark.asyncio
async def test_create_intake_with_invalid_patient_uid_returns_404(async_client, assistant_credentials):
    """
    Creating intake with unknown patient_uid should return 404.
    """
    assistant_token = await login_and_get_token(async_client, assistant_credentials)
    payload = {
        "patient_uid": "PAT-999999",
        "chief_complaint": "Fever and sore throat",
        "symptoms": "Fever, cough, and fatigue",
        "symptom_duration": "3 days",
        "symptom_severity": "moderate",
        "pain_score": 6,
        "consent_to_treatment": True,
        "consent_to_ai_review": True,
        "status": "submitted",
    }

    response = await async_client.post(
        "/intakes",
        headers={"Authorization": f"Bearer {assistant_token}"},
        json=payload
    )

    assert response.status_code == 404
    assert response.json()["detail"] == "Patient not found"

@pytest.mark.asyncio
async def test_create_intake_with_invalid_pain_score_returns_422(async_client, assistant_credentials):
    assistant_token = await login_and_get_token(async_client, assistant_credentials)
    payload = {
        "patient_uid": "PAT-999999",
        "chief_complaint": "Fever and sore throat",
        "pain_score": 15,
        "consent_to_treatment": True,
        "consent_to_ai_review": True,
        "status": "submitted",
    }

    response = await async_client.post(
        "/intakes",
        headers={"Authorization": f"Bearer {assistant_token}"},
        json=payload
    )

    assert response.status_code == 422
    
@pytest.mark.asyncio
async def test_create_submitted_intake_without_consent_returns_422(async_client, assistant_credentials):
    assistant_token = await login_and_get_token(async_client, assistant_credentials)
    payload = {
        "patient_uid": "PAT-999999",
        "chief_complaint": "Fever and sore throat",
        "consent_to_treatment": False,
        "consent_to_ai_review": False,
        "status": "submitted",
    }

    response = await async_client.post(
        "/intakes",
        headers={"Authorization": f"Bearer {assistant_token}"},
        json=payload
    )

    assert response.status_code == 422

@pytest.mark.asyncio
async def test_create_intake_with_valid_patient_uid_returns_201(async_client, assistant_credentials):
    """
    Create a patient first, then create intake using returned patient_uid.

    This validates the complete flow:
    patient registration -> patient_uid -> intake submission.
    """
    assistant_token = await login_and_get_token(async_client, assistant_credentials)
    unique_digits = str(uuid.uuid4().int)[:10]
    unique_email = uuid.uuid4().hex[:8]

    patient_payload = {
        "first_name": "Test",
        "last_name": "Patient",
        "date_of_birth": "1992-05-14",
        "gender": "male",
        "phone_number": f"+91{unique_digits}",
        "email": f"test.patient.{unique_email}@example.com",
        "emergency_contact_phone": f"+918{unique_digits[:9]}",
        "address_line_1": "123 Test Street",
        "address_line_2": "Near Test Metro",
        "city": "Bengaluru",
        "state": "Karnataka",
        "postal_code": "560001",
        "country": "India",
        "emergency_contact_name": "Test Contact",
    }

    patient_response = await async_client.post(
        "/patients",
        headers={"Authorization": f"Bearer {assistant_token}"},
        json=patient_payload
    )

    print(patient_response.text)
    assert patient_response.status_code == 201

    patient_body = patient_response.json()
    patient_uid = patient_body["patient_uid"]

    intake_payload = {
        "patient_uid": patient_uid,
        "chief_complaint": "Fever and sore throat",
        "symptoms": "Fever, cough, sore throat and fatigue",
        "symptom_duration": "3 days",
        "symptom_onset_date": "2026-05-27",
        "symptom_severity": "moderate",
        "pain_score": 6,
        "current_medications": "Paracetamol 500mg twice daily",
        "allergies": "Penicillin",
        "past_medical_history": "Asthma",
        "surgical_history": "Appendectomy in 2018",
        "family_history": "Father has diabetes",
        "social_history": "Non-smoker, occasional alcohol use",
        "vitals_json": {
            "temperature_f": 101.2,
            "blood_pressure": "120/80",
            "pulse": 88,
            "spo2": 98,
            "height_cm": 172,
            "weight_kg": 70,
        },
        "additional_notes": "Patient reports weakness since morning.",
        "consent_to_treatment": True,
        "consent_to_ai_review": True,
        "status": "submitted",
    }

    intake_response = await async_client.post(
        "/intakes",
        headers={"Authorization": f"Bearer {assistant_token}"},
        json=intake_payload,
    )

    assert intake_response.status_code == 201

    intake_body = intake_response.json()

    assert intake_body["patient_id"] == patient_body["id"]
    assert intake_body["chief_complaint"] == "Fever and sore throat"
    assert intake_body["status"] == "submitted"
    assert intake_body["pain_score"] == 6
    assert intake_body["submitted_at"] is not None


@pytest.mark.asyncio
async def test_list_intakes_returns_200(async_client, assistant_credentials):
    assistant_token = await login_and_get_token(async_client, assistant_credentials)
    await create_test_patient_and_intake(async_client, assistant_credentials)

    response = await async_client.get(
        "/intakes",
        headers={"Authorization": f"Bearer {assistant_token}"}
    )

    assert response.status_code == 200

    body = response.json()
    assert body["total"] >= 1
    assert isinstance(body["items"], list)
    
@pytest.mark.asyncio
async def test_get_intake_by_id_returns_200(async_client, assistant_credentials):
    assistant_token = await login_and_get_token(async_client, assistant_credentials)
    _, intake_body = await create_test_patient_and_intake(async_client, assistant_credentials)

    response = await async_client.get(
        f"/intakes/{intake_body['id']}",
        headers={"Authorization": f"Bearer {assistant_token}"}
    )

    assert response.status_code == 200
    assert response.json()["id"] == intake_body["id"]
    
    
@pytest.mark.asyncio
async def test_patch_intake_returns_200(async_client, assistant_credentials):
    assistant_token = await login_and_get_token(async_client, assistant_credentials)
    _, intake_body = await create_test_patient_and_intake(async_client, assistant_credentials)

    payload = {
        "pain_score": 8,
        "additional_notes": "Updated during automated test",
    }

    response = await async_client.patch(
        f"/intakes/{intake_body['id']}",
        headers={"Authorization": f"Bearer {assistant_token}"},
        json=payload,
    )

    assert response.status_code == 200

    body = response.json()
    assert body["pain_score"] == 8
    assert body["additional_notes"] == "Updated during automated test"


@pytest.mark.asyncio
async def test_delete_intake_soft_cancels_record(async_client, assistant_credentials):
    assistant_token = await login_and_get_token(async_client, assistant_credentials)
    _, intake_body = await create_test_patient_and_intake(async_client, assistant_credentials)

    response = await async_client.delete(
        f"/intakes/{intake_body['id']}",
        headers={"Authorization": f"Bearer {assistant_token}"}
    )

    assert response.status_code == 200
    assert response.json()["status"] == "cancelled"

@pytest.mark.asyncio
async def test_patch_cancelled_intake_returns_409(async_client, assistant_credentials):
    assistant_token = await login_and_get_token(async_client, assistant_credentials)
    _, intake_body = await create_test_patient_and_intake(async_client, assistant_credentials)

    cancel_response = await async_client.delete(
        f"/intakes/{intake_body['id']}",
        headers={"Authorization": f"Bearer {assistant_token}"}
    )
    assert cancel_response.status_code == 200

    patch_response = await async_client.patch(
        f"/intakes/{intake_body['id']}",
        headers={"Authorization": f"Bearer {assistant_token}"},
        json={"pain_score": 9},
    )

    assert patch_response.status_code == 409

@pytest.mark.asyncio
async def test_second_submitted_intake_for_same_patient_returns_409(async_client, assistant_credentials):
    assistant_token = await login_and_get_token(async_client, assistant_credentials)
    patient_body, _ = await create_test_patient_and_intake(async_client, assistant_credentials)

    second_intake_payload = {
        "patient_uid": patient_body["patient_uid"],
        "chief_complaint": "Headache and nausea",
        "symptoms": "Headache since morning",
        "symptom_duration": "1 day",
        "symptom_severity": "mild",
        "pain_score": 4,
        "consent_to_treatment": True,
        "consent_to_ai_review": True,
        "status": "submitted",
    }

    response = await async_client.post(
        "/intakes",
        headers={"Authorization": f"Bearer {assistant_token}"},
        json=second_intake_payload
    )

    assert response.status_code == 409
    assert response.json()["detail"] == "Patient already has an active submitted intake"

# pytest tests/api/test_intake_api.py -v

# test_create_intake_with_valid_patient_uid_returns_201
# test_clinic_admin_can_create_doctor_user
# test_clinic_admin_can_list_users
# test_clinic_admin_can_reset_user_password