import pytest
import uuid

from tests.conftest import login_and_get_token


@pytest.mark.asyncio
async def test_login_and_me_returns_authenticated_user(
    async_client,
    clinic_admin_credentials,
):
    token = await login_and_get_token(
        async_client,
        clinic_admin_credentials,
    )

    response = await async_client.get(
        "/auth/me",
        headers={"Authorization": f"Bearer {token}"},
    )

    assert response.status_code == 200
    assert response.json()["email"] == clinic_admin_credentials["email"]
    assert response.json()["role"] == "clinic_admin"
    assert "clinic_admin" in response.json()["roles"]

@pytest.mark.asyncio
async def test_doctor_cannot_register_patient(
    async_client,
    doctor_credentials,
):
    token = await login_and_get_token(
        async_client,
        doctor_credentials,
    )

    response = await async_client.post(
        "/patients",
        headers={"Authorization": f"Bearer {token}"},
        json={
            "first_name": "Blocked",
            "last_name": "Doctor",
            "date_of_birth": "1990-01-01",
            "gender": "male",
            "phone_number": "9991112222",
            "email": "blocked.doctor@example.com",
        },
    )

    assert response.status_code == 403


@pytest.mark.asyncio
async def test_assistant_cannot_create_consultation(
    async_client,
    assistant_credentials,
):
    token = await login_and_get_token(
        async_client,
        assistant_credentials,
    )

    response = await async_client.post(
        "/consultations",
        headers={"Authorization": f"Bearer {token}"},
        json={
            "patient_uid": "PAT-DOES-NOT-MATTER",
        },
    )

    assert response.status_code == 403

@pytest.mark.asyncio
async def test_demo_user_cannot_fetch_apollo_patient(
    async_client,
    assistant_credentials,
    apollo_assistant_credentials,
):
    apollo_token = await login_and_get_token(
        async_client,
        apollo_assistant_credentials,
    )

    apollo_patient_response = await async_client.post(
        "/patients",
        headers={"Authorization": f"Bearer {apollo_token}"},
        json={
            "first_name": "Apollo",
            "last_name": "Patient",
            "date_of_birth": "1990-01-01",
            "gender": "female",
            "phone_number": f"9888{uuid.uuid4().int % 10000000:07d}",
            "email": f"apollo.patient.{uuid.uuid4().hex}@example.com",
        },
    )

    print("Apollo patient creation response:", apollo_patient_response.status_code, apollo_patient_response.json())
    assert apollo_patient_response.status_code == 201
    apollo_patient_id = apollo_patient_response.json()["id"]

    demo_token = await login_and_get_token(async_client, assistant_credentials)

    forbidden_response = await async_client.get(
        f"/patients/{apollo_patient_id}",
        headers={"Authorization": f"Bearer {demo_token}"},
    )

    assert forbidden_response.status_code == 404
# pytest tests/api/test_auth_rbac_api.py -v