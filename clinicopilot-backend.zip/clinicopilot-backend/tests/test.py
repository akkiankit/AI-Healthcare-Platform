from app.modules.auth.security import hash_password
print(hash_password("Admin1234"))