import pytest
from unittest.mock import AsyncMock, Mock
from uuid import uuid4

from fastapi import HTTPException

from app.modules.patients.service import PatientService


pytestmark = pytest.mark.asyncio


async def test_search_patients_uses_current_user_clinic():
    db = Mock()

    service = PatientService(db)
    service.repository.search_patients = AsyncMock(return_value=[])

    current_user = Mock()
    current_user.clinic_id = uuid4()

    result = await service.search_patients(
        current_user=current_user,
        query="PAT",
        limit=20,
    )

    assert result == []

    service.repository.search_patients.assert_awaited_once_with(
        clinic_id=current_user.clinic_id,
        query="PAT",
        limit=20,
    )


async def test_search_patients_rejects_short_query():
    db = Mock()

    service = PatientService(db)

    current_user = Mock()
    current_user.clinic_id = uuid4()

    with pytest.raises(HTTPException) as exc_info:
        await service.search_patients(
            current_user=current_user,
            query="a",
            limit=20,
        )

    assert exc_info.value.status_code == 400