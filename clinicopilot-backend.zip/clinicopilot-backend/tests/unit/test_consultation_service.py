import uuid
import pytest
from unittest.mock import AsyncMock, MagicMock, patch
from fastapi import HTTPException, status

# Import the service to test
from app.modules.consultations.service import (
    ConsultationService,
    _generate_consultation_number,
    _ensure_consultation_can_be_modified,
    TERMINAL_STATUSES
)

# ------------------------------------------------------------------------
# Helper to create mocked repositories
# ------------------------------------------------------------------------
def create_mocked_repositories():
    db = AsyncMock()
    # Map attributes accessed by the service
    db.patient_uid = "PAT-000001"
    db.clinic_id = "CLINIC-123"

    # Mock repository classes
    class MockRepository:
        @staticmethod
        def get_by_patient_uid(patient_uid: str) -> MagicMock:
            patient = MagicMock()
            patient.id = uuid.uuid4()
            patient.clinic_id = db.clinic_id
            return patient

        @staticmethod
        def get_by_consultation_number(consultation_number: str) -> MagicMock:
            consult = MagicMock()
            consult.intake_id = uuid.uuid4()
            consult.status = "draft"
            return consult

        @staticmethod
        def list_by_patient_id(patient_id: uuid.UUID, clinic_id: str) -> list:
            return []
        @staticmethod
        def get_latest_submitted_by_patient_id(patient_id: uuid.UUID) -> MagicMock:
            intake = MagicMock()
            intake.chief_complaint = "Headache"
            intake.symptoms = "pain, nausea"
            intake.symptom_duration = "2 days"
            intake.symptom_severity = "moderate"
            return intake

        @staticmethod
        def create(**kwargs) -> MagicMock:
            consult = MagicMock(**kwargs)
            consult.id = uuid.uuid4()
            consult.consultation_number = kwargs.get('consultation_number')
            consult.clinic_id = kwargs.get('clinic_id')
            consult.patient_id = kwargs.get('patient_id')
            consult.intake_id = kwargs.get('intake_id')
            return consult

    return {
        "db": db,
        "patient_repository": MockRepository,
        "intake_repository": MockRepository,
        "consultation_repository": MockRepository,
    }

# Override dependencies during testing
@pytest.fixture(autouse=True, scope="module")
def override_dependencies():
    service_patcher = patch(
        "app.modules.consultations.service.ConsultationRepository",
        create_mocked_repositories()["patient_repository"]
    )
    service_repo_patcher = patch(
        "app.modules.consultations.service.ConsultationRepository",
        create_mocked_repositories()["consultation_repository"]
    )
    intake_repo_patcher = patch(
        "app.modules.consultations.service.ConsultationRepository",
        create_mocked_repositories()["intake_repository"]
    )
    mock_service_repo, mock_consult_repo, mock_intake_repo = (
        service_patcher.start(),
        service_repo_patcher.start(),
        intake_repo_patcher.start()
    )
    mock_service_repo.patient_uid = "CLINIC-123"
    mock_service_repo.clinic_id = "CLINIC-123"
    yield mock_service_repo, mock_service_repo, mock_intake_repo, mock_consult_repo
    mock_service_repo.stop()
    mock_service_repo.stop()
    mock_intake_repo.stop()
    mock_consult_repo.stop()

@pytest.fixture
def mock_db_session():
    db = AsyncMock()
    db.commit = AsyncMock(return_value=None)
    db.rollback = AsyncMock(return_value=None)
    db.flush = AsyncMock(return_value=None)
    return db

# ------------------------------------------------------------------------
# Test get_patient_dashboard (happy path)
# ------------------------------------------------------------------------
async def test_get_patient_dashboard_success(
    mock_db_session, mock_service_repo, mock_intake_repo, mock_consult_repo
):
    # -------------------------------
    # Service under test
    # -------------------------------
    service = ConsultationService(mock_db_session)

    # Override dependencies in the service
    service.patient_repository = mock_service_repo
    service.intake_repository = mock_intake_repo
    service.consultation_repository = mock_consult_repo

    # Mock user and patient data
    user_obj = MagicMock()
    user_obj.clinic_id = "CLINIC-123"
    doctor_role = MagicMock()
    doctor_role.name = "doctor"
    user_obj.roles = [doctor_role]

    patient_uid = "PAT-12345"
    
    # -------------------------------
    # Act
    # -------------------------------
    response = await service.get_patient_dashboard(
        patient_uid=patient_uid,
        current_user=user_obj,
    )

    # -------------------------------
    # Assert
    # -------------------------------
    mock_service_repo.get_by_patient_uid.assert_awaited_once_with("PAT-12345")
    mock_intake_repo.get_latest_submitted_by_patient_id.assert_awaited_once_with(
        uuid.UUID("PAT-12345")
    )

    # Response validation
    assert response.patient_profile.patient_uid == "PAT-12345"
    assert response.latest_intake.chief_complaint == "Headache"
    assert "Headache" in response.ai_summary  # Simple check

    mock_db_session.add.assert_awaited_once()  # Audit log
    mock_db_session.commit.assert_awaited_once()
    mock_db_session.refresh.assert_awaited_once()

# ------------------------------------------------------------------------
# Test get_patient_dashboard (patient not found)
# ------------------------------------------------------------------------
async def test_get_patient_dashboard_patient_not_found(
    mock_db_session, override_dependencies
):
    mock_service_repo.get_by_patient_uid.return_value = None

    with pytest.raises(HTTPException) as excinfo:
        await ConsultationService(mock_db_session).get_patient_dashboard(
            patient_uid="UNKNOWN",
            current_user=MagicMock(clinic_id="CLINIC-123")
        )
    exc = excinfo.value
    assert exc.status_code == status.HTTP_404_NOT_FOUND
    assert exc.detail == "Patient not found"
    mock_db_session.commit.assert_not_awaited()

# ------------------------------------------------------------------------
# Test create_consultation (duplicate intake)
# ------------------------------------------------------------------------
async def test_create_consultation_duplicate_intake(
    mock_db_session, mock_service_repo, mock_intake_repo, mock_consult_repo
):
    # Override service dependencies
    service = ConsultationService(mock_db_session)
    service.patient_repository = mock_service_repo
    service.intake_repository = mock_intake_repo
    service.consultation_repository = mock_consult_repo

    # Mock user and patient data
    user_obj = MagicMock()
    user_obj.clinic_id = "CLINIC-123"
    doctor_role = MagicMock()
    doctor_role.name = "doctor"
    user_obj.roles = [doctor_role]

    patient_uid = "PAT-12345"

    # Mock the request payload
    payload = MagicMock()
    payload.patient_uid = patient_uid

    # ---------------------------------
    # Simulate existing consultation
    # ---------------------------------
    mock_consult_repo.get_by_intake_id.return_value = MagicMock()

    with pytest.raises(HTTPException) as excinfo:
        await service.create_consultation(
            consultation_data=payload,
            current_user=user_obj,
        )
    exc = excinfo.value
    assert exc.status_code == status.HTTP_409_CONFLICT
    assert exc.detail == "Consultation already exists for this intake"
    mock_db_session.commit.assert_not_awaited()

# ------------------------------------------------------------------------
# Test create_consultation (success path)
# ------------------------------------------------------------------------
async def test_create_consultation_success_path(
    mock_db_session, mock_service_repo, mock_intake_repo, mock_consult_repo
):
    # Mock user and patient data
    user_obj = MagicMock()
    user_obj.clinic_id = "CLINIC-123"
    doctor_role = MagicMock()
    doctor_role.name = "doctor"
    user_obj.roles = [doctor_role]

    patient_uid = "PAT-12345"
    consultation_number = "CON-000001"

    # Mock the request
    payload = MagicMock(patient_uid=patient_uid)

    # Service under test
    service = ConsultationService(mock_db_session)
    service.patient_repository = mock_service_repo
    service.intake_repository = mock_intake_repo
    service.consultation_repository = mock_consult_repo

    # Assertions setup
    mock_service_repo.get_by_patient_uid.return_value = MagicMock(id=uuid.uuid4())
    mock_intake_repo.get_latest_submitted_by_patient_id.return_value = (
        MagicMock(
            chief_complaint="New Symptom",
            symptoms="new symptom",
            symptom_duration="1 day",
            symptom_severity="low",
        )
    )

    # Override _generate_consultation_number to return predictable value
    mock_consult_repo.create.return_value = MagicMock(
        consultation_number=consultation_number,
    )

    # Act
    result = await service.create_consultation(
        consultation_data=payload,
        current_user=user_obj,
    )

    # Assertions
    assert result.consultation_number == consultation_number
    mock_consult_repo.create.assert_awaited_once_with(
        consultation_number=consultation_number,
        clinic_id="CLINIC-123",
        patient_id=uuid.UUID(patient_uid),
        intake_id=uuid.uuid4(),
        doctor_user_id=user_obj.id,
    )
    mock_intake_repo.update_status.assert_awaited_once()
    mock_db_session.commit.assert_awaited_once()

# ------------------------------------------------------------------------
# Test update_consultation (cannot modify completed consultations)
# ------------------------------------------------------------------------
async def test_update_consultation_completed_status(
    mock_db_session, mock_service_repo, mock_intake_repo, mock_consult_repo
):
    service = ConsultationService(mock_db_session)
    service.patient_repository = mock_service_repo
    service.consultation_repository = mock_consult_repo

    # Mock user
    user_obj = MagicMock(clinic_id="CLINIC-123")
    doctor_role = MagicMock()
    doctor_role.name = "doctor"
    user_obj.roles = [doctor_role]

    # Mock an existing consultation with "completed" status
    completed_consultation = MagicMock()
    completed_consultation.status = "completed"
    mock_consult_repo.get_by_consultation_number.return_value = completed_consultation

    with pytest.raises(HTTPException) as excinfo:
        await service.update_consultation(
            consultation_number="123",
            update_data=MagicMock(),
            current_user=user_obj,
        )
    exc = excinfo.value
    assert exc.detail == (
        "Consultation with status 'completed' cannot be modified"
    )
    mock_db_session.rollback.assert_awaited_once()
