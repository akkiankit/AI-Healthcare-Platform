
# app/modules/clinics/schemas.py
"""
Clinic API schemas.

These schemas define request and response contracts for clinic registration,
clinic profile management, and clinic lookup APIs.
"""

from datetime import datetime
from uuid import UUID

from pydantic import BaseModel, ConfigDict, EmailStr, Field, field_validator


class ClinicBase(BaseModel):
    """
    Shared clinic fields.

    Contains clinic identity, contact, and address fields used across create
    and read API contracts.
    """

    name: str = Field(..., min_length=2, max_length=150)
    email: EmailStr | None = None
    phone_number: str | None = Field(default=None, max_length=30)

    address_line_1: str | None = Field(default=None, max_length=255)
    address_line_2: str | None = Field(default=None, max_length=255)
    city: str | None = Field(default=None, max_length=100)
    state: str | None = Field(default=None, max_length=100)
    postal_code: str | None = Field(default=None, max_length=20)
    country: str | None = Field(default=None, max_length=100)

    @field_validator(
        "name",
        "phone_number",
        "address_line_1",
        "address_line_2",
        "city",
        "state",
        "postal_code",
        "country",
        mode="before",
    )
    @classmethod
    def normalize_text_fields(cls, value: str | None) -> str | None:
        """
        Trim clinic text fields.

        Blank optional strings are converted to None to keep persisted data
        clean and consistent.
        """
        if value is None:
            return None

        if not isinstance(value, str):
            raise ValueError("value must be a string")

        normalized_value = value.strip()
        return normalized_value or None


class ClinicCreate(ClinicBase):
    """
    Request schema for creating a clinic.
    """


class ClinicUpdate(BaseModel):
    """
    Request schema for partially updating clinic details.

    All fields are optional to support PATCH-style updates.
    """

    name: str | None = Field(default=None, min_length=2, max_length=150)
    email: EmailStr | None = None
    phone_number: str | None = Field(default=None, max_length=30)

    address_line_1: str | None = Field(default=None, max_length=255)
    address_line_2: str | None = Field(default=None, max_length=255)
    city: str | None = Field(default=None, max_length=100)
    state: str | None = Field(default=None, max_length=100)
    postal_code: str | None = Field(default=None, max_length=20)
    country: str | None = Field(default=None, max_length=100)

    is_active: bool | None = None

    @field_validator(
        "name",
        "phone_number",
        "address_line_1",
        "address_line_2",
        "city",
        "state",
        "postal_code",
        "country",
        mode="before",
    )
    @classmethod
    def normalize_optional_text_fields(cls, value: str | None) -> str | None:
        """
        Trim optional clinic update fields.

        Blank strings become None to prevent meaningless updates.
        """
        if value is None:
            return None

        if not isinstance(value, str):
            raise ValueError("value must be a string")

        normalized_value = value.strip()
        return normalized_value or None


class ClinicRead(ClinicBase):
    """
    Response schema returned by clinic APIs.

    from_attributes=True allows Pydantic to serialize SQLAlchemy ORM objects.
    """

    model_config = ConfigDict(from_attributes=True)

    id: UUID
    is_active: bool
    created_at: datetime
    updated_at: datetime | None = None


class ClinicListResponse(BaseModel):
    """
    Paginated clinic list response.

    Used by clinic list/search APIs with pagination metadata.
    """

    clinics: list[ClinicRead]
    total: int = Field(..., ge=0)
    limit: int = Field(..., ge=1, le=100)
    offset: int = Field(..., ge=0)