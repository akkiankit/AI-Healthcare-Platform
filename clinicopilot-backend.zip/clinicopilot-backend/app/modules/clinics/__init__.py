
# app/modules/clinics/__init__.py
"""
Clinic module exports.
"""

from app.modules.clinics.schemas import (
    ClinicBase,
    ClinicCreate,
    ClinicListResponse,
    ClinicRead,
    ClinicUpdate,
)

__all__ = [
    "ClinicBase",
    "ClinicCreate",
    "ClinicListResponse",
    "ClinicRead",
    "ClinicUpdate",
]