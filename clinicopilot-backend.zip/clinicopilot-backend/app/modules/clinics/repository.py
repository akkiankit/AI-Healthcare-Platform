"""
Clinic repository.

Contains async database lookup operations for clinic records.
"""

from sqlalchemy import func, select
from sqlalchemy.ext.asyncio import AsyncSession

from app.modules.clinics.models import Clinic


class ClinicRepository:
    """
    Database access layer for clinic records.

    Used by other modules when they need to resolve clinic information.
    """

    def __init__(self, db: AsyncSession) -> None:
        """
        Initialize repository with active async DB session.
        """
        self.db = db

    async def get_by_name(self, clinic_name: str) -> Clinic | None:
        """
        Fetch one active clinic by name.

        Matching is case-insensitive to make API input user-friendly.
        """
        normalized_name = clinic_name.strip().lower()

        statement = select(Clinic).where(
            func.lower(Clinic.name) == normalized_name,
            Clinic.is_active.is_(True),
        )

        result = await self.db.execute(statement)
        return result.scalar_one_or_none()