
"""
Diagnostic report database model.

This model stores uploaded diagnostic reports, OCR-extracted content,
structured extracted values, and AI-generated simplified explanations.
"""

import uuid
from datetime import datetime

from sqlalchemy import DateTime, ForeignKey, Index, String, Text, func
from sqlalchemy.dialects.postgresql import JSONB, UUID
from sqlalchemy.orm import Mapped, mapped_column
from app.db.base_class import Base


class DiagnosticReport(Base):
    """
    Represents a diagnostic report uploaded for a patient.

    Notes:
    - Original file is stored in external/object storage.
    - OCR output is stored for traceability.
    - AI explanation is stored as JSONB draft/reviewable content.
    """

    __tablename__ = "diagnostic_reports"

    __table_args__ = (
        Index("idx_diagnostic_reports_patient_id", "patient_id"),
        Index("idx_diagnostic_reports_consultation_id", "consultation_id"),
        Index("idx_diagnostic_reports_status", "status"),
        Index("idx_diagnostic_reports_uploaded_at", "uploaded_at"),
    )

    id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True),
        primary_key=True,
        default=uuid.uuid4,
        comment="Primary unique identifier for diagnostic report.",
    )

    patient_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True),
        ForeignKey("patients.id", ondelete="CASCADE"),
        nullable=False,
        comment="Patient linked to this diagnostic report.",
    )

    consultation_id: Mapped[uuid.UUID | None] = mapped_column(
        UUID(as_uuid=True),
        ForeignKey("consultations.id", ondelete="SET NULL"),
        nullable=True,
        comment="Optional consultation linked to this diagnostic report.",
    )

    file_url: Mapped[str] = mapped_column(
        Text,
        nullable=False,
        comment="Secure storage URL/path for uploaded diagnostic report.",
    )

    report_type: Mapped[str | None] = mapped_column(
        String(100),
        nullable=True,
        comment="Report type such as CBC, thyroid, sugar, lipid profile, etc.",
    )

    extracted_text: Mapped[str | None] = mapped_column(
        Text,
        nullable=True,
        comment="Raw OCR-extracted text from diagnostic report.",
    )

    extracted_values_json: Mapped[dict | None] = mapped_column(
        JSONB,
        nullable=True,
        comment="Structured report values extracted from OCR/document processing.",
    )

    ai_explanation_json: Mapped[dict | None] = mapped_column(
        JSONB,
        nullable=True,
        comment="AI-generated simplified explanation for doctor review.",
    )

    status: Mapped[str] = mapped_column(
        String(50),
        nullable=False,
        default="uploaded",
        comment="Report status: uploaded, ocr_processed, ai_draft, approved, failed.",
    )

    uploaded_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True),
        server_default=func.now(),
        nullable=False,
        comment="Timestamp when report was uploaded.",
    )

    def __repr__(self) -> str:
        """
        Return developer-friendly representation for debugging/logging.
        """
        return (
            f"<DiagnosticReport(id={self.id}, "
            f"patient_id={self.patient_id}, "
            f"status={self.status})>"
        )
