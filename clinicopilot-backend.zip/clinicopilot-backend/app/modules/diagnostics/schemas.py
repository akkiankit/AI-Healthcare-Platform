"""
Diagnostic API schemas.

These schemas define request and response contracts for diagnostic orders,
test results, imaging references, lab reports, and doctor-reviewed findings.
"""

from datetime import datetime
from uuid import UUID

from pydantic import BaseModel, ConfigDict, Field, field_validator


class DiagnosticBase(BaseModel):
    """
    Shared diagnostic fields.

    Captures diagnostic test details linked to a patient and consultation.
    """

    test_name: str = Field(..., min_length=2, max_length=200)
    test_type: str | None = Field(default=None, max_length=100)
    result_summary: str | None = Field(default=None, max_length=5000)
    report_url: str | None = Field(default=None, max_length=1000)
    notes: str | None = Field(default=None, max_length=3000)

    @field_validator(
        "test_name",
        "test_type",
        "result_summary",
        "report_url",
        "notes",
        mode="before",
    )
    @classmethod
    def normalize_text_fields(cls, value: str | None) -> str | None:
        """
        Trim diagnostic text fields.

        Blank optional values become None to keep diagnostic records clean.
        """
        if value is None:
            return None

        if not isinstance(value, str):
            raise ValueError("value must be a string")

        normalized_value = value.strip()
        return normalized_value or None


class DiagnosticCreate(DiagnosticBase):
    """
    Request schema for creating a diagnostic record.

    consultation_id links the diagnostic item to a consultation.
    patient_id supports efficient patient-level diagnostic history lookup.
    ordered_by_user_id identifies the doctor or staff member who ordered it.
    """

    consultation_id: UUID
    patient_id: UUID
    ordered_by_user_id: UUID


class DiagnosticUpdate(BaseModel):
    """
    Request schema for partially updating diagnostic details.

    Used when lab results, report links, or doctor notes become available.
    """

    test_name: str | None = Field(default=None, min_length=2, max_length=200)
    test_type: str | None = Field(default=None, max_length=100)
    result_summary: str | None = Field(default=None, max_length=5000)
    report_url: str | None = Field(default=None, max_length=1000)
    notes: str | None = Field(default=None, max_length=3000)
    status: str | None = Field(default=None, max_length=50)

    @field_validator(
        "test_name",
        "test_type",
        "result_summary",
        "report_url",
        "notes",
        "status",
        mode="before",
    )
    @classmethod
    def normalize_optional_text_fields(cls, value: str | None) -> str | None:
        """
        Normalize optional diagnostic update fields.

        Empty strings become None to avoid whitespace-only clinical data.
        """
        if value is None:
            return None

        if not isinstance(value, str):
            raise ValueError("value must be a string")

        normalized_value = value.strip()
        return normalized_value or None

    @field_validator("status")
    @classmethod
    def normalize_status(cls, value: str | None) -> str | None:
        """
        Normalize diagnostic workflow status.

        Example:
        "Result Available" -> "result_available"
        """
        if value is None:
            return None

        return value.strip().lower().replace(" ", "_")


class DiagnosticRead(DiagnosticBase):
    """
    Response schema returned by diagnostic APIs.

    from_attributes=True allows direct serialization from SQLAlchemy ORM models.
    """

    model_config = ConfigDict(from_attributes=True)

    id: UUID
    consultation_id: UUID
    patient_id: UUID
    ordered_by_user_id: UUID
    status: str
    created_at: datetime
    updated_at: datetime | None = None


class DiagnosticListResponse(BaseModel):
    """
    Paginated diagnostic list response.

    Used by diagnostic list/search APIs with pagination metadata.
    """

    diagnostics: list[DiagnosticRead]
    total: int = Field(..., ge=0)
    limit: int = Field(..., ge=1, le=100)
    offset: int = Field(..., ge=0)