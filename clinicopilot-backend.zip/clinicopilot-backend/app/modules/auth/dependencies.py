# app/modules/auth/dependencies.py

"""
Authentication and RBAC dependencies.

This module provides reusable FastAPI dependencies for:
- Extracting the current authenticated user from JWT.
- Enforcing role-based access control.

These dependencies are used by routers to protect APIs.
"""

from collections.abc import Callable

from fastapi import Depends, HTTPException, status
from fastapi.security import HTTPAuthorizationCredentials, HTTPBearer
from sqlalchemy.ext.asyncio import AsyncSession

from app.db.session import get_db
from app.modules.auth.service import AuthService
from app.modules.users.models import User


bearer_scheme = HTTPBearer(auto_error=False)


async def get_current_user(
    credentials: HTTPAuthorizationCredentials | None = Depends(bearer_scheme),
    db: AsyncSession = Depends(get_db),
) -> User:
    """
    Return the currently authenticated user from the JWT access token.

    Expected header:
        Authorization: Bearer <access_token>
    """

    if credentials is None:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Authentication credentials were not provided",
        )

    service = AuthService(db)

    return await service.get_user_from_token(credentials.credentials)

def require_roles(*allowed_roles: str) -> Callable:
    """
    Enforce role-based access control.

    Supports both:
    - New multi-role model: current_user.roles
    - Temporary legacy fallback: current_user.role
    """

    async def role_checker(
        current_user: User = Depends(get_current_user),
    ) -> User:
        user_roles = {role.name for role in getattr(current_user, "roles", [])}

        # Temporary backward-compatible fallback.
        if not user_roles and getattr(current_user, "role", None) is not None:
            user_roles.add(current_user.role.name)

        if not user_roles.intersection(allowed_roles):
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail="You do not have permission to perform this action",
            )

        return current_user

    return role_checker

def require_permissions(*required_permissions: str) -> Callable:
    """
    Enforce permission-based access control.

    Example:
        Depends(require_permissions("user:create"))
        Depends(require_permissions("patient:read"))
    """

    async def permission_checker(
        current_user: User = Depends(get_current_user),
    ) -> User:
        user_permissions: set[str] = set()

        for role in current_user.roles:
            for role_permission in role.role_permissions:
                user_permissions.add(role_permission.permission.code)

        if not user_permissions.intersection(required_permissions):
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail="You do not have permission to perform this action",
            )

        return current_user

    return permission_checker

# def require_roles(*allowed_roles: str) -> Callable:
#     """
#     Enforce role-based access control.

#     Example:
#         Depends(require_roles("clinic_admin"))
#         Depends(require_roles("doctor", "clinic_admin"))
#     """

#     async def role_checker(
#         current_user: User = Depends(get_current_user),
#     ) -> User:
#         user_role = current_user.role.name

#         if user_role not in allowed_roles:
#             raise HTTPException(
#                 status_code=status.HTTP_403_FORBIDDEN,
#                 detail="You do not have permission to perform this action",
#             )

#         return current_user

#     return role_checker