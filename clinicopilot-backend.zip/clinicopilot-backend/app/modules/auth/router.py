"""
API router for authentication workflows.

Router responsibilities:
- Expose login endpoint.
- Validate request and response schemas.
- Delegate authentication logic to AuthService.
"""

from fastapi import APIRouter, Depends, status
from sqlalchemy.ext.asyncio import AsyncSession

from app.db.session import get_db
from app.modules.auth.schemas import LoginRequest, LoginResponse, AuthenticatedUser
from app.modules.auth.service import AuthService
from app.modules.auth.dependencies import get_current_user, require_roles
from app.modules.users.models import User

router = APIRouter(
    prefix="/auth",
    tags=["Authentication"],
)


@router.post(
    "/login",
    response_model=LoginResponse,
    status_code=status.HTTP_200_OK,
    summary="User login",
    description=(
        "Authenticate clinic admin, doctor, or assistant user and return "
        "JWT access token with authenticated user context."
    ),
)
async def login(
    login_data: LoginRequest,
    db: AsyncSession = Depends(get_db),
) -> LoginResponse:
    """
    Authenticate user credentials.

    Supported roles:
    - clinic_admin
    - doctor
    - assistant
    """
    service = AuthService(db)

    return await service.login(login_data)

@router.get(
    "/me",
    response_model=AuthenticatedUser,
    status_code=status.HTTP_200_OK,
    summary="Get current authenticated user",
    description="Return the currently authenticated user from the JWT access token.",
)
async def get_me(
    current_user: User = Depends(get_current_user),
) -> AuthenticatedUser:
    """
    Return authenticated user context.

    Used by frontend after login to know:
    - user identity
    - clinic
    - role
    - active status
    """
    roles = [role.name for role in current_user.roles]
    return AuthenticatedUser(
        id=current_user.id,
        clinic_id=current_user.clinic_id,
        email=current_user.email,
        full_name=current_user.full_name,
        role = roles[0] if roles else None,
        roles=roles,
        is_active=current_user.is_active,
        last_login_at=current_user.last_login_at,
    )