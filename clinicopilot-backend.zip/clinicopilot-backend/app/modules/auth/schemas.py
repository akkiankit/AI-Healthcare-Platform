
# app/modules/auth/schemas.py
"""
Authentication API schemas.

These schemas define request and response contracts for login, token refresh,
password workflows, and authenticated user context.
"""

from datetime import datetime
from uuid import UUID

from pydantic import BaseModel, ConfigDict, EmailStr, Field, field_validator

class LoginRequest(BaseModel):
    """
    Request schema for user login.

    Accepts email and password credentials from the client.
    """

    email: EmailStr
    password: str = Field(..., min_length=8, max_length=128)


class TokenResponse(BaseModel):
    """
    Response schema returned after successful authentication.

    access_token is used for API authorization.
    refresh_token is used to obtain a new access token.
    """

    access_token: str
    refresh_token: str
    token_type: str = "bearer"
    expires_in: int = Field(..., ge=1)


class RefreshTokenRequest(BaseModel):
    """
    Request schema for refreshing an access token.
    """

    refresh_token: str = Field(..., min_length=20)


class PasswordChangeRequest(BaseModel):
    """
    Request schema for changing an authenticated user's password.
    """

    current_password: str = Field(..., min_length=8, max_length=128)
    new_password: str = Field(..., min_length=8, max_length=128)

    @field_validator("new_password")
    @classmethod
    def validate_new_password(cls, value: str) -> str:
        """
        Enforce a baseline password policy. Stronger password checks can later be moved into a shared security. 
        utility if reused across registration and reset flows.
        """

        if not any(char.isupper() for char in value):
            raise ValueError("new_password must contain at least one uppercase letter")
        
        if not any(char.islower() for char in value):
            raise ValueError("new_password must contain at least one lowercase letter")
        
        if not any(char.isdigit() for char in value):
            raise ValueError("new_password must contain at least one number")
        
        return value


class PasswordResetRequest(BaseModel):
    """
    Request schema for starting password reset flow.
    """

    email: EmailStr


class PasswordResetConfirmRequest(BaseModel):
    """
    Request schema for confirming password reset using a reset token.
    """

    reset_token: str = Field(..., min_length=20)
    new_password: str = Field(..., min_length=8, max_length=128)


class AuthenticatedUser(BaseModel):
    """
    Authenticated user context returned to the frontend.

    This schema exposes safe user identity fields after login.
    Sensitive fields such as password_hash must never be included.
    """

    model_config = ConfigDict(from_attributes=True)

    id: UUID
    clinic_id: UUID | None = None
    email: EmailStr
    full_name: str
    role: str | None = None
    roles: list[str] = Field(default_factory=list)
    is_active: bool
    last_login_at: datetime | None = None


class LoginResponse(BaseModel):
    """
        Full login response including token payload and authenticated user context.
    """
    token: TokenResponse
    user: AuthenticatedUser