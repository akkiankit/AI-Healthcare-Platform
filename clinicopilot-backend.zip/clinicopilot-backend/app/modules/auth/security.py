"""
Security utilities for authentication.

This module handles:
- Password hashing
- Password verification
- JWT access token generation

Why separate file?
Security logic should be isolated so routers/services do not directly manage
cryptographic operations.
"""

from datetime import UTC, datetime, timedelta
from typing import Any

from jose import jwt
from passlib.context import CryptContext

from app.core.config import settings


password_context = CryptContext(
    schemes=["bcrypt"],
    deprecated="auto",
)


def hash_password(password: str) -> str:
    """
    Hash a plain-text password before storing it in the database.
    """
    return password_context.hash(password)


def verify_password(plain_password: str, password_hash: str) -> bool:
    """
    Verify a plain-text password against the stored password hash.
    """
    return password_context.verify(plain_password, password_hash)


def create_access_token(
    *,
    subject: str,
    expires_delta: timedelta | None = None,
    additional_claims: dict[str, Any] | None = None,
) -> str:
    """
    Create a signed JWT access token.

    Args:
        subject: Usually user.id as string.
        expires_delta: Optional custom expiry.
        additional_claims: Extra token data such as role or clinic_id.

    Returns:
        Encoded JWT string.
    """
    expire_at = datetime.now(UTC) + (
        expires_delta or timedelta(minutes=settings.ACCESS_TOKEN_EXPIRE_MINUTES)
    )

    payload: dict[str, Any] = {
        "sub": subject,
        "exp": expire_at,
        "iat": datetime.now(UTC),
    }

    if additional_claims:
        payload.update(additional_claims)

    return jwt.encode(
        payload,
        settings.SECRET_KEY,
        algorithm=settings.ALGORITHM,
    )