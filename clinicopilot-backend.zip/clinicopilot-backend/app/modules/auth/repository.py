"""
Repository layer for authentication workflows.

This module contains database queries needed by auth services.

Repository responsibilities:
- Fetch users by email.
- Fetch users by ID.
- Load role information required for RBAC.
- Update login metadata.

Business rules stay in the service layer.
"""

from uuid import UUID

from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.orm import selectinload
from app.modules.users.models import User, RolePermission, Role


class AuthRepository:
    """
    Repository for authentication-related user lookups.
    """

    def __init__(self, db: AsyncSession) -> None:
        self.db = db

    async def get_user_by_email(self, email: str) -> User | None:
        """
        Fetch user by email with role eagerly loaded.

        Why:
        - Login needs user credentials.
        - RBAC needs role name.
        - selectinload prevents lazy-loading issues in async SQLAlchemy.
        """
        result = await self.db.execute(
            select(User)
            .options(
                # selectinload(User.role),
                selectinload(User.roles)
                .selectinload(Role.role_permissions)
                .selectinload(RolePermission.permission)
            )
            .where(User.email == email.lower().strip())
        )

        return result.scalar_one_or_none()

    async def get_user_by_id(self, user_id: UUID) -> User | None:
        """
        Fetch user by internal UUID with role eagerly loaded.

        Used by current_user dependency after JWT validation.
        """
        result = await self.db.execute(
            select(User)
            .options(
                selectinload(User.roles)
                .selectinload(Role.role_permissions)
                .selectinload(RolePermission.permission))
            .where(User.id == user_id)
        )

        return result.scalar_one_or_none()

    async def update_last_login(self, user: User) -> User:
        """
        Update user's last login timestamp.

        Commit is controlled by service layer.
        """
        from datetime import UTC, datetime

        user.last_login_at = datetime.now(UTC)

        await self.db.flush()
        await self.db.refresh(user)

        return user