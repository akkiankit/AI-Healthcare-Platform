"""
Service layer for authentication workflows.

This module owns auth business rules:
- Validate login credentials.
- Verify password.
- Generate JWT tokens.
- Build safe authenticated user response.
- Update last login timestamp.
"""

from datetime import timedelta
from uuid import UUID

from fastapi import HTTPException, status
from jose import JWTError, jwt
from sqlalchemy.exc import SQLAlchemyError
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.config import settings
from app.modules.auth.repository import AuthRepository
from app.modules.auth.schemas import (AuthenticatedUser,LoginRequest,LoginResponse,TokenResponse,)
from app.modules.auth.security import create_access_token, verify_password
from app.modules.users.models import User


class AuthService:
    """
    Business service for authentication.
    """

    def __init__(self, db: AsyncSession) -> None:
        self.db = db
        self.auth_repository = AuthRepository(db)

    async def login(self, login_data: LoginRequest) -> LoginResponse:
        """
        Authenticate user and return JWT token with safe user context.
        """

        user = await self.auth_repository.get_user_by_email(login_data.email)

        if user is None:
            raise HTTPException(
                status_code=status.HTTP_401_UNAUTHORIZED,
                detail="Invalid email or password",
            )

        if not user.is_active:
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail="User account is inactive",
            )

        if not verify_password(login_data.password, user.password_hash):
            raise HTTPException(
                status_code=status.HTTP_401_UNAUTHORIZED,
                detail="Invalid email or password",
            )

        access_token_expires = timedelta(
            minutes=settings.ACCESS_TOKEN_EXPIRE_MINUTES
        )

        access_token = create_access_token(
            subject=str(user.id),
            expires_delta=access_token_expires,
            additional_claims={
                "clinic_id": str(user.clinic_id) if user.clinic_id else None,
                # "role": self._get_user_role_names(user)[0] if self._get_user_role_names(user) else None,
                "roles": self._get_user_role_names(user),
                "email": user.email,
            },
        )

        # For now, use access token as refresh placeholder.
        # Later we should implement real refresh token storage/rotation.
        refresh_token = create_access_token(
            subject=str(user.id),
            expires_delta=timedelta(days=7),
            additional_claims={
                "token_type": "refresh",
            },
        )

        try:
            await self.auth_repository.update_last_login(user)
            await self.db.commit()
            await self.db.refresh(user)

        except SQLAlchemyError as exc:
            await self.db.rollback()
            raise HTTPException(
                status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                detail="Database error occurred while updating login metadata",
            ) from exc

        return LoginResponse(
            token=TokenResponse(
                access_token=access_token,
                refresh_token=refresh_token,
                expires_in=settings.ACCESS_TOKEN_EXPIRE_MINUTES * 60,
            ),
            user=self._build_authenticated_user(user),
        )

    async def get_user_from_token(self, token: str) -> User:
        """
        Decode JWT token and return authenticated user.
        """

        try:
            payload = jwt.decode(
                token,
                settings.SECRET_KEY,
                algorithms=[settings.ALGORITHM],
            )

            user_id = payload.get("sub")

            if user_id is None:
                raise HTTPException(
                    status_code=status.HTTP_401_UNAUTHORIZED,
                    detail="Invalid authentication token",
                )

        except JWTError as exc:
            raise HTTPException(
                status_code=status.HTTP_401_UNAUTHORIZED,
                detail="Invalid or expired authentication token",
            ) from exc

        user = await self.auth_repository.get_user_by_id(UUID(user_id))

        if user is None:
            raise HTTPException(
                status_code=status.HTTP_401_UNAUTHORIZED,
                detail="Authenticated user not found",
            )

        if not user.is_active:
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail="User account is inactive",
            )

        return user

    def _build_authenticated_user(self, user: User) -> AuthenticatedUser:
        """
        Convert User ORM object into safe API response schema.
        """

        return AuthenticatedUser(
            id=user.id,
            clinic_id=user.clinic_id,
            email=user.email,
            full_name=user.full_name,
            role=self._get_user_role_names(user)[0] if self._get_user_role_names(user) else None,
            roles=self._get_user_role_names(user),
            is_active=user.is_active,
            last_login_at=user.last_login_at,
        )
    
    def _get_user_role_names(self, user: User) -> list[str]:
        roles = [role.name for role in getattr(user, "roles", [])]

        if not roles and getattr(user, "role", None) is not None:
            roles.append(user.role.name)

        return roles