"""
AI output database model.

This model stores all AI-generated outputs such as:
- patient summaries
- follow-up questions
- condition-based assistance
- prescription draft assistance
- diagnostic report explanations

Every AI output should be stored as a draft first and reviewed by a doctor
before becoming part of the final clinical record.
"""

import uuid
from datetime import datetime

from sqlalchemy import DateTime, ForeignKey, Index, String, func
from sqlalchemy.dialects.postgresql import JSONB, UUID
from sqlalchemy.orm import Mapped, mapped_column, relationship

from app.db.base_class import Base


class AIOutput(Base):
    """
    Represents an AI-generated output linked to a consultation.

    Notes:
    - Stores prompt version for traceability.
    - Stores both input and output JSON for audit/debugging.
    - Status should indicate draft, approved, edited, rejected, or failed.
    """

    __tablename__ = "ai_outputs"

    __table_args__ = (
        Index("idx_ai_outputs_consultation_id", "consultation_id"),
        Index("idx_ai_outputs_ai_type", "ai_type"),
        Index("idx_ai_outputs_status", "status"),
        Index("idx_ai_outputs_created_at", "created_at"),
    )

    id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True),
        primary_key=True,
        default=uuid.uuid4,
        comment="Primary unique identifier for AI output.",
    )

    consultation_id: Mapped[uuid.UUID | None] = mapped_column(
        UUID(as_uuid=True),
        ForeignKey("consultations.id", ondelete="CASCADE"),
        nullable=True,
        comment="Consultation linked to this AI output.",
    )

    ai_type: Mapped[str] = mapped_column(
        String(100),
        nullable=False,
        comment="AI output type: patient_summary, follow_up_questions, etc.",
    )

    prompt_version: Mapped[str | None] = mapped_column(
        String(50),
        nullable=True,
        comment="Prompt template version used to generate this output.",
    )

    input_json: Mapped[dict | None] = mapped_column(
        JSONB,
        nullable=True,
        comment="Structured input sent to the AI service.",
    )

    output_json: Mapped[dict] = mapped_column(
        JSONB,
        nullable=False,
        comment="Structured AI-generated output.",
    )

    status: Mapped[str] = mapped_column(
        String(50),
        nullable=False,
        default="draft",
        comment="AI output status: draft, approved, edited, rejected, failed.",
    )

    reviewed_by_user_id: Mapped[uuid.UUID | None] = mapped_column(
        UUID(as_uuid=True),
        ForeignKey("users.id", ondelete="SET NULL"),
        nullable=True,
        comment="Doctor/user who reviewed this AI output.",
    )

    reviewed_at: Mapped[datetime | None] = mapped_column(
        DateTime(timezone=True),
        nullable=True,
        comment="Timestamp when AI output was reviewed.",
    )

    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True),
        server_default=func.now(),
        nullable=False,
        comment="Record creation timestamp.",
    )

    consultation = relationship("Consultation")

    def __repr__(self) -> str:
        """
        Return developer-friendly representation for debugging/logging.
        """
        return (
            f"<AIOutput(id={self.id}, "
            f"ai_type={self.ai_type}, "
            f"status={self.status})>"
        )