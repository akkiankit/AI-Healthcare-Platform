"""
app/modules/ai/schemas.py
AI workflow API schemas.

These schemas define request and response contracts for AI-assisted clinical
summaries, risk signals, recommendations, and doctor-in-the-loop approval.
"""

from datetime import datetime
from uuid import UUID

from pydantic import BaseModel, ConfigDict, Field, field_validator


class AISummaryBase(BaseModel):
    """
    Shared AI summary fields.

    Stores AI-generated clinical support output that must be reviewed by a
    licensed doctor before it influences care decisions.
    """

    summary_text: str = Field(..., min_length=10, max_length=8000)
    risk_level: str | None = Field(default=None, max_length=50)
    recommendation_text: str | None = Field(default=None, max_length=8000)
    model_name: str | None = Field(default=None, max_length=100)
    model_version: str | None = Field(default=None, max_length=100)

    @field_validator(
        "summary_text",
        "risk_level",
        "recommendation_text",
        "model_name",
        "model_version",
        mode="before",
    )
    @classmethod
    def normalize_text_fields(cls, value: str | None) -> str | None:
        """
        Trim AI text fields before validation.

        Blank optional values become None to avoid storing meaningless output.
        """
        if value is None:
            return None

        if not isinstance(value, str):
            raise ValueError("value must be a string")

        normalized_value = value.strip()
        return normalized_value or None

    @field_validator("risk_level")
    @classmethod
    def normalize_risk_level(cls, value: str | None) -> str | None:
        """
        Normalize AI risk levels for consistent downstream filtering.

        Example:
        "High Risk" -> "high_risk"
        """
        if value is None:
            return None

        return value.strip().lower().replace(" ", "_")


class AISummaryCreate(AISummaryBase):
    """
    Request schema for creating an AI summary.

    consultation_id links AI output to the clinical consultation workflow.
    """

    consultation_id: UUID


class AISummaryUpdate(BaseModel):
    """
    Request schema for updating AI summary review state.

    Used when a doctor reviews, accepts, edits, or rejects AI-generated output.
    """

    summary_text: str | None = Field(default=None, min_length=10, max_length=8000)
    risk_level: str | None = Field(default=None, max_length=50)
    recommendation_text: str | None = Field(default=None, max_length=8000)

    is_doctor_reviewed: bool | None = None
    doctor_review_notes: str | None = Field(default=None, max_length=5000)

    @field_validator(
        "summary_text",
        "risk_level",
        "recommendation_text",
        "doctor_review_notes",
        mode="before",
    )
    @classmethod
    def normalize_optional_text_fields(cls, value: str | None) -> str | None:
        """
        Normalize optional AI update text fields.

        Empty strings are converted to None to keep updates predictable.
        """
        if value is None:
            return None

        if not isinstance(value, str):
            raise ValueError("value must be a string")

        normalized_value = value.strip()
        return normalized_value or None

    @field_validator("risk_level")
    @classmethod
    def normalize_risk_level(cls, value: str | None) -> str | None:
        """
        Normalize risk level when included in update payload.
        """
        if value is None:
            return None

        return value.strip().lower().replace(" ", "_")


class AISummaryReviewRequest(BaseModel):
    """
    Request schema for explicit doctor review action.

    Keeps review decisions separate from general AI summary updates.
    """

    is_approved: bool
    doctor_review_notes: str | None = Field(default=None, max_length=5000)

    @field_validator("doctor_review_notes", mode="before")
    @classmethod
    def normalize_review_notes(cls, value: str | None) -> str | None:
        """
        Trim doctor review notes.

        Blank review notes are treated as None.
        """
        if value is None:
            return None

        if not isinstance(value, str):
            raise ValueError("doctor_review_notes must be a string")

        normalized_value = value.strip()
        return normalized_value or None


class AISummaryRead(AISummaryBase):
    """
    Response schema returned by AI summary APIs.

    from_attributes=True allows direct serialization from SQLAlchemy ORM models.
    """

    model_config = ConfigDict(from_attributes=True)

    id: UUID
    consultation_id: UUID

    is_doctor_reviewed: bool
    doctor_review_notes: str | None = None
    reviewed_by_user_id: UUID | None = None
    reviewed_at: datetime | None = None

    created_at: datetime
    updated_at: datetime | None = None


class AISummaryListResponse(BaseModel):
    """
    Paginated AI summary list response.

    Used by AI workflow list/search APIs with pagination metadata.
    """

    ai_summaries: list[AISummaryRead]
    total: int = Field(..., ge=0)
    limit: int = Field(..., ge=1, le=100)
    offset: int = Field(..., ge=0)