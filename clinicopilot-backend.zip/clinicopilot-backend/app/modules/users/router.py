"""
API router for clinic user management.

This module exposes user creation, listing, retrieval, update, and password reset
endpoints that are limited to clinic administrators.
"""

from uuid import UUID

from fastapi import APIRouter, Depends, Query, status
from sqlalchemy.ext.asyncio import AsyncSession

from app.db.session import get_db

# from app.modules.auth.dependencies import require_roles
from app.modules.auth.dependencies import require_permissions
from app.modules.users.schemas import (UserCreate, UserListResponse, UserPasswordReset, UserRead, UserUpdate,)
from app.modules.users.service import UserService
from app.modules.users.models import User

router = APIRouter(prefix="/users", tags=["Users"],)


@router.post(
    "",
    response_model=UserRead,
    status_code=status.HTTP_201_CREATED,
    summary="Create a clinic user",
    description=(
        "Clinic administrators may create doctor or assistant users for their "
        "own clinic."
    ),
)
async def create_user(
    user_data: UserCreate,
    db: AsyncSession = Depends(get_db),
        current_user: User = Depends(require_permissions("user:create")),
) -> UserRead:
    """Create a new user belonging to the current user's clinic."""
    print('Creating user with data:', user_data)
    service = UserService(db)
    return await service.create_user(user_data, current_user=current_user)


@router.get(
    "",
    response_model=UserListResponse,
    status_code=status.HTTP_200_OK,
    summary="List clinic users",
)
async def list_users(
    limit: int = Query(default=50, ge=1, le=100),
    offset: int = Query(default=0, ge=0),
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(require_permissions("user:list")),
) -> UserListResponse:
    """Return paginated users for the current clinic."""
    service = UserService(db)
    return await service.list_users(
        current_user=current_user,
        limit=limit,
        offset=offset,
    )


@router.get(
    "/{user_id}",
    response_model=UserRead,
    status_code=status.HTTP_200_OK,
    summary="Get user by ID",
)
async def get_user(
    user_id: UUID,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(require_permissions("user:read")),

) -> UserRead:
    """Return one clinic user by internal UUID."""
    service = UserService(db)
    return await service.get_user(user_id, current_user=current_user)


@router.patch(
    "/{user_id}",
    response_model=UserRead,
    status_code=status.HTTP_200_OK,
    summary="Update user",
)
async def update_user(
    user_id: UUID,
    user_data: UserUpdate,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(require_permissions("user:update")),
) -> UserRead:
    """Partially update a clinic user's profile or active state."""
    service = UserService(db)
    return await service.update_user(user_id, user_data, current_user=current_user)


@router.patch(
    "/{user_id}/reset-password",
    response_model=UserRead,
    status_code=status.HTTP_200_OK,
    summary="Reset user password",
)
async def reset_user_password(
    user_id: UUID,
    password_data: UserPasswordReset,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(require_permissions("user:reset_password")),
) -> UserRead:
    """Reset a clinic user's password."""
    service = UserService(db)
    return await service.reset_password(
        user_id,
        new_password=password_data.password,
        current_user=current_user,
    )


@router.patch(
    "/{user_id}/deactivate",
    response_model=UserRead,
    status_code=status.HTTP_200_OK,
    summary="Deactivate user",
)
async def deactivate_user(
    user_id: UUID,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(require_permissions("user:deactivate")),
) -> UserRead:
    service = UserService(db)
    return await service.deactivate_user(user_id, current_user=current_user)


@router.patch(
    "/{user_id}/activate",
    response_model=UserRead,
    status_code=status.HTTP_200_OK,
    summary="Activate user",
)
async def activate_user(
    user_id: UUID,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(require_permissions("user:activate")),
) -> UserRead:
    service = UserService(db)
    return await service.activate_user(user_id, current_user=current_user)


@router.patch(
    "/{user_id}/roles",
    response_model=UserRead,
    status_code=status.HTTP_200_OK,
    summary="Update user roles",
)
async def update_user_roles(
    user_id: UUID,
    user_data: UserUpdate,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(require_permissions("user:assign_roles")),
) -> UserRead:
    service = UserService(db)
    return await service.update_user(user_id, user_data, current_user=current_user)
