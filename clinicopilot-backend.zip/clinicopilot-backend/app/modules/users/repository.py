"""
User repository.

Contains database operations for user management and RBAC-related lookups.
"""

from uuid import UUID

from sqlalchemy import func, select
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.orm import selectinload

from app.modules.users.models import Role, User


class UserRepository:
    """Database access layer for user management."""

    def __init__(self, db: AsyncSession) -> None:
        self.db = db

    async def get_by_id(self, user_id: UUID) -> User | None:
        """Fetch a user by internal UUID."""
        result = await self.db.execute(
            select(User)
            # .options(selectinload(User.role))
            .options(selectinload(User.roles))
            .where(User.id == user_id)
        )
        return result.scalar_one_or_none()

    async def get_by_email(self, email: str) -> User | None:
        """Fetch a user by email address."""
        result = await self.db.execute(
            select(User)
            # .options(selectinload(User.role))
            .options(selectinload(User.roles))
            .where(User.email == email.lower().strip())
        )
        return result.scalar_one_or_none()

    async def get_role_by_name(self, role_name: str) -> Role | None:
        """Fetch a role by normalized name."""
        result = await self.db.execute(
            select(Role).where(Role.name == role_name.strip().lower())
        )
        return result.scalar_one_or_none()

    async def count_by_clinic(self, clinic_id: UUID) -> int:
        """Return the total number of users for a clinic."""
        result = await self.db.execute(
            select(func.count()).select_from(User).where(User.clinic_id == clinic_id)
        )
        return int(result.scalar_one())

    async def list_by_clinic(
        self,
        clinic_id: UUID,
        limit: int = 50,
        offset: int = 0,
    ) -> tuple[list[User], int]:
        """Return paginated users for a clinic."""
        query = select(User).options(selectinload(User.roles)).where(User.clinic_id == clinic_id)
        result = await self.db.execute(query.order_by(User.created_at.desc()).limit(limit).offset(offset))
        users = list(result.scalars().all())
        total = await self.count_by_clinic(clinic_id)
        return users, total

    async def create(
        self,
        *,
        full_name: str,
        email: str,
        password_hash: str,
        phone: str | None,
        # role_id: UUID,
        clinic_id: UUID,
        roles: list[Role],
    ) -> User:
        """Create a new clinic-affiliated user."""
        user = User(
            clinic_id=clinic_id,
            # role_id=role_id,
            full_name=full_name.strip(),
            email=email.lower().strip(),
            phone=phone.strip() if phone else None,
            password_hash=password_hash,
            is_active=True,
        )

        user.roles.extend(roles)
        if roles:
            user.role_id = roles[0].id  # Set role_id to the first role for backward compatibility.

        self.db.add(user)
        await self.db.flush()
        await self.db.refresh(user)
        return user

    async def update(self, user: User, user_data: dict[str, object]) -> User:
        """Apply partial updates to a user."""
        for field_name, field_value in user_data.items():
            setattr(user, field_name, field_value)

        await self.db.flush()
        await self.db.refresh(user)
        return user
    
    async def update_roles(self, user: User, roles: list[Role]) -> User:
        """Update a user's roles."""
        user.roles = roles
        if roles:
            user.role_id = roles[0].id  # Update role_id to the first role for backward compatibility.
        else:
            user.role_id = None  # Clear role_id if no roles assigned.

        await self.db.flush()
        await self.db.refresh(user)
        return user
