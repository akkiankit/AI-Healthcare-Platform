"""
User service.

Contains business logic for clinic user management.
"""

from uuid import UUID

from fastapi import HTTPException, status
from sqlalchemy.ext.asyncio import AsyncSession

from app.modules.auth.security import hash_password
from app.modules.users.models import Role, User
from app.modules.users.repository import UserRepository
from app.modules.users.schemas import ( UserCreate, UserListResponse, UserRead,
    UserUpdate,
)


class UserService:
    """Business service for user management."""

    ALLOWED_CREATE_ROLES = {"doctor", "assistant", "clinic_admin"}

    def __init__(self, db: AsyncSession) -> None:
        self.db = db
        self.repository = UserRepository(db)

    def _to_user_read(self, user: User) -> UserRead:
        """Convert User ORM object to API response."""
        return UserRead(
            id=user.id,
            clinic_id=user.clinic_id,
            email=user.email,
            full_name=user.full_name,
            roles=[role.name for role in user.roles],
            is_active=user.is_active,
            last_login_at=user.last_login_at,
            created_at=user.created_at,
            updated_at=user.updated_at,
        )

    async def _resolve_roles(self, role_names: list[str]) -> list[Role]:
        """Validate and fetch roles by name."""
        normalized_roles: list[str] = []
        roles: list[Role] = []

        for role_name in role_names:
            normalized_role = role_name.strip().lower().replace(" ", "_")

            if normalized_role not in self.ALLOWED_CREATE_ROLES:
                raise HTTPException(
                    status_code=status.HTTP_400_BAD_REQUEST,
                    detail="Role must be clinic_admin, doctor, or assistant",
                )

            if normalized_role in normalized_roles:
                continue

            normalized_roles.append(normalized_role)
            role = await self.repository.get_role_by_name(normalized_role)

            if role is None:
                raise HTTPException(
                    status_code=status.HTTP_400_BAD_REQUEST,
                    detail=f"Role '{normalized_role}' does not exist",
                )

            roles.append(role)

        return roles

    async def create_user(self, user_data: UserCreate, *, current_user: User) -> UserRead:
        """Create a new user for the authenticated clinic."""

        if current_user.clinic_id is None:
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail="You do not have permission to create users without an associated clinic",
            )

        existing_user = await self.repository.get_by_email(user_data.email)

        if existing_user is not None:
            raise HTTPException(
                status_code=status.HTTP_409_CONFLICT,
                detail="A user with this email address already exists",
            )

        roles = await self._resolve_roles(user_data.roles)
        password_hash = hash_password(user_data.password)

        user = await self.repository.create(
            full_name=user_data.full_name,
            email=user_data.email,
            phone=user_data.phone,
            password_hash=password_hash,
            clinic_id=current_user.clinic_id,
            roles=roles,
        )

        try:
            await self.db.commit()
            # await self.db.refresh(user)
        except Exception as exc:
            await self.db.rollback()
            raise HTTPException(
                status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                detail="Database error occurred while creating user",
            ) from exc

        user = await self.repository.get_by_id(user.id)
        if user is None:
            raise HTTPException(
                status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                detail="Database error occurred while retrieving created user",
            )

        return self._to_user_read(user)

    async def get_user(self, user_id: UUID, *, current_user: User) -> UserRead:
        """Retrieve a clinic user by internal UUID."""
        user = await self.repository.get_by_id(user_id)

        if user is None or user.clinic_id != current_user.clinic_id:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail="User not found",
            )

        return self._to_user_read(user)

    async def list_users(
        self,
        *,
        current_user: User,
        limit: int = 50,
        offset: int = 0,
    ) -> UserListResponse:
        """Return paginated clinic users."""
        users, total = await self.repository.list_by_clinic(
            current_user.clinic_id,
            limit=limit,
            offset=offset,
        )

        return UserListResponse(
            users=[self._to_user_read(user) for user in users],
            total=total,
            limit=limit,
            offset=offset,
        )

    async def update_user(
        self,
        user_id: UUID,
        user_data: UserUpdate,
        *,
        current_user: User,
    ) -> UserRead:
        """Update clinic user properties and roles."""
        print('Updating user with data:', user_data)
        user = await self.repository.get_by_id(user_id)

        if user is None or user.clinic_id != current_user.clinic_id:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail="User not found",
            )

        update_payload = user_data.model_dump(exclude_unset=True)

        if "roles" in update_payload:
            role_names = update_payload.pop("roles")
            roles = await self._resolve_roles(role_names)
            await self.repository.update_roles(user, roles)

        if update_payload:
            user = await self.repository.update(user, update_payload)

        try:
            await self.db.commit()
            # await self.db.refresh(user)
        except Exception as exc:
            await self.db.rollback()
            raise HTTPException(
                status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                detail="Database error occurred while updating user",
            ) from exc

        user = await self.repository.get_by_id(user.id)
        if user is None:
            raise HTTPException(
                status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                detail="Database error occurred while retrieving updated user",
            )

        return self._to_user_read(user)

    async def reset_password(
        self,
        user_id: UUID,
        new_password: str,
        *,
        current_user: User,
    ) -> UserRead:
        """Reset a clinic user's password."""
        user = await self.repository.get_by_id(user_id)

        if user is None or user.clinic_id != current_user.clinic_id:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail="User not found",
            )

        user.password_hash = hash_password(new_password)

        try:
            await self.db.flush()
            # await self.db.refresh(user)
            await self.db.commit()
        except Exception as exc:
            await self.db.rollback()
            raise HTTPException(
                status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                detail="Database error occurred while resetting password",
            ) from exc

        user = await self.repository.get_by_id(user.id)
        if user is None:
            raise HTTPException(
                status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                detail="Database error occurred while retrieving updated user",
            )

        return self._to_user_read(user)
    

    async def deactivate_user(self, user_id: UUID, *, current_user: User) -> UserRead:
        user = await self.repository.get_by_id(user_id)

        if user is None or user.clinic_id != current_user.clinic_id:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail="User not found",
            )

        if user.id == current_user.id:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="You cannot deactivate your own account",
            )

        user.is_active = False

        try:
            await self.db.flush()
            await self.db.refresh(user)
            await self.db.commit()
        except Exception as exc:
            await self.db.rollback()
            raise HTTPException(
                status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                detail="Database error occurred while deactivating user",
            ) from exc

        return self._to_user_read(user)


    async def activate_user(self, user_id: UUID, *, current_user: User) -> UserRead:
        user = await self.repository.get_by_id(user_id)

        if user is None or user.clinic_id != current_user.clinic_id:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail="User not found",
            )

        user.is_active = True

        try:
            await self.db.flush()
            await self.db.refresh(user)
            await self.db.commit()
        except Exception as exc:
            await self.db.rollback()
            raise HTTPException(
                status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                detail="Database error occurred while activating user",
            ) from exc

        return self._to_user_read(user)