

# app/modules/users/schemas.py
"""
User API schemas.

These schemas define request and response contracts for platform users such as
doctors, clinic admins, staff, and operational users. Sensitive fields like
password_hash are intentionally excluded from response schemas.
"""

from datetime import datetime
from uuid import UUID

from pydantic import BaseModel, ConfigDict, EmailStr, Field, field_validator


class UserBase(BaseModel):
    """
    Shared user fields.

    Contains safe user identity and profile fields used across create/read
    schemas.
    """

    email: EmailStr
    full_name: str = Field(..., min_length=2, max_length=150)
    phone: str | None = Field(default=None, min_length=5, max_length=30)
    # role: str = Field(..., min_length=2, max_length=50)
    roles: list[str] = Field(..., min_length=1)


    @field_validator("full_name", mode="before")
    @classmethod
    def normalize_text_fields(cls, value: str) -> str:
        """
        Trim and normalize required user text fields.
        """
        if not isinstance(value, str):
            raise ValueError("value must be a string")

        normalized_value = value.strip()

        if not normalized_value:
            raise ValueError("value cannot be empty")

        return normalized_value
    
    @field_validator("phone", mode="before")
    @classmethod
    def normalize_phone(cls, value: str | None) -> str | None:
        """
        Trim optional phone field.

        Blank strings become None to avoid meaningless updates.
        """
        if value is None:
            return None

        if not isinstance(value, str):
            raise ValueError("phone must be a string")

        normalized_value = value.strip()
        return normalized_value or None

    @field_validator("roles")
    @classmethod
    def normalize_roles(cls, values: list[str]) -> list[str]:
        """
        Trim and normalize role values.
        """

        normalized_roles: list[str] = []
        for value in values:
            if not isinstance(value, str):
                raise ValueError("each role must be a string")

            role = value.strip().lower().replace(" ", "_")

            if not role:
                raise ValueError("role values cannot be empty")
            
            if role not in normalized_roles:
                normalized_roles.append(role)

        return normalized_roles


class UserCreate(UserBase):
    """
    Request schema for creating a user.

    password is accepted only in create requests and must never be returned in
    API responses.
    """

    # clinic_id: UUID | None = None
    email: EmailStr
    full_name: str = Field(..., min_length=2, max_length=150)
    phone: str | None = Field(default=None, min_length=10, max_length=30)
    roles: list[str] = Field(..., min_length=1)
    password: str = Field(..., min_length=8, max_length=128)


class UserUpdate(BaseModel):
    """
    Request schema for partially updating a user.

    All fields are optional to support PATCH-style updates.
    """

    full_name: str | None = Field(default=None, min_length=2, max_length=150)
    phone: str | None = Field(default=None, min_length=10, max_length=30)
    roles: list[str] | None = Field(default=None, min_length=1)
    # clinic_id: UUID | None = None
    is_active: bool | None = None

    @field_validator("full_name", mode="before")
    @classmethod
    def normalize_optional_text_fields(cls, value: str | None) -> str | None:
        """
        Trim optional update text fields.

        Blank strings become None to avoid meaningless updates.
        """
        if value is None:
            return None

        if not isinstance(value, str):
            raise ValueError("value must be a string")

        normalized_value = value.strip()
        return normalized_value or None

    # @field_validator("role")
    # @classmethod
    # def normalize_role(cls, value: str | None) -> str | None:
    #     """
    #     Normalize role value when included in update payload.
    #     """
    #     if value is None:
    #         return None

    #     return value.strip().lower().replace(" ", "_")


class UserPasswordReset(BaseModel):
    """Request schema for resetting a user's password."""

    password: str = Field(..., min_length=8, max_length=128)


class UserRead(BaseModel):
    """
    Response schema returned by user APIs.

    from_attributes=True allows direct serialization from SQLAlchemy ORM models.
    """

    model_config = ConfigDict(from_attributes=True)

    id: UUID
    clinic_id: UUID | None = None

    email: EmailStr
    full_name: str
    phone: str | None = None
    roles: list[str]
    is_active: bool
    last_login_at: datetime | None = None
    created_at: datetime
    updated_at: datetime | None = None


class UserListResponse(BaseModel):
    """
    Paginated user list response.

    Used by user search/list APIs with pagination metadata.
    """

    users: list[UserRead]
    total: int = Field(..., ge=0)
    limit: int = Field(..., ge=1, le=100)
    offset: int = Field(..., ge=0)
