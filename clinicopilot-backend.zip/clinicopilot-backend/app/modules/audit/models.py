"""
Audit log database model.

This model stores immutable audit trail records for important user and system actions.
Audit logs are critical for healthcare traceability, security review, and compliance readiness.
"""

import uuid
from datetime import datetime

from sqlalchemy import DateTime, ForeignKey, Index, String, func
from sqlalchemy.dialects.postgresql import JSONB, UUID
from sqlalchemy.orm import Mapped, mapped_column
from app.db.base_class import Base


class AuditLog(Base):
    """
    Represents an audit log entry.

    Notes:
    - Audit records should be append-only.
    - Do not update or delete audit logs in normal application workflows.
    - Capture user, clinic, action, entity, old/new values, and request metadata.
    """

    __tablename__ = "audit_logs"

    __table_args__ = (
        Index("idx_audit_logs_user_id", "user_id"),
        Index("idx_audit_logs_clinic_id", "clinic_id"),
        Index("idx_audit_logs_entity", "entity_type", "entity_id"),
        Index("idx_audit_logs_created_at", "created_at"),
        Index("idx_audit_logs_action", "action"),
    )

    id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True),
        primary_key=True,
        default=uuid.uuid4,
        comment="Primary unique identifier for audit log entry.",
    )

    user_id: Mapped[uuid.UUID | None] = mapped_column(
        UUID(as_uuid=True),
        ForeignKey("users.id", ondelete="SET NULL"),
        nullable=True,
        comment="User who performed the action. Null for system actions.",
    )

    clinic_id: Mapped[uuid.UUID | None] = mapped_column(
        UUID(as_uuid=True),
        ForeignKey("clinics.id", ondelete="SET NULL"),
        nullable=True,
        comment="Clinic context for this audit event.",
    )

    action: Mapped[str] = mapped_column(
        String(150),
        nullable=False,
        comment="Action performed, for example PATIENT_CREATED or AI_SUMMARY_GENERATED.",
    )

    entity_type: Mapped[str] = mapped_column(
        String(100),
        nullable=False,
        comment="Entity type affected, for example patient, intake, consultation.",
    )

    entity_id: Mapped[uuid.UUID | None] = mapped_column(
        UUID(as_uuid=True),
        nullable=True,
        comment="Entity ID affected by this action.",
    )

    old_value_json: Mapped[dict | None] = mapped_column(
        JSONB,
        nullable=True,
        comment="Previous value before update, if applicable.",
    )

    new_value_json: Mapped[dict | None] = mapped_column(
        JSONB,
        nullable=True,
        comment="New value after create/update, if applicable.",
    )

    ip_address: Mapped[str | None] = mapped_column(
        String(100),
        nullable=True,
        comment="Request IP address, if available.",
    )

    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True),
        server_default=func.now(),
        nullable=False,
        comment="Timestamp when audit event was created.",
    )

    def __repr__(self) -> str:
        """
        Return developer-friendly representation for debugging/logging.
        """
        return (
            f"<AuditLog(id={self.id}, "
            f"action={self.action}, "
            f"entity_type={self.entity_type}, "
            f"entity_id={self.entity_id})>"
        )