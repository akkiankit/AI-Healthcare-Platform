"""
Audit API schemas.

These schemas define response contracts for audit events. Audit records are
system-generated and should not be freely created by external clients.
"""

from datetime import datetime
from uuid import UUID

from pydantic import BaseModel, ConfigDict, Field


class AuditLogRead(BaseModel):
    """
    Response schema for audit log records.

    Exposes security and compliance-relevant activity in a safe, read-only API
    format for authorized admins.
    """

    model_config = ConfigDict(from_attributes=True)

    id: UUID
    actor_user_id: UUID | None = None
    action: str = Field(..., min_length=2, max_length=150)
    entity_type: str = Field(..., min_length=2, max_length=100)
    entity_id: UUID | None = None
    ip_address: str | None = Field(default=None, max_length=100)
    user_agent: str | None = Field(default=None, max_length=500)
    metadata: dict | None = None
    created_at: datetime


class AuditLogListResponse(BaseModel):
    """
    Paginated audit log list response.

    Used by admin-only audit APIs with pagination metadata.
    """

    audit_logs: list[AuditLogRead]
    total: int = Field(..., ge=0)
    limit: int = Field(..., ge=1, le=100)
    offset: int = Field(..., ge=0)