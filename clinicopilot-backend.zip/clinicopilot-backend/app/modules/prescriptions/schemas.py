"""
app/modules/prescriptions/schemas.py
Prescription API schemas.

These schemas define request and response contracts for medication prescribing
workflows. Prescription records must remain doctor-controlled and auditable.
"""

from datetime import datetime
from uuid import UUID

from pydantic import BaseModel, ConfigDict, Field, field_validator


class PrescriptionBase(BaseModel):
    """
    Shared prescription fields.

    Captures medication instructions issued by a doctor during or after a
    consultation.
    """

    medication_name: str = Field(..., min_length=2, max_length=200)
    dosage: str = Field(..., min_length=1, max_length=100)
    frequency: str = Field(..., min_length=1, max_length=100)
    duration: str | None = Field(default=None, max_length=100)
    instructions: str | None = Field(default=None, max_length=2000)

    @field_validator(
        "medication_name",
        "dosage",
        "frequency",
        "duration",
        "instructions",
        mode="before",
    )
    @classmethod
    def normalize_text_fields(cls, value: str | None) -> str | None:
        """
        Trim prescription text fields.

        Blank optional values become None to avoid storing meaningless clinical
        instructions.
        """
        if value is None:
            return None

        if not isinstance(value, str):
            raise ValueError("value must be a string")

        normalized_value = value.strip()
        return normalized_value or None


class PrescriptionCreate(PrescriptionBase):
    """
    Request schema for creating a prescription.

    consultation_id links the prescription to a clinical consultation.
    patient_id supports efficient patient-level prescription lookup.
    prescribed_by_user_id identifies the doctor who issued it.
    """

    consultation_id: UUID
    patient_id: UUID
    prescribed_by_user_id: UUID


class PrescriptionUpdate(BaseModel):
    """
    Request schema for partially updating a prescription.

    Used for controlled correction workflows before finalization.
    """

    medication_name: str | None = Field(default=None, min_length=2, max_length=200)
    dosage: str | None = Field(default=None, min_length=1, max_length=100)
    frequency: str | None = Field(default=None, min_length=1, max_length=100)
    duration: str | None = Field(default=None, max_length=100)
    instructions: str | None = Field(default=None, max_length=2000)
    is_active: bool | None = None

    @field_validator(
        "medication_name",
        "dosage",
        "frequency",
        "duration",
        "instructions",
        mode="before",
    )
    @classmethod
    def normalize_optional_text_fields(cls, value: str | None) -> str | None:
        """
        Normalize optional prescription update fields.

        Empty strings become None to prevent accidental whitespace-only updates.
        """
        if value is None:
            return None

        if not isinstance(value, str):
            raise ValueError("value must be a string")

        normalized_value = value.strip()
        return normalized_value or None


class PrescriptionRead(PrescriptionBase):
    """
    Response schema returned by prescription APIs.

    from_attributes=True allows direct serialization from SQLAlchemy ORM models.
    """

    model_config = ConfigDict(from_attributes=True)

    id: UUID
    consultation_id: UUID
    patient_id: UUID
    prescribed_by_user_id: UUID
    is_active: bool
    created_at: datetime
    updated_at: datetime | None = None


class PrescriptionListResponse(BaseModel):
    """
    Paginated prescription list response.

    Used by prescription list/search APIs with pagination metadata.
    """

    prescriptions: list[PrescriptionRead]
    total: int = Field(..., ge=0)
    limit: int = Field(..., ge=1, le=100)
    offset: int = Field(..., ge=0)