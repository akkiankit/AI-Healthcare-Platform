"""
Prescription database models.

These models store doctor-created or AI-assisted prescription drafts.
A prescription must always be reviewed and approved by a doctor before becoming final.
"""

import uuid
from datetime import datetime

from sqlalchemy import DateTime, ForeignKey, Index, String, Text, func
from sqlalchemy.dialects.postgresql import UUID
from sqlalchemy.orm import Mapped, mapped_column, relationship
from app.db.base_class import Base


class Prescription(Base):
    """
    Represents a prescription linked to a consultation.

    Notes:
    - Prescription starts as draft.
    - Doctor approval is required before finalization.
    - Prescription items are stored separately for better structure.
    """

    __tablename__ = "prescriptions"

    __table_args__ = (
        Index("idx_prescriptions_consultation_id", "consultation_id"),
        Index("idx_prescriptions_status", "status"),
        Index("idx_prescriptions_created_at", "created_at"),
    )

    id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True),
        primary_key=True,
        default=uuid.uuid4,
        comment="Primary unique identifier for prescription.",
    )

    consultation_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True),
        ForeignKey("consultations.id", ondelete="CASCADE"),
        nullable=False,
        comment="Consultation linked to this prescription.",
    )

    created_by_user_id: Mapped[uuid.UUID | None] = mapped_column(
        UUID(as_uuid=True),
        ForeignKey("users.id", ondelete="SET NULL"),
        nullable=True,
        comment="Doctor/user who created the prescription.",
    )

    status: Mapped[str] = mapped_column(
        String(50),
        nullable=False,
        default="draft",
        comment="Prescription status: draft, approved, cancelled.",
    )

    instructions: Mapped[str | None] = mapped_column(
        Text,
        nullable=True,
        comment="General prescription-level instructions.",
    )

    approved_at: Mapped[datetime | None] = mapped_column(
        DateTime(timezone=True),
        nullable=True,
        comment="Timestamp when prescription was approved by doctor.",
    )

    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True),
        server_default=func.now(),
        nullable=False,
        comment="Record creation timestamp.",
    )

    updated_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True),
        server_default=func.now(),
        onupdate=func.now(),
        nullable=False,
        comment="Record last update timestamp.",
    )

    items = relationship(
        "PrescriptionItem",
        back_populates="prescription",
        cascade="all, delete-orphan",
        passive_deletes=True,
    )

    def __repr__(self) -> str:
        """
        Return developer-friendly representation for debugging/logging.
        """
        return (
            f"<Prescription(id={self.id}, "
            f"consultation_id={self.consultation_id}, "
            f"status={self.status})>"
        )


class PrescriptionItem(Base):
    """
    Represents one medicine item inside a prescription.

    Notes:
    - Stores both brand name and composition where available.
    - Dosage/frequency/duration are intentionally text fields for MVP flexibility.
    """

    __tablename__ = "prescription_items"

    __table_args__ = (
        Index("idx_prescription_items_prescription_id", "prescription_id"),
    )

    id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True),
        primary_key=True,
        default=uuid.uuid4,
        comment="Primary unique identifier for prescription item.",
    )

    prescription_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True),
        ForeignKey("prescriptions.id", ondelete="CASCADE"),
        nullable=False,
        comment="Prescription linked to this medicine item.",
    )

    medicine_name: Mapped[str] = mapped_column(
        String(255),
        nullable=False,
        comment="Medicine brand or name selected by doctor.",
    )

    composition: Mapped[str | None] = mapped_column(
        Text,
        nullable=True,
        comment="Generic composition, if available.",
    )

    dosage: Mapped[str | None] = mapped_column(
        String(100),
        nullable=True,
        comment="Dosage instruction, for example 500mg.",
    )

    duration: Mapped[str | None] = mapped_column(
        String(100),
        nullable=True,
        comment="Treatment duration, for example 5 days.",
    )

    frequency: Mapped[str | None] = mapped_column(
        String(100),
        nullable=True,
        comment="Frequency, for example twice daily.",
    )

    instructions: Mapped[str | None] = mapped_column(
        Text,
        nullable=True,
        comment="Medicine-specific instructions.",
    )

    prescription = relationship(
        "Prescription",
        back_populates="items",
    )

    def __repr__(self) -> str:
        """
        Return developer-friendly representation for debugging/logging.
        """
        return (
            f"<PrescriptionItem(id={self.id}, "
            f"medicine_name={self.medicine_name})>"
        )

