"""
API router for patient intake endpoints.

This module exposes HTTP endpoints for patient intake workflows.

Router responsibilities:
- Define API paths and HTTP methods.
- Validate request/response schemas.
- Inject database session dependency.
- Delegate business logic to service layer.

Business rules should remain in service.py.
Database queries should remain in repository.py.
"""

from uuid import UUID
from fastapi import APIRouter, Depends, Query, status
from sqlalchemy.ext.asyncio import AsyncSession
from app.db.session import get_db
from app.modules.intake.schemas import (IntakeCreate, IntakeListResponse, IntakeRead, IntakeUpdate,)
from app.modules.intake.service import PatientIntakeService
from app.modules.auth.dependencies import require_permissions
from app.modules.users.models import User

router = APIRouter(prefix="/intakes", tags=["Patient Intakes"],)

@router.post("", response_model=IntakeRead, status_code=status.HTTP_201_CREATED, summary="Create patient intake",
    description=(
        "Create a patient intake submission containing symptoms, history, "
        "vitals, consent, and additional clinical notes."
    ),
)
async def create_intake(
    intake_data: IntakeCreate,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(require_permissions("intake:create")),
) -> IntakeRead:
    """
    Create a new patient intake.

    Flow:
    - Validate request payload using IntakeCreate.
    - Verify patient exists in service layer.
    - Create intake record.
    - Return created intake.

    Args:
        intake_data: Patient intake creation payload.
        db: Async database session injected by FastAPI.
        current_user: Current authenticated user.
    Returns:
        Created intake response.
    """
    service = PatientIntakeService(db)
    intake = await service.create_intake(intake_data, current_user=current_user)

    return IntakeRead.model_validate(intake)


@router.get(
    "",
    response_model=IntakeListResponse,
    status_code=status.HTTP_200_OK,
    summary="List patient intakes",
    description=(
        "List patient intake records with optional filtering by patient ID "
        "and workflow status."
    ),
)
async def list_intakes(
    patient_id: UUID | None = Query(
        default=None,
        description="Optional patient ID filter.",
        
    ),
    intake_status: str | None = Query(
        default=None,
        description="Optional status filter: draft, submitted, reviewed, cancelled.",
    ),
    limit: int = Query(
        default=50,
        ge=1,
        le=100,
        description="Maximum number of records to return.",
    ),
    offset: int = Query(
        default=0,
        ge=0,
        description="Pagination offset.",
    ),
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(require_permissions("intake:list")),
) -> IntakeListResponse:
    """
    List intake records with pagination.

    Query examples:
    - /api/v1/intakes
    - /api/v1/intakes?patient_id=<uuid>
    - /api/v1/intakes?intake_status=submitted
    - /api/v1/intakes?limit=20&offset=40

    Args:
        patient_id: Optional patient UUID.
        intake_status: Optional intake workflow status.
        limit: Page size.
        offset: Pagination offset.
        db: Async database session.

    Returns:
        Paginated intake response.
    """
    service = PatientIntakeService(db)

    return await service.list_intakes(
        patient_id=patient_id,
        intake_status=intake_status,
        limit=limit,
        offset=offset,
        current_user=current_user
    )


@router.get(
    "/{intake_id}",
    response_model=IntakeRead,
    status_code=status.HTTP_200_OK,
    summary="Get intake by ID",
    description="Fetch a single patient intake record by intake ID.",
)
async def get_intake(
    intake_id: UUID,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(require_permissions("intake:read")),
) -> IntakeRead:
    """
    Get intake details by ID.

    Args:
        intake_id: Intake UUID from path.
        db: Async database session.

    Returns:
        Matching intake response.
    """
    service = PatientIntakeService(db)
    intake = await service.get_intake(intake_id, current_user=current_user)

    return IntakeRead.model_validate(intake)


@router.patch(
    "/{intake_id}",
    response_model=IntakeRead,
    status_code=status.HTTP_200_OK,
    summary="Update patient intake",
    description=(
        "Partially update an intake record. Only provided fields are updated. "
        "Reviewed or cancelled intakes cannot be modified."
    ),
)
async def update_intake(
    intake_id: UUID,
    update_data: IntakeUpdate,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(require_permissions("intake:update")),
) -> IntakeRead:
    """
    Partially update an existing intake.

    Flow:
    - Validate patch payload.
    - Fetch existing intake.
    - Enforce workflow rules.
    - Apply only provided fields.
    - Return updated intake.

    Args:
        intake_id: Intake UUID from path.
        update_data: Partial intake update payload.
        db: Async database session.
        current_user: Current authenticated user.

    Returns:
        Updated intake response.
    """
    service = PatientIntakeService(db)
    intake = await service.update_intake(intake_id, update_data, current_user=current_user)

    return IntakeRead.model_validate(intake)


@router.delete(
    "/{intake_id}",
    response_model=IntakeRead,
    status_code=status.HTTP_200_OK,
    summary="Cancel patient intake",
    description=(
        "Cancel an intake by changing its status to cancelled. "
        "The record is not physically deleted."
    ),
)
async def cancel_intake(
    intake_id: UUID,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(require_permissions("intake:cancel")),
) -> IntakeRead:
    """
    Cancel an intake.

    This endpoint performs soft cancellation.

    Args:
        intake_id: Intake UUID from path.
        db: Async database session.

    Returns:
        Cancelled intake response.
    """
    service = PatientIntakeService(db)
    intake = await service.cancel_intake(intake_id, current_user=current_user)

    return IntakeRead.model_validate(intake)