"""
Repository layer for patient intake records.

This module contains low-level database operations for PatientIntake.

Repository responsibilities:
- Build SQLAlchemy queries.
- Execute database operations.
- Return ORM objects or counts.

Repository should not contain business workflow decisions.
Those belong in the service layer.
"""

from uuid import UUID
from sqlalchemy import Select, func, select
from sqlalchemy.ext.asyncio import AsyncSession
from app.modules.intake.models import PatientIntake
from app.modules.intake.schemas import IntakeCreate, IntakeUpdate
from app.modules.patients.models import Patient

class PatientIntakeRepository:
    """
    Database repository for patient intake records.

    This class isolates SQLAlchemy query logic from the service layer.

    Benefits:
    - Easier testing.
    - Cleaner business logic.
    - Reusable database operations.
    - Lower coupling between API logic and SQLAlchemy.
    """

    def __init__(self, db: AsyncSession) -> None:
        """
        Initialize repository with an async database session.

        Args:
            db: Active SQLAlchemy AsyncSession.
        """
        self.db = db

    async def create(
        self,
        intake_data: IntakeCreate, patient_id: UUID, submitted_by: UUID,
        *,
        submitted_at,
        
    ) -> PatientIntake:
        """
        Create a new patient intake record.

        Args:
            intake_data: Validated intake creation payload.
            patient_id: ID of the patient associated with the intake.
            submitted_at: Submission timestamp decided by service layer.

        Returns:
            Newly created PatientIntake ORM object.

        Notes:
            This method only creates and flushes the object.
            Transaction commit is controlled by service layer.
        """
        intake = PatientIntake(
            patient_id=patient_id,
            chief_complaint=intake_data.chief_complaint,
            symptoms=intake_data.symptoms,
            symptom_duration=intake_data.symptom_duration,
            symptom_onset_date=intake_data.symptom_onset_date,
            symptom_severity=intake_data.symptom_severity,
            pain_score=intake_data.pain_score,
            current_medications=intake_data.current_medications,
            allergies=intake_data.allergies,
            past_medical_history=intake_data.past_medical_history,
            surgical_history=intake_data.surgical_history,
            family_history=intake_data.family_history,
            social_history=intake_data.social_history,
            vitals_json=intake_data.vitals_json,
            additional_notes=intake_data.additional_notes,
            consent_to_treatment=intake_data.consent_to_treatment,
            consent_to_ai_review=intake_data.consent_to_ai_review,
            status=intake_data.status,
            submitted_at=submitted_at,
            created_by_user_id=submitted_by,
        )

        self.db.add(intake)

        await self.db.flush()
        await self.db.refresh(intake)

        return intake

    async def get_by_id(self, intake_id: UUID) -> PatientIntake | None:
        """
        Fetch one intake record by its unique ID.

        Args:
            intake_id: Intake UUID.

        Returns:
            PatientIntake if found, otherwise None.
        """
        result = await self.db.execute(
            select(PatientIntake).where(PatientIntake.id == intake_id)
        )

        return result.scalar_one_or_none()

    async def list(
        self,
        *,
        patient_id: UUID | None = None,
        clinic_id: UUID | None = None,
        status: str | None = None,
        limit: int = 50,
        offset: int = 0,

    ) -> list[PatientIntake]:
        """
        Fetch paginated intake records.

        Args:
            patient_id: Optional filter by patient.
            status: Optional filter by workflow status.
            limit: Maximum records to return.
            offset: Pagination offset.

        Returns:
            List of matching PatientIntake records.

        Performance:
            Indexed filters are used for patient_id and status.
        """
        query = self._build_filtered_query(patient_id=patient_id, clinic_id=clinic_id, status=status)

        query = (
            query.order_by(PatientIntake.created_at.desc())
            .limit(limit)
            .offset(offset)
        )

        result = await self.db.execute(query)

        return list(result.scalars().all())

    async def count(
        self,
        *,
        patient_id: UUID | None = None,
        clinic_id: UUID | None = None,
        status: str | None = None,
    ) -> int:
        """
        Count intake records matching filters.

        Args:
            patient_id: Optional filter by patient.
            clinic_id: Optional filter by clinic.
            status: Optional filter by workflow status.

        Returns:
            Total count of matching records.
        """
        query = select(func.count(PatientIntake.id))

        # print(f"Counting intakes with filters - patient_id: {patient_id}, clinic_id: {clinic_id}, status: {status}")

        if clinic_id is not None:
            query = query.join(Patient, Patient.id == PatientIntake.patient_id)

        # print(f"Base count query: {query}")

        if patient_id is not None:
            query = query.where(PatientIntake.patient_id == patient_id)

        if status is not None:
            query = query.where(PatientIntake.status == status)

        result = await self.db.execute(query)

        return int(result.scalar_one())

    async def update(
        self,
        intake: PatientIntake,
        update_data: IntakeUpdate,
        *,
        submitted_at,
    ) -> PatientIntake:
        """
        Update an existing intake record.

        Args:
            intake: Existing PatientIntake ORM object.
            update_data: Validated partial update payload.
            submitted_at: Submission timestamp decided by service layer.

        Returns:
            Updated PatientIntake ORM object.

        Notes:
            Only fields explicitly provided in the request are updated.
        """
        update_payload = update_data.model_dump(exclude_unset=True)

        for field_name, field_value in update_payload.items():
            setattr(intake, field_name, field_value)

        if submitted_at is not None:
            intake.submitted_at = submitted_at

        await self.db.flush()
        await self.db.refresh(intake)

        return intake

    async def soft_cancel(self, intake: PatientIntake) -> PatientIntake:
        """
        Soft-cancel an intake by changing its status.

        Args:
            intake: Existing PatientIntake ORM object.

        Returns:
            Cancelled PatientIntake ORM object.

        Why not delete?
            Intake data is clinical history.
            For audit and safety, we preserve the record.
        """
        intake.status = "cancelled"

        await self.db.flush()
        await self.db.refresh(intake)

        return intake

    async def get_latest_submitted_by_patient_id(
    self,
    patient_id: UUID,
    ) -> PatientIntake | None:
        """
        Fetch the latest submitted intake for a patient.

        Used by consultation workflow.

        Why:
        - Consultation should start only from an intake that is ready for doctor review.
        - The service layer should not manually build SQL queries.
        - Ordering by submitted_at keeps the newest clinical visit first.
        """
        result = await self.db.execute(
            select(PatientIntake)
            .where(PatientIntake.patient_id == patient_id)
            .where(PatientIntake.status == "submitted")
            .order_by(PatientIntake.submitted_at.desc(), PatientIntake.created_at.desc())
            .limit(1)
        )

        return result.scalar_one_or_none()
    
    async def update_status(
        self,
        intake: PatientIntake,
        status: str,
        ) -> PatientIntake:
        """
        Update only the workflow status of an intake.

        Used by consultation workflow.

        Why:
        - Keeps status transition logic explicit.
        - Avoids reusing generic update methods for internal workflow transitions.
        - Prevents accidental modification of clinical intake fields.
        """
        intake.status = status

        await self.db.flush()
        await self.db.refresh(intake)

        return intake

    def _build_filtered_query(
        self,
        *,
        patient_id: UUID | None,
        clinic_id: UUID | None,
        status: str | None,
    ) -> Select:
        """
        Build a reusable filtered SELECT query.

        Args:
            patient_id: Optional patient filter.
            clinic_id: Optional clinic filter.
            status: Optional status filter.

        Returns:
            SQLAlchemy Select object.

        Why:
            Keeps filtering logic consistent between list-style queries.
        """
        query = select(PatientIntake)

        # if clinic_id is not None:
        #     query = query.join(Patient, Patient.id == PatientIntake.patient_id)
            # query = query.where(PatientIntake.clinic_id == clinic_id)

        if patient_id is not None:
            query = query.where(PatientIntake.patient_id == patient_id)

        if status is not None:
            query = query.where(PatientIntake.status == status)

        return query