"""
Pydantic schemas for patient intake APIs.

This module defines request and response contracts for the intake feature.

Schemas are used by FastAPI for:
- Request validation
- Response serialization
- Swagger documentation
- Type safety between router and service layers
"""

from datetime import date, datetime
from typing import Any
from uuid import UUID
from pydantic import BaseModel, ConfigDict, Field, field_validator, model_validator

VALID_INTAKE_STATUSES = {"draft", "submitted","consultation_in_progress", "consulted", "cancelled"}
VALID_SYMPTOM_SEVERITIES = {"mild", "moderate", "severe", "critical"}


class IntakeBase(BaseModel):
    """
    Shared fields used by intake create, update, and response schemas.

    Purpose:
    - Avoid duplicate field definitions.
    - Keep the API contract consistent.
    - Centralize validation rules for common fields.
    """

    chief_complaint: str | None = Field(
        default=None,
        min_length=3,
        max_length=500,
        description="Main reason for the patient's visit.",
        examples=["Fever and sore throat"],
    )

    symptoms: str | None = Field(
        default=None,
        description="Detailed symptoms reported by the patient.",
        examples=["Fever, cough, sore throat, and fatigue."],
    )

    symptom_duration: str | None = Field(
        default=None,
        max_length=100,
        description="How long the patient has had symptoms.",
        examples=["3 days"],
    )

    symptom_onset_date: date | None = Field(
        default=None,
        description="Approximate date when symptoms started.",
        examples=["2026-05-27"],
    )

    symptom_severity: str | None = Field(
        default=None,
        description="Severity of symptoms: mild, moderate, severe, or critical.",
        examples=["moderate"],
    )

    pain_score: int | None = Field(
        default=None,
        ge=0,
        le=10,
        description="Pain score from 0 to 10.",
        examples=[6],
    )

    current_medications: str | None = Field(
        default=None,
        description="Current medicines being taken by the patient.",
        examples=["Paracetamol 500mg twice daily"],
    )

    allergies: str | None = Field(
        default=None,
        description="Known drug, food, or environmental allergies.",
        examples=["Penicillin"],
    )

    past_medical_history: str | None = Field(
        default=None,
        description="Past illnesses or chronic conditions.",
        examples=["Asthma"],
    )

    surgical_history: str | None = Field(
        default=None,
        description="Previous surgeries or medical procedures.",
        examples=["Appendectomy in 2018"],
    )

    family_history: str | None = Field(
        default=None,
        description="Relevant family medical history.",
        examples=["Father has diabetes"],
    )

    social_history: str | None = Field(
        default=None,
        description="Lifestyle and social history relevant to care.",
        examples=["Non-smoker, occasional alcohol use"],
    )

    vitals_json: dict[str, Any] | None = Field(
        default=None,
        description="Flexible vitals object such as temperature, BP, pulse, SpO2.",
        examples=[
            {
                "temperature_f": 101.2,
                "blood_pressure": "120/80",
                "pulse": 88,
                "spo2": 98,
                "height_cm": 172,
                "weight_kg": 70,
            }
        ],
    )

    additional_notes: str | None = Field(
        default=None,
        description="Additional notes from patient or clinic staff.",
        examples=["Patient reports weakness since morning."],
    )

    consent_to_treatment: bool = Field(
        default=False,
        description="Whether patient has consented to treatment.",
    )

    consent_to_ai_review: bool = Field(
        default=False,
        description="Whether patient has consented to AI-assisted review.",
    )

    status: str = Field(
        default="submitted",
        description="Intake workflow status: draft, submitted, consultation_in_progress, consulted, or cancelled.",
        examples=["submitted"],
    )

    @field_validator(
        "chief_complaint",
        "symptoms",
        "symptom_duration",
        "symptom_severity",
        "current_medications",
        "allergies",
        "past_medical_history",
        "surgical_history",
        "family_history",
        "social_history",
        "additional_notes",
        mode="before",
    )
    @classmethod
    def normalize_blank_strings(cls, value: str | None) -> str | None:
        """
        Convert blank strings to None and trim extra spaces.

        Why:
        - Prevents storing meaningless empty strings.
        - Keeps database data cleaner.
        - Makes filtering and downstream AI processing easier.
        """
        if value is None:
            return None

        if isinstance(value, str):
            cleaned_value = value.strip()
            return cleaned_value or None

        return value

    @field_validator("symptom_severity")
    @classmethod
    def validate_symptom_severity(cls, value: str | None) -> str | None:
        """
        Validate symptom severity against allowed enterprise values.
        """
        if value is None:
            return None

        normalized_value = value.lower().strip()

        if normalized_value not in VALID_SYMPTOM_SEVERITIES:
            raise ValueError(
                "symptom_severity must be one of: mild, moderate, severe, critical"
            )

        return normalized_value

    @field_validator("status")
    @classmethod
    def validate_status(cls, value: str) -> str:
        """
        Validate intake workflow status.
        """
        normalized_value = value.lower().strip()

        if normalized_value not in VALID_INTAKE_STATUSES:
            raise ValueError(
                "status must be one of: draft, submitted, consultation_in_progress, consulted, cancelled"
            )

        return normalized_value

    @field_validator("symptom_onset_date")
    @classmethod
    def validate_symptom_onset_date(cls, value: date | None) -> date | None:
        """
        Prevent future symptom onset dates.

        Why:
        - A symptom cannot start in the future.
        - This catches incorrect patient/staff input early.
        """
        if value is not None and value > date.today():
            raise ValueError("symptom_onset_date cannot be in the future")

        return value

    @model_validator(mode="after")
    def validate_submission_consent(self) -> "IntakeBase":
        """
        Require consent when intake is submitted.

        Business rule:
        - Draft can be saved without consent.
        - Submitted intake requires both treatment and AI review consent.

        You can relax AI consent later if your product supports manual-only review.
        """
        if self.status == "submitted":
            if not self.consent_to_treatment:
                raise ValueError(
                    "consent_to_treatment is required when submitting an intake"
                )

            if not self.consent_to_ai_review:
                raise ValueError(
                    "consent_to_ai_review is required when submitting an intake"
                )

        return self


class IntakeCreate(IntakeBase):
    """
    Request schema for creating a patient intake.

    Used by:
    POST /api/v1/intakes

    Required:
    - patient_id
    - chief_complaint

    Optional:
    - symptoms
    - vitals
    - history
    - notes
    - consent fields
    """

    patient_uid: str = Field(..., description="Patient UID for whom the intake is submitted.", examples=["PAT-000001"],)

    chief_complaint: str = Field(
        ...,
        min_length=3,
        max_length=500,
        description="Main reason for the patient's visit.",
        examples=["Fever and sore throat"],
    )


class IntakeUpdate(BaseModel):
    """
    Request schema for partially updating an intake.

    Used by:
    PATCH /api/v1/intakes/{intake_id}

    Important:
    - All fields are optional.
    - Only provided fields are updated.
    - This supports low-latency partial updates.
    """

    chief_complaint: str | None = Field(default=None, min_length=3, max_length=500)
    symptoms: str | None = None
    symptom_duration: str | None = Field(default=None, max_length=100)
    symptom_onset_date: date | None = None
    symptom_severity: str | None = None
    pain_score: int | None = Field(default=None, ge=0, le=10)

    current_medications: str | None = None
    allergies: str | None = None
    past_medical_history: str | None = None
    surgical_history: str | None = None
    family_history: str | None = None
    social_history: str | None = None

    vitals_json: dict[str, Any] | None = None
    additional_notes: str | None = None

    consent_to_treatment: bool | None = None
    consent_to_ai_review: bool | None = None
    status: str | None = None

    @field_validator(
        "chief_complaint",
        "symptoms",
        "symptom_duration",
        "symptom_severity",
        "current_medications",
        "allergies",
        "past_medical_history",
        "surgical_history",
        "family_history",
        "social_history",
        "additional_notes",
        mode="before",
    )
    @classmethod
    def normalize_blank_strings(cls, value: str | None) -> str | None:
        """
        Convert blank update strings to None.

        Why:
        - If frontend sends an empty string, we store NULL instead of useless text.
        """
        if value is None:
            return None

        if isinstance(value, str):
            cleaned_value = value.strip()
            return cleaned_value or None

        return value

    @field_validator("symptom_severity")
    @classmethod
    def validate_symptom_severity(cls, value: str | None) -> str | None:
        """
        Validate severity during update.
        """
        if value is None:
            return None

        normalized_value = value.lower().strip()

        if normalized_value not in VALID_SYMPTOM_SEVERITIES:
            raise ValueError(
                "symptom_severity must be one of: mild, moderate, severe, critical"
            )

        return normalized_value

    @field_validator("status")
    @classmethod
    def validate_status(cls, value: str | None) -> str | None:
        """
        Validate status during update.
        """
        if value is None:
            return None

        normalized_value = value.lower().strip()

        if normalized_value not in VALID_INTAKE_STATUSES:
            raise ValueError(
                "status must be one of: draft, submitted, reviewed, cancelled"
            )

        return normalized_value

    @field_validator("symptom_onset_date")
    @classmethod
    def validate_symptom_onset_date(cls, value: date | None) -> date | None:
        """
        Prevent future symptom onset dates during update.
        """
        if value is not None and value > date.today():
            raise ValueError("symptom_onset_date cannot be in the future")

        return value


class IntakeRead(IntakeBase):
    """
    Response schema returned by intake APIs.

    Used by:
    - POST /api/v1/intakes
    - GET /api/v1/intakes/{intake_id}
    - PATCH /api/v1/intakes/{intake_id}

    `from_attributes=True` allows Pydantic to read SQLAlchemy ORM objects.
    """

    model_config = ConfigDict(from_attributes=True)

    id: UUID
    patient_id: UUID
    created_by_user_id: UUID | None = None
    submitted_at: datetime | None = None
    created_at: datetime
    updated_at: datetime | None = None


class IntakeListResponse(BaseModel):
    """
    Paginated response schema for intake listing.

    Used by:
    GET /api/v1/intakes

    Why:
    - Avoids returning raw arrays only.
    - Allows frontend to build pagination easily.
    """

    total: int
    limit: int
    offset: int
    items: list[IntakeRead]