"""
Patient intake database model.

This module defines the SQLAlchemy ORM model for patient intake submissions.

The intake record captures symptoms, clinical context, consent, vitals, and
workflow status before the consultation begins.
"""

import uuid
from datetime import date, datetime

from sqlalchemy import (Boolean, CheckConstraint, Date, DateTime, ForeignKey, Index, Integer, String, Text, func,)
from sqlalchemy.dialects.postgresql import JSONB, UUID
from sqlalchemy.orm import Mapped, mapped_column, relationship
from app.db.base_class import Base


class PatientIntake(Base):
    """
    ORM entity for the `patient_intakes` table.

    Purpose:
    - Store patient-submitted intake information.
    - Link every intake to one registered patient.
    - Capture symptoms, medical history, vitals, and consent.
    - Support workflow status such as draft, submitted, consultation_in_progress, consulted, cancelled.

    Design notes:
    - `vitals_json` uses PostgreSQL JSONB for flexibility.
    - `status` avoids many boolean workflow flags.
    - `submitted_at` is nullable because drafts may not be submitted yet.
    """

    __tablename__ = "patient_intakes"

    __table_args__ = (
        CheckConstraint(
            "pain_score IS NULL OR (pain_score >= 0 AND pain_score <= 10)",
            name="ck_patient_intakes_pain_score_range",
        ),
        CheckConstraint(
            "status IN ('draft', 'submitted', 'consultation_in_progress', 'consulted', 'cancelled')",
            name="ck_patient_intakes_status_allowed",
        ),
        CheckConstraint(
            "symptom_severity IS NULL OR symptom_severity IN "
            "('mild', 'moderate', 'severe', 'critical')",
            name="ck_patient_intakes_symptom_severity_allowed",
        ),
        Index("idx_patient_intakes_patient_id", "patient_id"),
        Index("idx_patient_intakes_status", "status"),
        Index("idx_patient_intakes_submitted_at", "submitted_at"),
        Index("idx_patient_intakes_created_at", "created_at"),
    )

    id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True),
        primary_key=True,
        default=uuid.uuid4,
        comment="Primary unique identifier for the intake record.",
    )

    patient_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True),
        ForeignKey("patients.id", ondelete="CASCADE"),
        nullable=False,
        comment="Patient linked to this intake record.",
    )

    created_by_user_id: Mapped[uuid.UUID | None] = mapped_column(
        UUID(as_uuid=True),
        ForeignKey("users.id", ondelete="SET NULL"),
        nullable=True,
        comment="User or staff member who created the intake record.",
    )

    chief_complaint: Mapped[str] = mapped_column(
        String(500),
        nullable=False,
        comment="Main reason for the patient's visit.",
    )

    symptoms: Mapped[str | None] = mapped_column(
        Text,
        nullable=True,
        comment="Detailed symptoms described by the patient.",
    )

    symptom_duration: Mapped[str | None] = mapped_column(
        String(100),
        nullable=True,
        comment="Duration of symptoms, for example 3 days or 1 week.",
    )

    symptom_onset_date: Mapped[date | None] = mapped_column(
        Date,
        nullable=True,
        comment="Approximate date when symptoms started.",
    )

    symptom_severity: Mapped[str | None] = mapped_column(
        String(20),
        nullable=True,
        comment="Symptom severity: mild, moderate, severe, or critical.",
    )

    pain_score: Mapped[int | None] = mapped_column(
        Integer,
        nullable=True,
        comment="Patient-reported pain score from 0 to 10.",
    )

    current_medications: Mapped[str | None] = mapped_column(
        Text,
        nullable=True,
        comment="Current medications being taken by the patient.",
    )

    allergies: Mapped[str | None] = mapped_column(
        Text,
        nullable=True,
        comment="Known allergies.",
    )

    past_medical_history: Mapped[str | None] = mapped_column(
        Text,
        nullable=True,
        comment="Past medical history or chronic conditions.",
    )

    surgical_history: Mapped[str | None] = mapped_column(
        Text,
        nullable=True,
        comment="Previous surgeries or procedures.",
    )

    family_history: Mapped[str | None] = mapped_column(
        Text,
        nullable=True,
        comment="Relevant family medical history.",
    )

    social_history: Mapped[str | None] = mapped_column(
        Text,
        nullable=True,
        comment="Lifestyle and social history relevant to care.",
    )

    vitals_json: Mapped[dict | None] = mapped_column(
        JSONB,
        nullable=True,
        comment="Flexible vitals payload such as BP, pulse, temperature, SpO2.",
    )

    additional_notes: Mapped[str | None] = mapped_column(
        Text,
        nullable=True,
        comment="Additional patient or staff notes.",
    )

    consent_to_treatment: Mapped[bool] = mapped_column(
        Boolean,
        nullable=False,
        default=False,
        comment="Whether patient consented to treatment.",
    )

    consent_to_ai_review: Mapped[bool] = mapped_column(
        Boolean,
        nullable=False,
        default=False,
        comment="Whether patient consented to AI-assisted review.",
    )

    status: Mapped[str] = mapped_column(
        String(50),
        nullable=False,
        default="submitted",
        comment="Workflow status: draft, submitted, consultation_in_progress, consulted, or cancelled.",
    )

    submitted_at: Mapped[datetime | None] = mapped_column(
        DateTime(timezone=True),
        nullable=True,
        comment="Timestamp when intake was submitted.",
    )

    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True),
        server_default=func.now(),
        nullable=False,
        comment="Record creation timestamp.",
    )

    updated_at: Mapped[datetime | None] = mapped_column(
        DateTime(timezone=True),
        server_default=func.now(),
        onupdate=func.now(),
        nullable=True,
        comment="Record last update timestamp.",
    )

    patient = relationship(
        "Patient",
        back_populates="intakes",
    )

    def __repr__(self) -> str:
        """
        Return a developer-friendly representation for logs/debugging.
        """
        return (
            f"<PatientIntake(id={self.id}, "
            f"patient_id={self.patient_id}, status={self.status})>"
        )