"""
Service layer for patient intake workflows.

This module contains business rules for patient intake submission.

Service responsibilities:
- Validate patient existence.
- Enforce workflow rules.
- Manage transaction commit/rollback.
- Convert database/repository results into API-safe errors.
- Coordinate repository calls.
"""

from datetime import UTC, datetime
from uuid import UUID

from fastapi import HTTPException, status
from sqlalchemy.exc import IntegrityError, SQLAlchemyError
from sqlalchemy.ext.asyncio import AsyncSession
from app.modules.patients.models import Patient
from app.modules.intake.models import PatientIntake
from app.modules.intake.repository import PatientIntakeRepository
from app.modules.intake.schemas import IntakeCreate, IntakeListResponse, IntakeRead, IntakeUpdate
from app.modules.patients.repository import PatientRepository
from app.modules.users.models import User
from app.modules.auth.dependencies import require_roles

class PatientIntakeService:
    """
    Business service for patient intake operations.

    This class sits between router and repository.

    Router handles HTTP.
    Repository handles DB queries.
    Service handles business rules.
    """

    LOCKED_STATUSES = {"consultation_in_progress","consulted", "cancelled"}

    def __init__(self, db: AsyncSession) -> None:
        """
        Initialize service with database session and repositories.

        Args:
            db: Active SQLAlchemy AsyncSession.
        """
        self.db = db
        self.intake_repository = PatientIntakeRepository(db)
        self.patient_repository = PatientRepository(db)

    async def create_intake(self, intake_data: IntakeCreate, current_user: User) -> PatientIntake:
        """
        Create a new patient intake.

        Business rules:
        - Patient must exist.
        - submitted_at is set only when status is submitted.
        - Transaction is committed only after successful insert.

        Args:
            intake_data: Validated intake creation payload.

        Returns:
            Created PatientIntake ORM object.

        Raises:
            HTTPException:
                404 if patient does not exist.
                409 if database constraint fails.
                500 for unexpected database failures.
        """

        patient = await self._get_patient_by_uid_or_404(intake_data.patient_uid)
        self._ensure_patient_belongs_to_user_clinic(patient, current_user)

        if patient.clinic_id != current_user.clinic_id:
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail="Patient does not belong to the user's clinic",
            )
       

        # one active submitted intake per patient rule.
        if intake_data.status == "submitted":
            submitted_count = await self.intake_repository.count(
                patient_id=patient.id,
                status="submitted",
            )

            if submitted_count > 0:
                raise HTTPException(
                    status_code=status.HTTP_409_CONFLICT,
                    detail="Patient already has an active submitted intake",
                )

        submitted_at = self._get_submission_timestamp(intake_data.status)

        try:
            intake = await self.intake_repository.create(
                intake_data,
                patient_id=patient.id,
                submitted_by=current_user.id,
                submitted_at=submitted_at,
            )

            await self.db.commit()
            await self.db.refresh(intake)

            return intake

        except IntegrityError as exc:
            await self.db.rollback()
            raise HTTPException(
                status_code=status.HTTP_409_CONFLICT,
                detail="Unable to create intake due to database constraint violation",
            ) from exc

        except SQLAlchemyError as exc:
            await self.db.rollback()
            raise HTTPException(
                status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                detail="Database error occurred while creating patient intake",
            ) from exc

    async def get_intake(self, intake_id: UUID, current_user: User) -> PatientIntake:
        """
        Get a single intake by ID.

        Args:
            intake_id: Intake UUID.
            current_user: Current authenticated user.

        Returns:
            Matching PatientIntake ORM object.

        Raises:
            HTTPException: 404 if intake is not found.
        """
        intake = await self.intake_repository.get_by_id(intake_id)
        if intake is None:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail="Patient intake not found",
            )

        patient = await self.patient_repository.get_by_id(intake.patient_id)
        if patient is None or patient.clinic_id != current_user.clinic_id:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail="Patient intake not found",
            )

        return intake

    async def list_intakes(
        self,
        *,
        patient_id: UUID | None = None,
        intake_status: str | None = None,
        current_user: User = None,
        limit: int = 50,
        offset: int = 0,
        
    ) -> IntakeListResponse:
        """
        Return paginated intake records.

        Args:
            patient_id: Optional patient filter.
            intake_status: Optional workflow status filter.
            limit: Page size.
            offset: Offset for pagination.

        Returns:
            IntakeListResponse containing total count and items.
        """
        print(f"Listing intakes for clinic {current_user.clinic_id}")
        total = await self.intake_repository.count(
            patient_id=patient_id,
            clinic_id=current_user.clinic_id,
            status=intake_status,
        )

        items = await self.intake_repository.list(
            patient_id=patient_id,
            clinic_id=current_user.clinic_id,
            status=intake_status,
            limit=limit,
            offset=offset,
        )

        return IntakeListResponse(
            total=total,
            limit=limit,
            offset=offset,
            items=[IntakeRead.model_validate(item) for item in items],
        )

    async def update_intake(
        self,
        intake_id: UUID,
        update_data: IntakeUpdate,
        current_user: User,
    ) -> PatientIntake:
        """
        Partially update an intake record.

        Business rules:
        - Intake must exist.
        - Intake cannot be updated once consultation is in progress, consulted, or cancelled.
        - Reviewed/cancelled intake cannot be updated.
        - submitted_at is set when status changes to submitted.
        - Only provided fields are updated.

        Args:
            intake_id: Intake UUID.
            update_data: Validated partial update payload.
            current_user: Current authenticated user.
        Returns:
            Updated PatientIntake ORM object.
        """
        intake = await self.get_intake(intake_id, current_user)
        await self._ensure_intake_belongs_to_user_clinic(intake, current_user)

        patient = await self.patient_repository.get_by_id(intake.patient_id)
        if patient is None or patient.clinic_id != current_user.clinic_id:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail="Patient Intake not found",
            )

        self._ensure_intake_can_be_modified(intake)

        update_payload = update_data.model_dump(exclude_unset=True)

        submitted_at = None

        if update_payload.get("status") == "submitted" and intake.submitted_at is None:
            submitted_at = datetime.now(UTC)

        try:
            updated_intake = await self.intake_repository.update(
                intake,
                update_data,
                submitted_at=submitted_at,
            )

            await self.db.commit()
            await self.db.refresh(updated_intake)

            return updated_intake

        except IntegrityError as exc:
            await self.db.rollback()
            raise HTTPException(
                status_code=status.HTTP_409_CONFLICT,
                detail="Unable to update intake due to database constraint violation",
            ) from exc

        except SQLAlchemyError as exc:
            await self.db.rollback()
            raise HTTPException(
                status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                detail="Database error occurred while updating patient intake",
            ) from exc

    async def cancel_intake(self, intake_id: UUID, current_user: User) -> PatientIntake:
        """
        Cancel an intake without physically deleting it.

        Business rules:
        - Intake must exist.
        - Reviewed intake cannot be cancelled.
        - Already cancelled intake returns safely.

        Args:
            intake_id: Intake UUID.

        Returns:
            Cancelled PatientIntake ORM object.
        """
        intake = await self.get_intake(intake_id, current_user)

        if intake.status in {"consultation_in_progress", "consulted"}:
            raise HTTPException(
                status_code=status.HTTP_409_CONFLICT,
                detail=f"Intake with status : {intake.status} cannot be cancelled",
            )
        
        patient = await self.patient_repository.get_by_id(intake.patient_id)
        if patient is None or patient.clinic_id != current_user.clinic_id:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail="Patient Intake not found",
            )

        if intake.status == "cancelled":
            return intake

        try:
            cancelled_intake = await self.intake_repository.soft_cancel(intake)

            await self.db.commit()
            await self.db.refresh(cancelled_intake)

            return cancelled_intake

        except SQLAlchemyError as exc:
            await self.db.rollback()
            raise HTTPException(
                status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                detail="Database error occurred while cancelling patient intake",
            ) from exc

    async def _get_patient_by_uid_or_404(self, patient_uid: str) -> Patient:
        """
        Verify that the patient exists before creating an intake.

        Why:
        - Prevents orphan intake records.
        - Gives clean 404 response before DB foreign key failure.
        """

        patient = await self.patient_repository.get_by_patient_uid(patient_uid)

        if patient is None:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail="Patient not found",
            )
        return patient
        
    async def _ensure_patient_exists(self, patient_id: UUID) -> None:
        """
        Verify that the patient exists before creating an intake.

        Why:
        - Prevents orphan intake records.
        - Gives clean 404 response before DB foreign key failure.
        """
        patient = await self.patient_repository.get_by_id(patient_id)

        if patient is None:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail="Patient not found",
            )

    def _ensure_intake_can_be_modified(self, intake: PatientIntake) -> None:
        """
        Prevent updates to terminal workflow states.

        Locked states:
        - consultation_in_progress
        - consulted
        - cancelled

        Why:
        - Reviewed intake may already be used by doctor or AI workflow.
        - Cancelled intake should remain immutable for audit consistency.
        """
        if intake.status in self.LOCKED_STATUSES:
            raise HTTPException(
                status_code=status.HTTP_409_CONFLICT,
                detail=f"Intake with status '{intake.status}' cannot be modified",
            )

    def _ensure_patient_belongs_to_user_clinic(self, patient: Patient, current_user: User) -> None:
        """
        Ensure the patient belongs to the same clinic as the current user.

        Why:
        - Enforces multi-tenancy data isolation.
        - Prevents cross-clinic data access.

        Raises:
            HTTPException: 403 if patient does not belong to user's clinic.
        """
        if patient.clinic_id != current_user.clinic_id:
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail="Patient does not belong to the user's clinic",
            )
        
    
    async def _ensure_intake_belongs_to_user_clinic(self, intake: PatientIntake, current_user: User) -> None:
        """
        Ensure the intake's patient belongs to the same clinic as the current user.

        Why:
        - Enforces multi-tenancy data isolation.
        - Prevents cross-clinic data access.

        Raises:
            HTTPException: 403 if intake's patient does not belong to user's clinic.
        """
        patient = await self.patient_repository.get_by_id(intake.patient_id)

        if patient is None or patient.clinic_id != current_user.clinic_id:
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail="Intake does not belong to the user's clinic",
            )
    @staticmethod
    def _get_submission_timestamp(intake_status: str) -> datetime | None:
        """
        Return submission timestamp for submitted intake.

        Args:
            intake_status: Intake workflow status.

        Returns:
            Current UTC datetime if submitted, else None.
        """
        if intake_status == "submitted":
            return datetime.now(UTC)

        return None