"""
Service layer for consultation workflow.

This module owns consultation business rules:
- Resolve patient_uid to patient UUID.
- Find latest submitted intake.
- Prevent duplicate consultation for the same intake.
- Create consultation.
- Move intake status through consultation workflow.
"""

from uuid import UUID
import uuid
from fastapi import HTTPException, status
from sqlalchemy.exc import IntegrityError, SQLAlchemyError
from sqlalchemy.ext.asyncio import AsyncSession
from app.modules.consultations.models import Consultation
from app.modules.consultations.repository import ConsultationRepository
from app.modules.consultations.schemas import (ConsultationCreate, ConsultationListResponse, ConsultationRead, ConsultationUpdate,
                                               ConsultationDashboardResponse, ConsultationDraftUpdate)
from app.modules.intake.repository import PatientIntakeRepository
from app.modules.patients.repository import PatientRepository
from app.modules.users.models import User
from app.modules.patients.schemas import PatientRead
from app.modules.intake.schemas import IntakeRead
from app.modules.audit.models import AuditLog

class ConsultationService:
    """ 
    Business service for doctor consultation workflow.

    Router handles HTTP.
    Repository handles SQL.
    Service handles business rules and workflow transitions.
    """

    TERMINAL_STATUSES = {"completed", "cancelled"}
    STRUCTURED_NOTE_FIELDS = {
        "clinical_notes",
        "diagnosis_notes",
        "examination_notes",
        "doctor_observations",
        "assessment",
        "diagnosis",
        "treatment_plan",
        "follow_up_instructions",
        "consultation_summary",
    }


    def __init__(self, db: AsyncSession) -> None:
        self.db = db
        self.consultation_repository = ConsultationRepository(db)
        self.patient_repository = PatientRepository(db)
        self.intake_repository = PatientIntakeRepository(db)

    def _extract_consultation_note_values(self, consultation: Consultation) -> dict:
        """Capture current consultation note values for audit logging."""
        return {
            field_name: getattr(consultation, field_name, None)
            for field_name in self.STRUCTURED_NOTE_FIELDS
        }
    
    def _apply_consultation_note_updates(
        self,
        consultation: Consultation,
        update_data: ConsultationDraftUpdate,
    ) -> list[str]:
        """Apply provided draft/complete note fields to consultation."""
        update_payload = update_data.model_dump(exclude_unset=True)

        updated_fields: list[str] = []

        for field_name, field_value in update_payload.items():
            if field_name in self.STRUCTURED_NOTE_FIELDS:
                setattr(consultation, field_name, field_value)
                updated_fields.append(field_name)

        return updated_fields  

    async def get_patient_dashboard(
        self,
        patient_uid: str,
        current_user: User,
    ) -> ConsultationDashboardResponse:
        """Build the doctor consultation dashboard payload for one patient.

        The endpoint is clinic-isolated and returns everything needed to open
        the consultation workspace in one backend call.
        """

        patient = await self.patient_repository.get_by_patient_uid(
            patient_uid.strip().upper()
        )

        if patient is None:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail="Patient not found",
            )

        if patient.clinic_id != current_user.clinic_id:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail="Patient not found",
            )
        print(f"Patient {patient.id} found for patient_uid {patient_uid}")

        latest_intake = await self.intake_repository.get_latest_submitted_by_patient_id(patient.id)
        active_consultation = await self.consultation_repository.get_active_by_patient_id(patient.id)
        consultation_history = await self.consultation_repository.list_by_patient_id(
            patient_id=patient.id,
            clinic_id=current_user.clinic_id,
            limit=10,
        )

        await self._write_audit_log(
            action="CONSULTATION_DASHBOARD_VIEWED",
            entity_id=str(patient.id),
            entity_type="patient",
            current_user=current_user,
            new_value={"patient_uid": str(patient.patient_uid)},
        )
        await self.db.commit()

        return ConsultationDashboardResponse(
            patient_profile=PatientRead.model_validate(patient),
            latest_intake=IntakeRead.model_validate(latest_intake) if latest_intake else None,
            active_consultation=(
                ConsultationRead.model_validate(active_consultation)
                if active_consultation
                else None
            ),
            consultation_history=[
                ConsultationRead.model_validate(item) for item in consultation_history
            ],
            ai_summary=self._build_placeholder_ai_summary(latest_intake),
            ai_follow_up_questions=self._build_placeholder_follow_up_questions(latest_intake),
        )

    async def create_consultation(
            self,
            consultation_data: ConsultationCreate,
            current_user: User,
        ) -> Consultation:
        """
        Create a consultation from the patient's latest submitted intake.
        """

        print(f"Roles for current user: {[role.name for role in current_user.roles]}")

        patient = await self.patient_repository.get_by_patient_uid(
            consultation_data.patient_uid
        )

        if patient is None:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail="Patient not found",
            )

        if patient.clinic_id != current_user.clinic_id:
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail="Patient does not belong to the same clinic as the doctor",
            )

        intake = await self.intake_repository.get_latest_submitted_by_patient_id(
            patient.id
        )

        if intake is None:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail="No submitted intake found for this patient",
            )

        existing_consultation = await self.consultation_repository.get_by_intake_id(
            intake.id
        )

        if existing_consultation is not None:
            raise HTTPException(
                status_code=status.HTTP_409_CONFLICT,
                detail="Consultation already exists for this intake",
            )

        consultation_number = await self._generate_consultation_number()

        try:
            consultation = await self.consultation_repository.create(
                consultation_number=consultation_number,
                clinic_id=patient.clinic_id,
                patient_id=patient.id,
                intake_id=intake.id,
                doctor_user_id=current_user.id if "doctor" in [role.name for role in current_user.roles] else None,
            )
 
            await self.intake_repository.update_status(
                intake,
                "consultation_in_progress",
            )

            # Audit log for consultation creation
            await self._write_audit_log(
                action="CONSULTATION_CREATED",
                entity_id=consultation.id,
                entity_type="consultation",
                current_user=current_user,
                new_value={
                    "consultation_number": consultation.consultation_number,
                    "patient_uid": str(patient.patient_uid),
                    "intake_id": str(intake.id),
                },
            )

            await self.db.commit()
            await self.db.refresh(consultation)

            return consultation

        except IntegrityError as exc:
            await self.db.rollback()
            raise HTTPException(
                status_code=status.HTTP_409_CONFLICT,
                detail=(
                    "Unable to create consultation due to database constraint "
                    "violation"
                ),
            ) from exc

        except SQLAlchemyError as exc:
            await self.db.rollback()
            raise HTTPException(
                status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                detail=f"Database error occurred while creating consultation: {str(exc)} ",
            ) from exc

    async def get_consultation(
        self,
        consultation_number: str,
        *,
        current_user: User,
    ) -> Consultation:
        """
        Fetch one consultation by public consultation number.
        """

        consultation = (
            await self.consultation_repository.get_by_consultation_number(
                consultation_number
            )
        )

        if consultation is None:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail="Consultation not found",
            )
        
        self._ensure_consultation_belongs_to_user_clinic(consultation, current_user)

        return consultation

    async def list_consultations(
            self,
            *,
            patient_uid: str | None = None,
            status_filter: str | None = None,
            limit: int = 50,
            offset: int = 0,
            current_user: User,
        ) -> ConsultationListResponse:
        """
        Return paginated consultations.

        Supports optional patient_uid and status filters.
        """

        patient_id: UUID | None = None

        if patient_uid is not None:
            patient = await self.patient_repository.get_by_patient_uid(
                patient_uid.strip().upper()
            )

            if patient is None:
                raise HTTPException(
                    status_code=status.HTTP_404_NOT_FOUND,
                    detail="Patient not found",
                )

            patient_id = patient.id

        total = await self.consultation_repository.count(
            patient_id=patient_id,
            clinic_id=current_user.clinic_id,
            status=status_filter,
        )

        items = await self.consultation_repository.list_consultation(
            patient_id=patient_id,
            clinic_id=current_user.clinic_id,
            status=status_filter,
            limit=limit,
                offset=offset,
        )

        return ConsultationListResponse(
            total=total,
            limit=limit,
            offset=offset,
            items=[ConsultationRead.model_validate(item) for item in items],
        )

    async def update_consultation(
        self,
        consultation_number: str,
        update_data: ConsultationUpdate,
        current_user: User,
    ) -> Consultation:
        """
        Update consultation clinical details or workflow status.

        Rules:
        - completed/cancelled consultations cannot be modified.
        - when consultation becomes completed, intake becomes consulted.
        - when consultation becomes cancelled, intake becomes submitted again.
        """

        consultation = await self.get_consultation(consultation_number, current_user=current_user)

        self._ensure_consultation_can_be_modified(consultation)

        update_payload = update_data.model_dump(exclude_unset=True)

        requested_status = update_payload.get("status")

        try:
            updated_consultation = await self.consultation_repository.update(
                consultation,
                update_data,
            )

            if requested_status == "completed":
                intake = await self.intake_repository.get_by_id(
                    consultation.intake_id
                )

                if intake is not None:
                    await self.intake_repository.update_status(
                        intake,
                        "consulted",
                    )

            elif requested_status == "cancelled":
                intake = await self.intake_repository.get_by_id(
                    consultation.intake_id
                )

                if intake is not None:
                    await self.intake_repository.update_status(
                        intake,
                        "submitted",
                    )

            # Audit log for consultation update
            await self._write_audit_log(
                action="CONSULTATION_UPDATED",
                entity_id=consultation.id,
                entity_type="consultation",
                current_user=current_user,
                new_value={"status": updated_consultation.status},
            )

            await self.db.commit()
            await self.db.refresh(updated_consultation)

            return updated_consultation

        except IntegrityError as exc:
            await self.db.rollback()
            raise HTTPException(
                status_code=status.HTTP_409_CONFLICT,
                detail=(
                    "Unable to update consultation due to database constraint "
                    "violation"
                ),
            ) from exc

        except SQLAlchemyError as exc:
            await self.db.rollback()
            raise HTTPException(
                status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                detail="Database error occurred while updating consultation",
            ) from exc
        
    async def save_consultation_draft(
        self,
        consultation_number: str,
        update_data: ConsultationDraftUpdate,
        current_user: User,
    ) -> Consultation:
        """Save editable doctor notes without finalizing the consultation."""

        consultation = await self.get_consultation(consultation_number, current_user=current_user)
        self._ensure_consultation_can_be_modified(consultation)

        try:
            # old_value = {
            #     "clinical_notes": consultation.clinical_notes,
            #     "diagnosis_notes": consultation.diagnosis_notes,
            #     "status": consultation.status,
            # }

            # if update_data.clinical_notes is not None:
            #     consultation.clinical_notes = update_data.clinical_notes
            # if update_data.diagnosis_notes is not None:
            #     consultation.diagnosis_notes = update_data.diagnosis_notes

            old_value = self._extract_consultation_note_values(consultation)
            old_value["status"] = consultation.status

            updated_fields = self._apply_consultation_note_updates(
                consultation=consultation,
                update_data=update_data,
            )
            consultation.status = "draft"

            await self.db.flush()
            await self.db.refresh(consultation)
            new_value = self._extract_consultation_note_values(consultation)
            new_value["status"] = consultation.status
            new_value["updated_fields"] = updated_fields
            await self._write_audit_log(
                action="CONSULTATION_DRAFT_SAVED",
                entity_id=str(consultation.id),
                entity_type="consultation",
                current_user=current_user,
                old_value=old_value,
                new_value=new_value,
                # {
                #     "clinical_notes": consultation.clinical_notes,
                #     "diagnosis_notes": consultation.diagnosis_notes,
                #     "status": consultation.status,
                # },
            )
            await self.db.commit()
            await self.db.refresh(consultation)
            return consultation

        except SQLAlchemyError as exc:
            await self.db.rollback()
            raise HTTPException(
                status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                detail="Database error occurred while saving consultation draft",
            ) from exc

    async def complete_consultation(
        self,
        consultation_number: str,
        update_data: ConsultationDraftUpdate,
        current_user: User,
    ) -> Consultation:
        """Finalize a consultation and move the intake to consulted."""

        consultation = await self.get_consultation(consultation_number, current_user=current_user)
        self._ensure_consultation_can_be_modified(consultation)

        try:
            # old_value = {
            #     "clinical_notes": consultation.clinical_notes,
            #     "diagnosis_notes": consultation.diagnosis_notes,
            #     "status": consultation.status,
            # }

            # if update_data.clinical_notes is not None:
            #     consultation.clinical_notes = update_data.clinical_notes
            # if update_data.diagnosis_notes is not None:
            #     consultation.diagnosis_notes = update_data.diagnosis_notes

            old_value = self._extract_consultation_note_values(consultation)
            old_value["status"] = consultation.status

            updated_fields = self._apply_consultation_note_updates(
                consultation=consultation,
                update_data=update_data,
            )
            consultation.status = "completed"

            intake = await self.intake_repository.get_by_id(consultation.intake_id)
            if intake is not None:
                await self.intake_repository.update_status(intake, "consulted")

            new_value = self._extract_consultation_note_values(consultation)
            new_value["status"] = consultation.status
            new_value["updated_fields"] = updated_fields
            await self.db.flush()
            await self.db.refresh(consultation)
            await self._write_audit_log(
                action="CONSULTATION_COMPLETED",
                entity_id=consultation.id,
                entity_type="consultation",
                current_user=current_user,
                old_value=old_value,
                new_value=new_value,
            )
            await self.db.commit()
            await self.db.refresh(consultation)
            return consultation

        except SQLAlchemyError as exc:
            await self.db.rollback()
            raise HTTPException(
                status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                detail="Database error occurred while completing consultation",
            ) from exc

    async def cancel_consultation(
        self,
        consultation_number: str,
        current_user: User,
    ) -> Consultation:
        """
        Soft-cancel a consultation.

        If cancelled before completion, the intake is moved back to submitted
        so another consultation can be started later.
        """

        consultation = await self.get_consultation(consultation_number, current_user=current_user)

        if consultation.status == "completed":
            raise HTTPException(
                status_code=status.HTTP_409_CONFLICT,
                detail="Completed consultation cannot be cancelled",
            )

        if consultation.status == "cancelled":
            return consultation

        try:
            cancelled_consultation = await self.consultation_repository.soft_cancel(
                consultation
            )

            intake = await self.intake_repository.get_by_id(consultation.intake_id)

            if intake is not None:
                await self.intake_repository.update_status(
                    intake,
                    "submitted",
                )

            await self.db.commit()
            await self.db.refresh(cancelled_consultation)

            return cancelled_consultation
 
        except SQLAlchemyError as exc:
            await self.db.rollback()
            raise HTTPException(
                status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                detail="Database error occurred while cancelling consultation",
            ) from exc
        
    def _build_placeholder_ai_summary(self, intake) -> str | None:
        """Return deterministic summary until the AI provider is wired in."""

        if intake is None:
            return None

        parts = [f"Chief complaint: {intake.chief_complaint}"]
        if intake.symptoms:
            parts.append(f"Symptoms: {intake.symptoms}")
        if intake.symptom_duration:
            parts.append(f"Duration: {intake.symptom_duration}")
        if intake.symptom_severity:
            parts.append(f"Severity: {intake.symptom_severity}")
        return " | ".join(parts)

    def _build_placeholder_follow_up_questions(self, intake) -> list[str]:
        """Return safe rule-based questions until AI question generation is added."""

        if intake is None:
            return []

        questions = [
            "Have the symptoms improved, worsened, or stayed the same since intake?",
            "Are there any red-flag symptoms such as chest pain, breathing difficulty, fainting, or severe pain?",
        ]

        if not intake.allergies:
            questions.append("Does the patient have any known drug, food, or environmental allergies?")
        if not intake.current_medications:
            questions.append("Is the patient currently taking any prescription or over-the-counter medicines?")

        return questions

    @staticmethod
    def _serialize_json(data: dict | None) -> dict | None:
        """Recursively convert UUIDs and other non-serializable types to strings."""
        if data is None:
            return None
        if isinstance(data, dict):
            return {k: ConsultationService._serialize_json(v) for k, v in data.items()}
        if isinstance(data, list):
            return [ConsultationService._serialize_json(i) for i in data]
        if isinstance(data, uuid.UUID):
            return str(data)
        return data

    async def _write_audit_log(
        self,
        *,
        action: str,
        entity_type: str,
        entity_id: UUID | None,
        current_user: User,
        old_value: dict | None = None,
        new_value: dict | None = None,
    ) -> None:
        """Append an audit log record inside the current transaction."""

        self.db.add(
            AuditLog(
                user_id=current_user.id,
                clinic_id=current_user.clinic_id,
                action=action,
                entity_type=entity_type,
                entity_id=str(entity_id) if entity_id is not None else None,
                old_value_json=self._serialize_json(old_value),
                new_value_json=self._serialize_json(new_value),
            )
        )
        await self.db.flush()

    async def _generate_consultation_number(self) -> str:
        """
        Generate public consultation number.

        Current strategy:
        - Count existing consultations.
        - Add 1.
        - Format as CON-000001.

        Future improvement:
        - Replace with database sequence for concurrency safety.
        """

        total_consultations = await self.consultation_repository.count()
        next_number = total_consultations + 1

        return f"CON-{next_number:06d}"

    def _ensure_consultation_can_be_modified(
        self,
        consultation: Consultation,
    ) -> None:
        """
        Prevent modification of terminal consultation states.
        """

        if consultation.status in self.TERMINAL_STATUSES:
            raise HTTPException(
                status_code=status.HTTP_409_CONFLICT,
                detail=(
                    f"Consultation with status '{consultation.status}' "
                    "cannot be modified"
                ),
            )
        
    def _ensure_consultation_belongs_to_user_clinic(
            self,
            consultation: Consultation,
            current_user: User,
        ) -> None:
        """
        Ensure the consultation belongs to the same clinic as the doctor.

        This prevents doctors from accessing consultations of patients outside their clinic.
        """

        if consultation.clinic_id != current_user.clinic_id:
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail="Consultation does not belong to the same clinic as the doctor",
            )