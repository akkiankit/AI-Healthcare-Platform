"""
Repository layer for consultation records.

This module contains low-level database operations for Consultation.

Repository responsibilities:
- Build SQLAlchemy queries.
- Execute database operations.
- Return ORM objects or counts.

Repository should not contain business workflow decisions.
Those belong in the service layer.
"""

from uuid import UUID
from typing import List
from sqlalchemy import Select, func, select
from sqlalchemy.ext.asyncio import AsyncSession

from app.modules.consultations.models import Consultation
from app.modules.consultations.schemas import ConsultationUpdate


class ConsultationRepository:
    """
    Database repository for consultation records.

    This class isolates SQLAlchemy query logic from the service layer.

    Benefits:
    - Easier testing.
    - Cleaner business logic.
    - Reusable database operations.
    - Lower coupling between API logic and SQLAlchemy.
    """

    def __init__(self, db: AsyncSession) -> None:
        """
        Initialize repository with active database session.
        """
        self.db = db

    async def create(
        self,
        *,
        consultation_number: str,
        clinic_id: UUID,
        patient_id: UUID,
        intake_id: UUID,
        doctor_user_id: UUID | None = None,
    ) -> Consultation:
        """
        Create a consultation record.

        Notes:
        - Transaction commit is controlled by service layer.
        - Repository only persists and flushes data.
        """

        consultation = Consultation(
            consultation_number=consultation_number,
            clinic_id=clinic_id,
            patient_id=patient_id,
            intake_id=intake_id,
            doctor_user_id=doctor_user_id,
            status="in_progress",
        )

        self.db.add(consultation)

        await self.db.flush()
        await self.db.refresh(consultation)

        return consultation

    async def get_by_id(
        self,
        consultation_id: UUID,
    ) -> Consultation | None:
        """
        Fetch consultation by internal UUID.
        """

        result = await self.db.execute(
            select(Consultation).where(
                Consultation.id == consultation_id
            )
        )

        return result.scalar_one_or_none()

    async def get_by_consultation_number(
        self,
        consultation_number: str,
    ) -> Consultation | None:
        """
        Fetch consultation using public business identifier.

        Example:
            CON-000001
        """

        result = await self.db.execute(
            select(Consultation).where(
                Consultation.consultation_number == consultation_number
            )
        )

        return result.scalar_one_or_none()

    async def get_by_intake_id(
        self,
        intake_id: UUID,
    ) -> Consultation | None:
        """
        Fetch consultation associated with an intake.

        Why:
        - Enforces one-intake-to-one-consultation rule.
        """

        result = await self.db.execute(
            select(Consultation).where(
                Consultation.intake_id == intake_id
            )
        )

        return result.scalar_one_or_none()


    async def get_active_by_patient_id(
        self,
        patient_id: UUID,
    ) -> Consultation | None:
        """Fetch the latest non-terminal consultation for a patient."""

        result = await self.db.execute(
            select(Consultation)
            .where(Consultation.patient_id == patient_id)
            .where(Consultation.status.in_(["draft", "in_progress"]))
            .order_by(Consultation.consultation_date.desc())
            .limit(1)
        )

        return result.scalar_one_or_none()

    async def list_by_patient_id(
        self,
        *,
        patient_id: UUID,
        clinic_id: UUID,
        limit: int = 10,
    ) -> list[Consultation]:
        """Fetch recent consultation history for one patient in one clinic."""

        result = await self.db.execute(
            select(Consultation)
            .where(Consultation.patient_id == patient_id)
            .where(Consultation.clinic_id == clinic_id)
            .order_by(Consultation.consultation_date.desc())
            .limit(limit)
        )

        return list(result.scalars().all())

    async def list_consultation(
        self,
        *,
        patient_id: UUID | None = None,
        clinic_id: UUID | None = None,
        status: str | None = None,
        limit: int = 50,
        offset: int = 0,
    ) -> List[Consultation]:
        """
        Return paginated consultation records.
        """

        query = self._build_filtered_query(
            patient_id=patient_id,
            clinic_id=clinic_id,
            status=status,
        )

        query = (
            query.order_by(Consultation.consultation_date.desc())
            .limit(limit)
            .offset(offset)
        )

        result = await self.db.execute(query)

        return list(result.scalars().all())

    async def count(
        self,
        *,
        patient_id: UUID | None = None,
        clinic_id: UUID | None = None,
        status: str | None = None,
    ) -> int:
        """
        Count consultation records matching filters.
        """

        query = select(func.count(Consultation.id))

        if patient_id is not None:
            query = query.where(
                Consultation.patient_id == patient_id
            )

        if clinic_id is not None:
            query = query.where(
                Consultation.clinic_id == clinic_id
            )

        if status is not None:
            query = query.where(
                Consultation.status == status
            )

        result = await self.db.execute(query)

        return int(result.scalar_one())

    async def update(
        self,
        consultation: Consultation,
        update_data: ConsultationUpdate,
    ) -> Consultation:
        """
        Update consultation fields.

        Notes:
        - Only fields provided by API are updated.
        - Service layer controls workflow rules.
        """

        update_payload = update_data.model_dump(
            exclude_unset=True
        )

        for field_name, field_value in update_payload.items():
            setattr(
                consultation,
                field_name,
                field_value,
            )

        await self.db.flush()
        await self.db.refresh(consultation)

        return consultation

    async def update_status(
        self,
        consultation: Consultation,
        status: str,
    ) -> Consultation:
        """
        Update only consultation workflow status.

        Used internally by workflow transitions.
        """

        consultation.status = status

        await self.db.flush()
        await self.db.refresh(consultation)

        return consultation

    async def soft_cancel(
        self,
        consultation: Consultation,
    ) -> Consultation:
        """
        Soft cancel consultation.

        Why:
        - Preserve clinical audit history.
        - Avoid physical deletion of medical records.
        """

        consultation.status = "cancelled"

        await self.db.flush()
        await self.db.refresh(consultation)

        return consultation

    def _build_filtered_query(
        self,
        *,
        patient_id: UUID | None,
        clinic_id: UUID | None,
        status: str | None,
    ) -> Select:
        """
        Build reusable consultation filter query.

        Keeps filtering logic centralized.
        """

        query = select(Consultation)

        if patient_id is not None:
            query = query.where(
                Consultation.patient_id == patient_id
            )

        if clinic_id is not None:
            query = query.where(
                Consultation.clinic_id == clinic_id
            )

        if status is not None:
            query = query.where(
                Consultation.status == status
            )

        return query
    
    async def get_active_consultation_for_patient(
        self,
        patient_id: UUID,
        clinic_id: UUID,
    ) -> Consultation | None:
        stmt = (
            select(Consultation)
            .where(
                Consultation.patient_id == patient_id,
                Consultation.clinic_id == clinic_id,
                Consultation.status.in_(["draft", "in_progress"]),
            )
            .order_by(Consultation.created_at.desc())
            .limit(1)
        )

        result = await self.db.execute(stmt)
        return result.scalar_one_or_none()


    async def get_consultation_history_for_patient(
        self,
        patient_id: UUID,
        clinic_id: UUID,
        limit: int = 10,
    ) -> List[Consultation]:
        stmt = (
            select(Consultation)
            .where(
                Consultation.patient_id == patient_id,
                Consultation.clinic_id == clinic_id,
                Consultation.status == "completed",
            )
            .order_by(Consultation.completed_at.desc())
            .limit(limit)
        )

        result = await self.db.execute(stmt)
        return list(result.scalars().all())