"""
Consultation database model.

This model stores the doctor consultation record for a patient visit.
It links patient registration, intake details, doctor notes, diagnosis notes,
AI outputs, prescriptions, and diagnostic reports.
"""

import uuid
from datetime import datetime

from sqlalchemy import DateTime, ForeignKey, Index, String, Text, func
from sqlalchemy.dialects.postgresql import UUID
from sqlalchemy.orm import Mapped, mapped_column, relationship
from app.db.base_class import Base


class Consultation(Base):
    """
    Represents a doctor consultation session.

    Notes:
    - One patient can have many consultations.
    - Each consultation may optionally link to one intake record.
    - AI summaries, prescriptions, and diagnostic reports are linked to consultation.
    """

    __tablename__ = "consultations"

    __table_args__ = (
        Index("idx_consultations_clinic_id", "clinic_id"),
        Index("idx_consultations_patient_id", "patient_id"),
        Index("idx_consultations_doctor_user_id", "doctor_user_id"),
        Index("idx_consultations_status", "status"),
        Index("idx_consultations_date", "consultation_date"),
    )

    id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True),
        primary_key=True,
        default=uuid.uuid4,
        comment="Primary unique identifier for consultation record.",
    )

    clinic_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True),
        ForeignKey("clinics.id", ondelete="CASCADE"),
        nullable=False,
        comment="Clinic where this consultation belongs.",
    )

    patient_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True),
        ForeignKey("patients.id", ondelete="CASCADE"),
        nullable=False,
        comment="Patient linked to this consultation.",
    )

    consultation_number: Mapped[str] = mapped_column(
        String(30),
        nullable=False,
        unique=True,
        index=True,
        comment="Public business identifier for the consultation, e.g. CON-000001.",
    )

    doctor_user_id: Mapped[uuid.UUID | None] = mapped_column(
        UUID(as_uuid=True),
        ForeignKey("users.id", ondelete="SET NULL"),
        nullable=True,
        comment="Doctor responsible for this consultation.",
    )

    intake_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True),
        ForeignKey("patient_intakes.id", ondelete="RESTRICT"), # Prevent deletion of intake if linked to consultation
        nullable=False,
        comment="Submitted Patient intake record used for this consultation.",
    )

    status: Mapped[str] = mapped_column(
        String(50),
        nullable=False,
        default="in_progress",
        comment="Consultation status: in_progress, completed, cancelled.",
    )

    diagnosis_notes: Mapped[str | None] = mapped_column(
        Text,
        nullable=True,
        comment="Doctor-entered diagnosis or clinical impression notes.",
    )

    clinical_notes: Mapped[str | None] = mapped_column(
        Text,
        nullable=True,
        comment="Doctor's consultation notes and observations.",
    )

    examination_notes: Mapped[str | None] = mapped_column(Text, nullable=True)
    assessment: Mapped[str | None] = mapped_column(Text, nullable=True)
    treatment_plan: Mapped[str | None] = mapped_column(Text, nullable=True)
    follow_up_instructions: Mapped[str | None] = mapped_column(Text, nullable=True)
    consultation_summary: Mapped[str | None] = mapped_column(Text, nullable=True)

    consultation_date: Mapped[datetime] = mapped_column(
        DateTime(timezone=True),
        server_default=func.now(),
        nullable=False,
        comment="Date and time when consultation started.",
    )

    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True),
        server_default=func.now(),
        nullable=False,
        comment="Record creation timestamp.",
    )

    updated_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True),
        server_default=func.now(),
        onupdate=func.now(),
        nullable=False,
        comment="Record last update timestamp.",
    )

    patient = relationship(
        "Patient",
        back_populates="consultations",
    )

    def __repr__(self) -> str:
        """
        Return developer-friendly representation for debugging/logging.
        """
        return (
            f"<Consultation(id={self.id}, "
            f"consultation_number={self.consultation_number}, "
            f"patient_id={self.patient_id}, "
            f"status={self.status})>"
        )
