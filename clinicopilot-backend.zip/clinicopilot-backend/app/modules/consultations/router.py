"""
API router for consultation workflow.

This module exposes HTTP endpoints for doctor consultation operations.

Router responsibilities:
- Define API paths and HTTP methods.
- Validate request/response schemas.
- Inject database session dependency.
- Delegate business logic to ConsultationService.

Business rules stay in the service layer.
Database queries stay in the repository layer.
"""

from fastapi import APIRouter, Depends, Query, status
from sqlalchemy.ext.asyncio import AsyncSession
from app.db.session import get_db
from app.modules.auth.dependencies import require_permissions
from app.modules.consultations.schemas import (ConsultationCreate, ConsultationListResponse, ConsultationRead, ConsultationUpdate, 
        ConsultationDashboardResponse, ConsultationDraftUpdate)
from app.modules.consultations.service import ConsultationService
from app.modules.users.models import User

router = APIRouter(prefix="/consultations", tags=["Consultations"],)


@router.get(
    "/dashboard/patient/{patient_uid}",
    response_model=ConsultationDashboardResponse,
    status_code=status.HTTP_200_OK,
    summary="Load doctor consultation dashboard",
)
async def get_patient_consultation_dashboard(
    patient_uid: str,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(require_permissions("consultation:dashboard")),
) -> ConsultationDashboardResponse:
    """Return patient, intake, active consultation, history, and AI placeholders."""
    service = ConsultationService(db)
    return await service.get_patient_dashboard(patient_uid, current_user)


@router.post(
    "",
    response_model=ConsultationRead,
    status_code=status.HTTP_201_CREATED,
    summary="Create consultation",
    description=(
        "Create a consultation from the patient's latest submitted intake. "
        "The request uses patient_uid, and the backend resolves the patient, "
        "clinic, and submitted intake internally."
    ),
)
async def create_consultation(
        consultation_data: ConsultationCreate,
        db: AsyncSession = Depends(get_db),
        current_user: User = Depends(require_permissions("consultation:create")),
    ) -> ConsultationRead:
    """
    Create a consultation for the latest submitted intake of a patient.

    Workflow:
    - Resolve patient_uid.
    - Find latest submitted intake.
    - Prevent duplicate consultation for the same intake.
    - Create consultation.
    - Move intake status to consultation_in_progress.
    """
    service = ConsultationService(db)

    consultation = await service.create_consultation(consultation_data, current_user)

    return ConsultationRead.model_validate(consultation)


@router.get(
    "",
    response_model=ConsultationListResponse,
    status_code=status.HTTP_200_OK,
    summary="List consultations",
    description=(
        "Return paginated consultations. Supports optional filtering by "
        "patient_uid and consultation status."
    ),
)
async def list_consultations(
    patient_uid: str | None = Query(
        default=None,
        description="Optional public patient identifier filter.",
        examples=["PAT-000001"],
    ),
    status_filter: str | None = Query(
        default=None,
        alias="status",
        description="Optional consultation status filter.",
        examples=["in_progress"],
    ),
    limit: int = Query(
        default=50,
        ge=1,
        le=100,
        description="Maximum number of records to return.",
    ),
    offset: int = Query(
        default=0,
        ge=0,
        description="Pagination offset.",
    ),
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(require_permissions("consultation:list")),
) -> ConsultationListResponse:
    """
    List consultations with pagination and optional filters.
    """
    service = ConsultationService(db)

    return await service.list_consultations(
        patient_uid=patient_uid,
        status_filter=status_filter,
        limit=limit,
        offset=offset,
        current_user=current_user,
    )


@router.get(
    "/{consultation_number}",
    response_model=ConsultationRead,
    status_code=status.HTTP_200_OK,
    summary="Get consultation by consultation number",
    description="Fetch a single consultation using its public consultation number.",
)
async def get_consultation(
    consultation_number: str,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(require_permissions("consultation:read")),
) -> ConsultationRead:
    """
    Fetch a consultation by public business identifier.

    Example:
    - CON-000001
    """
    service = ConsultationService(db)

    consultation = await service.get_consultation(
        consultation_number.strip().upper(),
        current_user=current_user
    )

    return ConsultationRead.model_validate(consultation)


@router.patch(
    "/{consultation_number}",
    response_model=ConsultationRead,
    status_code=status.HTTP_200_OK,
    summary="Update consultation",
    description=(
        "Partially update consultation clinical notes, diagnosis notes, "
        "or workflow status."
    ),
)
async def update_consultation(
        consultation_number: str,
        update_data: ConsultationUpdate,
        db: AsyncSession = Depends(get_db),
        current_user: User = Depends(require_permissions("consultation:update")),
    ) -> ConsultationRead:
    """
    Update a consultation.

    Important workflow:
    - status=completed moves intake to consulted.
    - status=cancelled moves intake back to submitted.
    """
    service = ConsultationService(db)

    consultation = await service.update_consultation(
        consultation_number.strip().upper(),
        update_data,
        current_user=current_user,
    )

    return ConsultationRead.model_validate(consultation)


@router.patch(
    "/{consultation_number}/draft",
    response_model=ConsultationRead,
    status_code=status.HTTP_200_OK,
    summary="Save consultation draft",
)
async def save_consultation_draft(
    consultation_number: str,
    update_data: ConsultationDraftUpdate,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(require_permissions("consultation:update")),
) -> ConsultationRead:
    """Save editable consultation notes without finalizing."""
    service = ConsultationService(db)
    consultation = await service.save_consultation_draft(
        consultation_number.strip().upper(),
        update_data,
        current_user=current_user,
    )
    return ConsultationRead.model_validate(consultation)


@router.patch(
    "/{consultation_number}/complete",
    response_model=ConsultationRead,
    status_code=status.HTTP_200_OK,
    summary="Finalize consultation",
)
async def complete_consultation(
    consultation_number: str,
    update_data: ConsultationDraftUpdate,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(require_permissions("consultation:complete")),
) -> ConsultationRead:
    """Finalize consultation and mark linked intake as consulted."""
    service = ConsultationService(db)
    consultation = await service.complete_consultation(
        consultation_number.strip().upper(),
        update_data,
        current_user=current_user,
    )
    return ConsultationRead.model_validate(consultation)


@router.delete(
    "/{consultation_number}",
    response_model=ConsultationRead,
    status_code=status.HTTP_200_OK,
    summary="Cancel consultation",
    description=(
        "Soft-cancel a consultation. The record is preserved for audit history. "
        "If the consultation was in progress, the related intake is moved back "
        "to submitted."
    ),
)
async def cancel_consultation(
    consultation_number: str,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(require_permissions("consultation:cancel")),
) -> ConsultationRead:
    """
    Soft-cancel a consultation using consultation_number.
    """
    service = ConsultationService(db)

    consultation = await service.cancel_consultation(
        consultation_number.strip().upper(),
        current_user=current_user,
    )

    return ConsultationRead.model_validate(consultation)