"""
Consultation API schemas.

This module defines request and response contracts for the doctor consultation
workflow.

Design principle:
- External APIs use public identifiers such as patient_uid and consultation_number.
- Internal database relationships use UUID foreign keys.
"""

from datetime import datetime, date
from uuid import UUID
from pydantic import BaseModel, ConfigDict, Field, field_validator
from app.modules.patients.schemas import PatientRead
from app.modules.intake.schemas import IntakeRead

VALID_CONSULTATION_STATUSES = {"in_progress", "completed", "cancelled",}


class ConsultationCreate(BaseModel):
    """
    Request schema for creating a consultation.

    The frontend sends patient_uid only.

    Backend resolves:
    - patient_uid -> patient.id
    - patient.clinic_id -> clinic_id
    - latest submitted intake -> intake.id
    """

    patient_uid: str = Field(
        ...,
        min_length=3,
        max_length=50,
        description="Public patient identifier.",
        examples=["PAT-000001"],
    )

    @field_validator("patient_uid", mode="before")
    @classmethod
    def normalize_patient_uid(cls, value: str) -> str:
        """
        Normalize patient UID before service-layer lookup.
        """
        if not isinstance(value, str):
            raise ValueError("patient_uid must be a string")

        normalized_value = value.strip().upper()

        if not normalized_value:
            raise ValueError("patient_uid cannot be empty")

        return normalized_value


class ConsultationUpdate(BaseModel):
    """
    Request schema for partially updating consultation details.

    Used by:
    PATCH /api/v1/consultations/{consultation_number}

    Allowed updates:
    - clinical_notes
    - diagnosis_notes
    - status

    Status changes drive workflow synchronization with patient intake.
    """

    clinical_notes: str | None = Field(
        default=None,
        max_length=5000,
        description="Doctor's consultation notes and clinical observations.",
    )

    diagnosis_notes: str | None = Field(
        default=None,
        max_length=5000,
        description="Doctor-entered diagnosis or clinical impression notes.",
    )

    status: str | None = Field(
        default=None,
        description="Consultation workflow status.",
        examples=["completed"],
    )

    examination_notes: str | None = None
    assessment: str | None = None
    treatment_plan: str | None = None
    follow_up_instructions: str | None = None
    consultation_summary: str | None = None

    @field_validator("clinical_notes", "diagnosis_notes", "status", mode="before")
    @classmethod
    def normalize_text_fields(cls, value: str | None) -> str | None:
        """
        Trim whitespace and convert blank strings to None.

        Why:
        - Prevents meaningless empty strings in the database.
        - Keeps API behavior consistent with intake schemas.
        """
        if value is None:
            return None

        if not isinstance(value, str):
            return value

        normalized_value = value.strip()
        return normalized_value or None

    @field_validator("status")
    @classmethod
    def validate_status(cls, value: str | None) -> str | None:
        """
        Validate consultation workflow status.
        """
        if value is None:
            return None

        normalized_value = value.lower().strip()

        if normalized_value not in VALID_CONSULTATION_STATUSES:
            raise ValueError(
                "status must be one of: in_progress, completed, cancelled"
            )

        return normalized_value


class ConsultationRead(BaseModel):
    """
    Response schema returned by consultation APIs.

    from_attributes=True allows Pydantic to serialize SQLAlchemy ORM objects.
    """

    model_config = ConfigDict(from_attributes=True)

    id: UUID
    consultation_number: str
    clinic_id: UUID
    patient_id: UUID
    doctor_user_id: UUID | None = None
    intake_id: UUID

    status: str
    diagnosis_notes: str | None = None
    clinical_notes: str | None = None

    examination_notes: str | None = None
    assessment: str | None = None
    treatment_plan: str | None = None
    follow_up_instructions: str | None = None
    consultation_summary: str | None = None

    consultation_date: datetime
    created_at: datetime
    updated_at: datetime | None = None


class ConsultationListResponse(BaseModel):
    """
    Paginated consultation list response.

    Used by:
    GET /api/v1/consultations
    """

    total: int
    limit: int
    offset: int
    items: list[ConsultationRead]


class ConsultationDashboardResponse(BaseModel):
    """Single payload used by the doctor consultation dashboard.

    This keeps the frontend from making multiple calls when a doctor opens a
    patient consultation workspace.
    """

    patient_profile: PatientRead
    latest_intake: IntakeRead | None = None
    active_consultation: ConsultationRead | None = None
    consultation_history: list[ConsultationRead]
    ai_summary: str | None = None
    ai_follow_up_questions: list[str] = Field(default_factory=list)


class ConsultationDraftUpdate(BaseModel):
    """Request schema for saving a doctor consultation draft."""

    clinical_notes: str | None = Field(default=None, max_length=5000)
    diagnosis_notes: str | None = Field(default=None, max_length=5000)
    examination_notes: str | None = Field(default=None, max_length=5000)
    assessment: str | None = Field(default=None, max_length=5000)
    treatment_plan: str | None = Field(default=None, max_length=5000)
    follow_up_instructions: str | None = Field(default=None, max_length=5000)
    consultation_summary: str | None = Field(default=None, max_length=5000)

    @field_validator("clinical_notes", "diagnosis_notes", mode="before")
    @classmethod
    def normalize_text_fields(cls, value: str | None) -> str | None:
        if value is None:
            return None
        if not isinstance(value, str):
            return value
        normalized_value = value.strip()
        return normalized_value or None

class DashboardPatientProfile(BaseModel):
    patient_uid: str
    first_name: str
    last_name: str
    phone: str | None = None
    gender: str | None = None
    date_of_birth: date | None = None


class DashboardLatestIntake(BaseModel):
    intake_number: str | None = None
    chief_complaint: str | None = None
    symptoms: list[str] | None = None
    vitals: dict | None = None
    created_at: datetime | None = None


class DashboardConsultationSummary(BaseModel):
    consultation_number: str
    status: str
    clinical_notes: str | None = None
    diagnosis_notes: str | None = None
    created_at: datetime
    completed_at: datetime | None = None


class DoctorDashboardResponse(BaseModel):
    patient_profile: DashboardPatientProfile
    latest_intake: DashboardLatestIntake | None = None
    active_consultation: DashboardConsultationSummary | None = None
    consultation_history: list[DashboardConsultationSummary]
    ai_summary: str | None = None
    ai_follow_up_questions: list[str] = [] 

class ConsultationCompleteRequest(BaseModel):
    clinical_notes: str | None = None
    diagnosis_notes: str | None = None
    examination_notes: str | None = None
    assessment: str | None = None
    treatment_plan: str | None = None
    follow_up_instructions: str | None = None
    consultation_summary: str | None = None