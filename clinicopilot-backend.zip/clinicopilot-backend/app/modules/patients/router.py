"""
Patient API router.

This module exposes HTTP endpoints for patient registration, lookup, listing,
updates, and soft deletion.
"""

from uuid import UUID

from fastapi import APIRouter, Depends, HTTPException, Query, status
from sqlalchemy.ext.asyncio import AsyncSession
from app.db.session import get_db
from app.modules.patients.schemas import (PatientCreate, PatientListResponse, PatientRead, PatientUpdate, PatientSearchResponse,)
from app.modules.patients.service import PatientService
from app.modules.auth.dependencies import require_permissions
from app.modules.users.models import User

router = APIRouter(prefix="/patients",tags=["Patients"],)


@router.post("",response_model=PatientRead,status_code=status.HTTP_201_CREATED,summary="Register a new patient",)
async def register_patient(
        patient_data: PatientCreate,
        db: AsyncSession = Depends(get_db),
        current_user: User = Depends(require_permissions("patient:create")),
    ) -> PatientRead:
    """
    Register a new patient.

    Generates a platform-level unique patient ID and persists the patient record.
    """
    try:
        service = PatientService(db)
        return await service.register_patient(patient_data, current_user=current_user)

    except ValueError as exc:
        await db.rollback()
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=str(exc),
        ) from exc

    except Exception as exc:
        await db.rollback()
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            # detail="Failed to register patient",
            detail=f"Failed to register patient: {type(exc).__name__}: {str(exc)}"
        ) from exc


@router.get("/search",response_model=list[PatientSearchResponse],status_code=status.HTTP_200_OK,summary="Search patients by UID, name, or phone number",)
async def search_patients(
    query: str = Query(..., min_length=2, description="Patient UID, name, or phone number"),
    db: AsyncSession = Depends(get_db),
    limit: int = Query(20, ge=1, le=100, description="Maximum number of results to return"),
    current_user: User = Depends(require_permissions("patient:search")),
):
    service = PatientService(db)
    return await service.search_patients(
        current_user=current_user,
        query=query,
        limit=limit,
    )

@router.get("",response_model=PatientListResponse,summary="List active patients",)
async def list_patients(
        limit: int = Query(default=20, ge=1, le=100),
        offset: int = Query(default=0, ge=0),
        db: AsyncSession = Depends(get_db),
        current_user: User = Depends(require_permissions("patient:list")),
    ) -> PatientListResponse:
    """
    Return paginated active patients.
    """
    service = PatientService(db)
    return await service.list_patients(current_user=current_user, limit=limit, offset=offset)

@router.get("/uid/{patient_uid}",response_model=PatientRead, summary="Get patient by unique patient ID",)
async def get_patient_by_uid(
        patient_uid: str,
        db: AsyncSession = Depends(get_db),
        current_user: User = Depends(require_permissions("patient:read")),
    ) -> PatientRead:
    """
    Return one active patient by platform-generated patient UID.
    """
    try:
        service = PatientService(db)
        return await service.get_patient_by_uid(patient_uid, current_user=current_user)

    except ValueError as exc:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=str(exc),
        ) from exc


@router.get("/{patient_id}",response_model=PatientRead,summary="Get patient by ID",)
async def get_patient(
        patient_id: UUID,
        db: AsyncSession = Depends(get_db),
        current_user: User = Depends(require_permissions("patient:read")),
    ) -> PatientRead:
    """
    Return one active patient by database UUID.
    """
    try:
        service = PatientService(db)
        return await service.get_patient(patient_id, current_user=current_user)

    except ValueError as exc:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=str(exc),
        ) from exc


@router.patch("/{patient_id}",response_model=PatientRead,summary="Update patient",)
async def update_patient(
    patient_id: UUID,
        patient_data: PatientUpdate,
        db: AsyncSession = Depends(get_db),
        current_user: User = Depends(require_permissions("patient:update")),
    ) -> PatientRead:
    """
    Partially update an active patient record.
    """
    try:
        service = PatientService(db)
        return await service.update_patient(patient_id, patient_data, current_user=current_user)

    except ValueError as exc:
        await db.rollback()
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=str(exc),
        ) from exc

    except Exception as exc:
        await db.rollback()
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to update patient",
        ) from exc

@router.delete("/{patient_id}",response_model=PatientRead,summary="Deactivate patient",)
async def deactivate_patient(
    patient_id: UUID,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(require_permissions("patient:delete")),
    ) -> PatientRead:   
    """
    Soft delete a patient by marking the patient inactive.
    """
    try:
        service = PatientService(db)
        return await service.deactivate_patient(patient_id, current_user=current_user)

    except ValueError as exc:
        await db.rollback()
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=str(exc),
        ) from exc

    except Exception as exc:
        await db.rollback()
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to deactivate patient",
        ) from exc
    
