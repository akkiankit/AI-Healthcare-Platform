
# app/modules/patients/service.py
"""
Patient service.

Contains business logic for patient registration and patient workflows.
"""

from uuid import UUID

from sqlalchemy.ext.asyncio import AsyncSession
# from app.modules.clinics.repository import ClinicRepository
from app.modules.patients.models import Patient
from app.modules.patients.repository import PatientRepository
from app.modules.patients.schemas import (PatientCreate,PatientListResponse,PatientRead,PatientUpdate,)
from fastapi import HTTPException, status
from app.modules.users.models import User


class PatientService:
    """Business service for patient workflows."""

    def __init__(self, db: AsyncSession) -> None:
        """Initialize service with DB session and repository."""
        self.db = db
        self.repository = PatientRepository(db)
        # self.clinic_repository = ClinicRepository(db)

    async def register_patient(self, patient_data: PatientCreate,
                               *,
                                current_user: User) -> PatientRead:
        """
            Register a new patient using clinic name and patient details.
        
            flow:
            1. Resolve clinic name to clinic_id.
            2. Check for existing patient with same email or phone number in the clinic.
            3. Generate patient UID.
            4. Create patient record.
            5. Return created patient details.
        """

        # clinic = await self.clinic_repository.get_by_name(patient_data.clinic_name)

        # if clinic is None:
        #     raise ValueError("Clinic not found")
    
        # if clinic.id != current_user.clinic_id:
        #     raise HTTPException(
        #         status_code=status.HTTP_403_FORBIDDEN,
        #         detail="You do not have permission to register patients for this clinic",
        #     )

        if current_user.clinic_id is None:
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail="You do not have permission to register patients without an associated clinic",
            )
        
        clinic_id = current_user.clinic_id
        
        duplicate_exists = await self.repository.exist_by_email_or_phone(
            clinic_id=clinic_id,
            email = str(patient_data.email) if patient_data.email else None,
            phone_number=patient_data.phone_number,
        )

        if duplicate_exists:
            raise ValueError("Patient already exist in this clinic with same email or phone number")
        patient_uid = await self._generate_patient_uid()

        patient = await self.repository.create(
                    patient_data=patient_data,
                    patient_uid=patient_uid,
                    clinic_id=clinic_id,
                )

        await self.db.commit()
        return PatientRead.model_validate(patient)

    async def get_patient(self, patient_id: UUID, *, current_user: User) -> PatientRead:
        """Return one active patient by UUID."""
        patient = await self.repository.get_by_id(patient_id)

        if patient is None or patient.clinic_id != current_user.clinic_id:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail="Patient not found",
            )

        return PatientRead.model_validate(patient)

    async def get_patient_by_uid(self, patient_uid: str, *, current_user: User) -> PatientRead:
        """Return one active patient by generated patient UID."""
        patient = await self.repository.get_by_patient_uid(patient_uid)

        if patient is None or patient.clinic_id != current_user.clinic_id:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail="Patient not found",
            )

        return PatientRead.model_validate(patient)

    async def list_patients(self,*, current_user: User, limit: int = 20, offset: int = 0) -> PatientListResponse:
        """Return paginated active patients."""
        patients, total = await self.repository.list_patient(clinic_id=current_user.clinic_id, limit=limit, offset=offset)

        return PatientListResponse(
                    patients=[PatientRead.model_validate(patient) for patient in patients],
                    total=total,
                    limit=limit,
                    offset=offset,
                )

    async def update_patient(self, patient_id: UUID, patient_data: PatientUpdate, *, current_user: User) -> PatientRead:
        """Update an active patient record."""
        patient = await self.repository.get_by_id(patient_id)

        if patient is None or patient.clinic_id != current_user.clinic_id:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail="Patient not found",
            )

        updated_patient = await self.repository.update(patient, patient_data)
       

        await self.db.commit()
        return PatientRead.model_validate(updated_patient)

    async def deactivate_patient(self, patient_id: UUID, *, current_user: User) -> PatientRead:
        """Soft delete an active patient."""
        patient = await self.repository.get_by_id(patient_id)

        if patient is None or patient.clinic_id != current_user.clinic_id:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail="Patient not found",
            )

        deleted_patient = await self.repository.soft_delete(patient)

        await self.db.commit()
        return PatientRead.model_validate(deleted_patient)

    async def _generate_patient_uid(self) -> str:
        """
        Generate MVP patient UID.

        Current format:
        PAT-000001

        Later replace with DB sequence for high-concurrency production use.
        """
        total = await self.repository.count_active()
        return f"PAT-{total + 1:06d}"
    
    async def search_patients(
        self,
        current_user: User,
        query: str,
        limit: int = 20,
    ) -> list[Patient]:
        
        """
        Search active patients by UID, name, email or phone number within the current user's clinic.
        Used by Doctor Consultation Dashboard before opening the patient workspace
        """

        cleaned_query = query.strip() if query else ""

        if len(cleaned_query) < 2:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Search query must be at least 2 characters",
            )
        
        safe_limit = min(max(limit, 1), 50)  # Ensure limit is between 1 and 50
    
        return await self.repository.search_patients(
            clinic_id=current_user.clinic_id,
            query=cleaned_query,
            limit=safe_limit,
        )




# FAILED tests/api/test_intake_api.py::test_create_intake_with_valid_patient_uid_returns_201 - assert 403 == 201
# FAILED tests/api/test_intake_api.py::test_list_intakes_returns_200 - assert 403 == 201
# FAILED tests/api/test_intake_api.py::test_get_intake_by_id_returns_200 - assert 403 == 201
# FAILED tests/api/test_intake_api.py::test_patch_intake_returns_200 - assert 403 == 201
# FAILED tests/api/test_intake_api.py::test_delete_intake_soft_cancels_record - assert 403 == 201
# FAILED tests/api/test_intake_api.py::test_patch_cancelled_intake_returns_409 - assert 403 == 201
# FAILED tests/api/test_intake_api.py::test_second_submitted_intake_for_same_patient_returns_409 - assert 403 == 201