

# app/modules/patients/repository.py
"""
Patient repository.

Contains async database operations for patients.
"""

from uuid import UUID
from typing import List, Optional
from sqlalchemy import func, select, or_
from sqlalchemy.ext.asyncio import AsyncSession
from app.modules.patients.models import Patient
from app.modules.patients.schemas import PatientCreate, PatientUpdate


class PatientRepository:
    """Database access layer for patient records."""

    def __init__(self, db: AsyncSession) -> None:
        """Initialize repository with active async DB session."""
        self.db = db

    async def create(self, patient_data: PatientCreate, patient_uid: str, clinic_id: UUID) -> Patient:
        """Create and flush a new patient record."""
        # patient_payload = patient_data.model_dump(exclude={"clinic_name"})
        patient_payload = patient_data.model_dump()
        patient = Patient(**patient_payload, 
                          clinic_id=clinic_id, 
                          patient_uid=patient_uid
                          )

        self.db.add(patient)
        await self.db.flush()
        await self.db.refresh(patient)
        return patient

    async def get_by_id(self, patient_id: UUID) -> Patient | None:
        """Fetch one active patient by UUID."""
        result = await self.db.execute(
            select(Patient).where(
                Patient.id == patient_id,
                Patient.is_active.is_(True),
            )
        )
        return result.scalar_one_or_none()

    async def get_by_patient_uid(self, patient_uid: str) -> Patient | None:
        """Fetch one active patient by generated patient UID."""
        result = await self.db.execute(
            select(Patient).where(
                Patient.patient_uid == patient_uid,
                Patient.is_active.is_(True),
            )
        )
        return result.scalar_one_or_none()

    async def count_active(self, *, clinic_id: UUID | None = None) -> int:
        """Return total active patient count."""
        query = select(func.count()).select_from(Patient).where(Patient.is_active.is_(True))

        if clinic_id is not None:
            query = query.where(Patient.clinic_id == clinic_id)
        result = await self.db.execute(query)
        return int(result.scalar_one())

    async def list_patient(self, *, clinic_id: UUID | None = None, limit: int = 20, offset: int = 0) -> tuple[List[Patient], int]:
        """
        Return paginated active patients and total count.
        If clinic_id is provided, only return patients for that clinic. Otherwise, return patients across all clinics (for admin-level users).
        """
        
        query = select(Patient).where(Patient.is_active.is_(True))

        if clinic_id is not None:
            query = query.where(Patient.clinic_id == clinic_id)

        patients_result = await self.db.execute(
            query.order_by(Patient.created_at.desc()).limit(limit).offset(offset)
        )

        total = await self.count_active(clinic_id=clinic_id)
        return list(patients_result.scalars().all()), total

    async def update(self, patient: Patient, patient_data: PatientUpdate) -> Patient:
        """Apply PATCH-style updates to an existing patient."""
        update_data = patient_data.model_dump(exclude_unset=True)

        for field_name, field_value in update_data.items():
            setattr(patient, field_name, field_value)

        await self.db.flush()
        await self.db.refresh(patient)
        return patient

    async def soft_delete(self, patient: Patient) -> Patient:
        """Deactivate patient without physically deleting clinical data."""
        patient.is_active = False

        await self.db.flush()
        await self.db.refresh(patient)
        return patient
    
    async def exist_by_email_or_phone(self, clinic_id:UUID, email: str | None, phone_number: str | None,) -> bool:
        """Check whether an active patient already exists in the same clinic using email or phone number. 
        this prevents duplicate patient registration"""

        filters = [Patient.clinic_id == clinic_id, Patient.is_active.is_(True)]
        duplicate_filters = []
        if email:
            duplicate_filters.append(Patient.email == email)
        
        if phone_number:
            duplicate_filters.append(Patient.phone_number== phone_number)
        
        if not duplicate_filters:
            return False
        
        statement= select(Patient.id).where(
            *filters, 
            or_(*duplicate_filters),
            ).limit(1)

        result = await self.db.execute(statement=statement)
        return result.scalar_one_or_none() is not None
    
    async def search_patients(self, clinic_id: UUID, query: str, limit: int = 20,) -> List[Patient]:
        """"
        Search active patients by UID, name, email or phone number within a clinic.
        """
        search_value = f"%{query.strip()}%"

        stmt = (
            select(Patient)
            .where(
                Patient.clinic_id == clinic_id,
                Patient.is_active.is_(True),
                or_(
                    Patient.patient_uid.ilike(search_value),
                    Patient.first_name.ilike(search_value),
                    Patient.last_name.ilike(search_value),
                    Patient.phone_number.ilike(search_value),
                    Patient.email.ilike(search_value),
                ),
            )
            .order_by(Patient.created_at.desc())
            .limit(limit)
        )

        result = await self.db.execute(stmt)
        return list(result.scalars().all())
    
    