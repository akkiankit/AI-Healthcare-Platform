# app/modules/patients/schemas.py
"""
Patient API schemas.

These Pydantic models define request and response contracts for patient-related
API operations. They validate external input before it reaches the service layer
and serialize ORM objects safely for API responses.
"""

from datetime import date, datetime
from uuid import UUID

from pydantic import BaseModel, ConfigDict, EmailStr, Field, field_validator


class PatientBase(BaseModel):
    """
    Shared patient fields used by create and read schemas.

    Keep this class limited to fields that are common across multiple patient
    API contracts.
    """

    first_name: str = Field(..., min_length=1, max_length=100)
    last_name: str = Field(..., min_length=1, max_length=100)
    date_of_birth: date
    gender: str | None = Field(default=None, max_length=50)

    phone_number: str | None = Field(default=None, max_length=30)
    email: EmailStr | None = None

    address_line_1: str | None = Field(default=None, max_length=255)
    address_line_2: str | None = Field(default=None, max_length=255)
    city: str | None = Field(default=None, max_length=100)
    state: str | None = Field(default=None, max_length=100)
    postal_code: str | None = Field(default=None, max_length=20)
    country: str | None = Field(default=None, max_length=100)

    emergency_contact_name: str | None = Field(default=None, max_length=150)
    emergency_contact_phone: str | None = Field(default=None, max_length=30)

    @field_validator(
        "first_name",
        "last_name",
        "gender",
        "phone_number",
        "address_line_1",
        "address_line_2",
        "city",
        "state",
        "postal_code",
        "country",
        "emergency_contact_name",
        "emergency_contact_phone",
        mode="before",
    )
    @classmethod
    def normalize_text_fields(cls, value: str | None) -> str | None:
        """
        Normalize string input by trimming whitespace.

        Empty strings are converted to None so downstream layers can treat
        missing optional values consistently.
        """
        if value is None:
            return None

        if not isinstance(value, str):
            return value

        normalized_value = value.strip()
        return normalized_value or None

    @field_validator("date_of_birth")
    @classmethod
    def validate_date_of_birth(cls, value: date) -> date:
        """
        Reject future birth dates.

        This prevents invalid patient records from entering the database and
        avoids repeated validation in service/repository layers.
        """
        if value > date.today():
            raise ValueError("date_of_birth cannot be in the future")

        return value


class PatientCreate(PatientBase):
    """
    Request schema for creating a patient.

    clinic_id is required because every patient must belong to a clinic.
    """

    # clinic_id: UUID
    # clinic_name: str = Field(..., min_length=1, max_length=150)


class PatientUpdate(BaseModel):
    """
    Request schema for updating patient information.

    All fields are optional to support PATCH-style partial updates.
    """

    first_name: str | None = Field(default=None, min_length=1, max_length=100)
    last_name: str | None = Field(default=None, min_length=1, max_length=100)
    date_of_birth: date | None = None
    gender: str | None = Field(default=None, max_length=50)

    phone_number: str | None = Field(default=None, max_length=30)
    email: EmailStr | None = None

    address_line_1: str | None = Field(default=None, max_length=255)
    address_line_2: str | None = Field(default=None, max_length=255)
    city: str | None = Field(default=None, max_length=100)
    state: str | None = Field(default=None, max_length=100)
    postal_code: str | None = Field(default=None, max_length=20)
    country: str | None = Field(default=None, max_length=100)

    emergency_contact_name: str | None = Field(default=None, max_length=150)
    emergency_contact_phone: str | None = Field(default=None, max_length=30)

    is_active: bool | None = None

    @field_validator(
        "first_name",
        "last_name",
        "gender",
        "phone_number",
        "address_line_1",
        "address_line_2",
        "city",
        "state",
        "postal_code",
        "country",
        "emergency_contact_name",
        "emergency_contact_phone",
        mode="before",
    )
    @classmethod
    def normalize_text_fields(cls, value: str | None) -> str | None:
        """
        Normalize optional update fields.

        Blank strings are treated as None, which keeps partial update behavior
        predictable and prevents storing meaningless whitespace.
        """
        if value is None:
            return None

        if not isinstance(value, str):
            return value

        normalized_value = value.strip()
        return normalized_value or None

    @field_validator("date_of_birth")
    @classmethod
    def validate_date_of_birth(cls, value: date | None) -> date | None:
        """
        Reject future birth dates when date_of_birth is included in an update.
        """
        if value is not None and value > date.today():
            raise ValueError("date_of_birth cannot be in the future")

        return value


class PatientRead(PatientBase):
    """
    Response schema returned by patient APIs.

    from_attributes=True allows Pydantic to serialize SQLAlchemy ORM objects
    without manual dict conversion.
    """

    model_config = ConfigDict(from_attributes=True)

    id: UUID
    patient_uid: str
    clinic_id: UUID
    is_active: bool
    created_at: datetime
    updated_at: datetime | None = None
 

class PatientListResponse(BaseModel):
    """
    Paginated patient list response.

    Used by list/search APIs to return patient records with pagination metadata.
    """

    patients: list[PatientRead]
    total: int = Field(..., ge=0)
    limit: int = Field(..., ge=1, le=100)
    offset: int = Field(..., ge=0)

class PatientSearchResponse(BaseModel):
    id: UUID
    patient_uid: str
    first_name: str
    last_name: str
    email: EmailStr | None = None
    phone_number: str | None = None
    gender: str | None = None
    date_of_birth: date | None = None
    is_active: bool

    model_config = ConfigDict(from_attributes=True)