# app/api/v1/router.py
"""
API v1 router registry.

This module registers all versioned API routers under `/api/v1`.

Every feature module should expose its own router and be included here.
"""

from fastapi import APIRouter
from app.modules.auth.router import router as auth_router
from app.modules.users.router import router as users_router
from app.modules.patients.router import router as patient_router
from app.modules.intake.router import router as intake_router
from app.modules.consultations.router import router as consultations_router

api_v1_router = APIRouter()
api_v1_router.include_router(auth_router)
api_v1_router.include_router(users_router)
api_v1_router.include_router(patient_router)
api_v1_router.include_router(intake_router)
api_v1_router.include_router(consultations_router)
