import os
from sqlalchemy.ext.asyncio import AsyncSession, async_sessionmaker, create_async_engine
from sqlalchemy.engine import URL
from dotenv import load_dotenv
load_dotenv()

# Read credentials from environment variables
PGHOST = os.getenv("PGHOST")
PGUSER =os.getenv("PGUSER")
PGPORT =os.getenv("PGPORT")
PGDATABASE = os.getenv("PGDATABASE")
PGPASSWORD =os.getenv("PGPASSWORD")

if not PGPASSWORD:
    raise ValueError("PGPASSWORD environment variable not set")

DATABASE_URL = URL.create(
    drivername="postgresql+asyncpg",
    # drivername="postgresql+psycopg2",
    username=PGUSER,
    password=PGPASSWORD,
    host=PGHOST,
    port=int(PGPORT),
    database=PGDATABASE,
)

engine = create_async_engine(
    DATABASE_URL,
    echo=False,
    pool_pre_ping=True,
)

AsyncSessionLocal = async_sessionmaker(
    bind=engine,
    class_=AsyncSession,
    expire_on_commit=False,
)


async def get_db():
    async with AsyncSessionLocal() as session:
        yield session


async def test_connection():
    """Test PostgreSQL connection"""
    try:
        from sqlalchemy import text
        async with engine.connect() as conn:
            result = await conn.execute(text("SELECT 1"))
            print("✓ Connection successful!")
            print(f"  Result: {result.fetchone()}")
            return True
    except Exception as e:
        print(f"✗ Connection failed: {e}")
        return False
    finally:
        await engine.dispose()


# if __name__ == "__main__":
#     import asyncio
#     asyncio.run(test_connection())
