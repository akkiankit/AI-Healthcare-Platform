"""
model registry.

All SQLAlchemy ORM models must be imported here so alembic can detect them during migration autogeneration.
"""


# from sqlalchemy.orm import DeclarativeBase


# class Base(DeclarativeBase):
#     """
#     Base class for all SQLALchemy ORM models.
#     """
#     pass

# import all models below.
# don't remove these imports. ALembic needs them for model discovery
from app.db.base_class import Base
from app.modules.clinics.models import Clinic
from app.modules.users.models import Role, Permission, RolePermission, User
from app.modules.patients.models import Patient
from app.modules.intake.models import PatientIntake
from app.modules.consultations.models import Consultation
from app.modules.ai.models import AIOutput
from app.modules.prescriptions.models import Prescription
from app.modules.diagnostics.models import DiagnosticReport
from app.modules.audit.models import AuditLog

__all__ = ["Base"]