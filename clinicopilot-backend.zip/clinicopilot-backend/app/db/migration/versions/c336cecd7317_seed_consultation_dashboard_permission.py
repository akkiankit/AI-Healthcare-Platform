"""seed consultation dashboard permission

Revision ID: c336cecd7317
Revises: ead5fcc283be
Create Date: 2026-06-11 01:09:56.712718

"""
from typing import Sequence, Union

from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision: str = 'c336cecd7317'
down_revision: Union[str, Sequence[str], None] = 'ead5fcc283be'
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


CONSULTATION_PERMISSIONS = [
    ("consultation:create", "Create consultations"),
    ("consultation:list", "List consultations"),
    ("consultation:read", "Read consultation details"),
    ("consultation:update", "Update consultation notes and draft"),
    ("consultation:cancel", "Cancel consultations"),
    ("consultation:complete", "Finalize consultations"),
    ("consultation:dashboard", "Open doctor consultation dashboard"),
]

DOCTOR_PERMISSIONS = [
    "consultation:create",
    "consultation:list",
    "consultation:read",
    "consultation:update",
    "consultation:complete",
    "consultation:dashboard",
]

CLINIC_ADMIN_PERMISSIONS = [code for code, _description in CONSULTATION_PERMISSIONS]


def upgrade() -> None:
    """Seed consultation permissions and assign them to doctor and clinic_admin."""

    for code, description in CONSULTATION_PERMISSIONS:
        op.execute(
            f"""
            INSERT INTO permissions (id, code, description)
            VALUES (gen_random_uuid(), '{code}', '{description}')
            ON CONFLICT (code) DO NOTHING
            """
        )

    for role_name, permission_codes in {
        "doctor": DOCTOR_PERMISSIONS,
        "clinic_admin": CLINIC_ADMIN_PERMISSIONS,
    }.items():
        for code in permission_codes:
            op.execute(
                f"""
                INSERT INTO role_permissions (id, role_id, permission_id)
                SELECT gen_random_uuid(), r.id, p.id
                FROM roles r
                JOIN permissions p ON p.code = '{code}'
                WHERE r.name = '{role_name}'
                ON CONFLICT (role_id, permission_id) DO NOTHING
                """
            )


def downgrade() -> None:
    """Remove consultation permissions and related role assignments."""

    permission_codes = "', '".join(code for code, _description in CONSULTATION_PERMISSIONS)

    op.execute(
        f"""
        DELETE FROM role_permissions
        WHERE permission_id IN (
            SELECT id FROM permissions
            WHERE code IN ('{permission_codes}')
        )
        """
    )

    op.execute(
        f"""
        DELETE FROM permissions
        WHERE code IN ('{permission_codes}')
        """
    )