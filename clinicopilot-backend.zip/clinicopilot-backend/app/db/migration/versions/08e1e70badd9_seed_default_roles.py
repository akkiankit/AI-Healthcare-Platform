"""seed_default_roles

Revision ID: 08e1e70badd9
Revises: bfda1272de2e
Create Date: 2026-06-03 02:29:51.066521

"""
from typing import Sequence, Union

from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision: str = '08e1e70badd9'
down_revision: Union[str, Sequence[str], None] = 'bfda1272de2e'
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    """Upgrade schema."""
    pass


def downgrade() -> None:
    """Downgrade schema."""
    pass
