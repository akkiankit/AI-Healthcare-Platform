"""seed patient search permission

Revision ID: 9e5de4023eac
Revises: c336cecd7317
Create Date: 2026-06-13 02:22:35.713339

"""
from typing import Sequence, Union

from alembic import op
import sqlalchemy as sa
from sqlalchemy.sql import text


# revision identifiers, used by Alembic.
revision: str = '9e5de4023eac'
down_revision: Union[str, Sequence[str], None] = 'c336cecd7317'
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None

PATIENT_PERMISSIONS = [
    ("patient:create", "Create patients"),
    ("patient:list", "List patients"),
    ("patient:read", "Read patient details"),
    ("patient:update", "Update patients"),
    ("patient:search", "Search patients from doctor dashboard"),
]

CLINIC_ADMIN_PERMISSIONS = [
    "patient:create",
    "patient:list",
    "patient:read",
    "patient:update",
    "patient:search",
]

DOCTOR_PERMISSIONS = [
    "patient:read",
    "patient:search",
]

ASSISTANT_PERMISSIONS = [
    "patient:create",
    "patient:list",
    "patient:read",
    "patient:update",
    "patient:search",
]


def upgrade() -> None:
    """Seed patient permissions and assign them to allowed roles."""

    for code, description in PATIENT_PERMISSIONS:
        op.execute(
            f"""
            INSERT INTO permissions (id, code, description)
            VALUES (gen_random_uuid(), '{code}', '{description}')
            ON CONFLICT (code) DO NOTHING
            """
        )

    role_permission_map = {
        "clinic_admin": CLINIC_ADMIN_PERMISSIONS,
        "doctor": DOCTOR_PERMISSIONS,
        "assistant": ASSISTANT_PERMISSIONS,
    }

    for role_name, permission_codes in role_permission_map.items():
        for code in permission_codes:
            op.execute(
                f"""
                INSERT INTO role_permissions (id, role_id, permission_id)
                SELECT gen_random_uuid(), r.id, p.id
                FROM roles r
                JOIN permissions p ON p.code = '{code}'
                WHERE r.name = '{role_name}'
                ON CONFLICT (role_id, permission_id) DO NOTHING
                """
            )


def downgrade() -> None:
    """Remove seeded patient dashboard permissions and role assignments."""

    permission_codes = "', '".join(code for code, _description in PATIENT_PERMISSIONS)

    op.execute(
        f"""
        DELETE FROM role_permissions
        WHERE permission_id IN (
            SELECT id FROM permissions
            WHERE code IN ('{permission_codes}')
        )
        """
    )

    op.execute(
        f"""
        DELETE FROM permissions
        WHERE code IN ('{permission_codes}')
        """
    )