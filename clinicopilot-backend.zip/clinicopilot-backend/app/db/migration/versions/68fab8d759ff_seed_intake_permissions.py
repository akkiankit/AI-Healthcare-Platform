"""seed intake permissions

Revision ID: 68fab8d759ff
Revises: 9e5de4023eac
Create Date: 2026-06-13 02:44:38.031447

"""
from typing import Sequence, Union

from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision: str = '68fab8d759ff'
down_revision: Union[str, Sequence[str], None] = '9e5de4023eac'
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None

INTAKE_PERMISSIONS = [
    ("intake:create", "Create patient intakes"),
    ("intake:list", "List patient intakes"),
    ("intake:read", "Read patient intake details"),
    ("intake:update", "Update patient intakes"),
    ("intake:cancel", "Cancel patient intakes"),
]

CLINIC_ADMIN_PERMISSIONS = [code for code, _description in INTAKE_PERMISSIONS]

ASSISTANT_PERMISSIONS = [
    "intake:create",
    "intake:list",
    "intake:read",
    "intake:update",
    "intake:cancel",
]

DOCTOR_PERMISSIONS = [
    "intake:list",
    "intake:read",
]


def upgrade() -> None:
    """Seed intake permissions and assign them to allowed roles."""

    for code, description in INTAKE_PERMISSIONS:
        op.execute(
            f"""
            INSERT INTO permissions (id, code, description)
            VALUES (gen_random_uuid(), '{code}', '{description}')
            ON CONFLICT (code) DO NOTHING
            """
        )

    role_permission_map = {
        "clinic_admin": CLINIC_ADMIN_PERMISSIONS,
        "assistant": ASSISTANT_PERMISSIONS,
        "doctor": DOCTOR_PERMISSIONS,
    }

    for role_name, permission_codes in role_permission_map.items():
        for code in permission_codes:
            op.execute(
                f"""
                INSERT INTO role_permissions (id, role_id, permission_id)
                SELECT gen_random_uuid(), r.id, p.id
                FROM roles r
                JOIN permissions p ON p.code = '{code}'
                WHERE r.name = '{role_name}'
                ON CONFLICT (role_id, permission_id) DO NOTHING
                """
            )


def downgrade() -> None:
    """Remove intake permissions and related role assignments."""

    permission_codes = "', '".join(code for code, _description in INTAKE_PERMISSIONS)

    op.execute(
        f"""
        DELETE FROM role_permissions
        WHERE permission_id IN (
            SELECT id FROM permissions
            WHERE code IN ('{permission_codes}')
        )
        """
    )

    op.execute(
        f"""
        DELETE FROM permissions
        WHERE code IN ('{permission_codes}')
        """
    )