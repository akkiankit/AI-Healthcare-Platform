"""seed_user_management_permision

Revision ID: ead5fcc283be
Revises: fc8f9fafc57b
Create Date: 2026-06-06 01:36:00.952289

"""
from typing import Sequence, Union

from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision: str = 'ead5fcc283be'
down_revision: Union[str, Sequence[str], None] = 'fc8f9fafc57b'
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None

USER_MANAGEMENT_PERMISSIONS = [
    ("user:create", "Create clinic users"),
    ("user:list", "List clinic users"),
    ("user:read", "Read clinic user details"),
    ("user:update", "Update clinic users"),
    ("user:deactivate", "Deactivate clinic users"),
    ("user:activate", "Activate clinic users"),
    ("user:reset_password", "Reset clinic user password"),
    ("user:assign_roles", "Assign roles to clinic users"),
]


def upgrade() -> None:
    """Seed user-management permissions and assign them to clinic_admin."""

    for code, description in USER_MANAGEMENT_PERMISSIONS:
        op.execute(
            f"""
            INSERT INTO permissions (id, code, description)
            VALUES (gen_random_uuid(), '{code}', '{description}')
            ON CONFLICT (code) DO NOTHING
            """
        )

    for code, _description in USER_MANAGEMENT_PERMISSIONS:
        op.execute(
            f"""
            INSERT INTO role_permissions (id, role_id, permission_id)
            SELECT gen_random_uuid(), r.id, p.id
            FROM roles r
            JOIN permissions p ON p.code = '{code}'
            WHERE r.name = 'clinic_admin'
            ON CONFLICT (role_id, permission_id) DO NOTHING
            """
        )


def downgrade() -> None:
    """Remove user-management permissions from clinic_admin."""

    permission_codes = "', '".join(code for code, _ in USER_MANAGEMENT_PERMISSIONS)

    op.execute(
        f"""
        DELETE FROM role_permissions
        WHERE permission_id IN (
            SELECT id FROM permissions
            WHERE code IN ('{permission_codes}')
        )
        """
    )

    op.execute(
        f"""
        DELETE FROM permissions
        WHERE code IN ('{permission_codes}')
        """
    )