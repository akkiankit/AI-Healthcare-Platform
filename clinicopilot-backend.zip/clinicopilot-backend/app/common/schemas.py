"""
Common API schemas.

This module contains reusable request/response schemas shared across multiple
backend modules to keep API contracts consistent and avoid duplication.
"""

from pydantic import BaseModel, Field, field_validator


class PaginationParams(BaseModel):
    """
    Common pagination request parameters.

    Used by list/search endpoints to enforce safe limits and predictable paging.
    """

    limit: int = Field(default=20, ge=1, le=100)
    offset: int = Field(default=0, ge=0)


class ApiMessageResponse(BaseModel):
    """
    Standard message response.

    Used for simple success responses such as delete confirmation, logout,
    password reset request accepted, or status update confirmation.
    """

    message: str = Field(..., min_length=1, max_length=500)

    @field_validator("message", mode="before")
    @classmethod
    def normalize_message(cls, value: str) -> str:
        """
        Trim response message text before serialization.
        """
        if not isinstance(value, str):
            raise ValueError("message must be a string")

        normalized_value = value.strip()

        if not normalized_value:
            raise ValueError("message cannot be empty")

        return normalized_value


class ErrorResponse(BaseModel):
    """
    Standard API error response.

    Used by exception handlers to return predictable error payloads to clients.
    """

    error_code: str = Field(..., min_length=2, max_length=100)
    message: str = Field(..., min_length=1, max_length=500)
    details: dict | list | str | None = None


class ValidationErrorItem(BaseModel):
    """
    Single validation error item.

    Useful for returning field-level validation errors in a frontend-friendly
    structure.
    """

    field: str
    message: str


class ValidationErrorResponse(BaseModel):
    """
    Standard validation error response.

    Used when request payload validation fails.
    """

    error_code: str = "VALIDATION_ERROR"
    message: str = "Request validation failed"
    errors: list[ValidationErrorItem]
