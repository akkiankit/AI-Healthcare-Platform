"""
FastAPI application entrypoint.

This file creates the FastAPI app instance and registers global routers,
middleware, and application-level configuration.
"""

from fastapi import FastAPI
import uvicorn
from app.db import base
from app.api.v1.router import api_v1_router

app = FastAPI(
    title="AI-Assisted Healthcare Consultation Platform",
    version="1.0.0",
    description="Backend API for patient registration and healthcare workflows.",
)

app.include_router(api_v1_router)


@app.get("/health", tags=["Health"])
async def health_check() -> dict[str, str]:
    """
    Lightweight health check endpoint.

    Used by local testing, deployment platforms, and monitoring tools.
    """
    return {"status": "ok"}


# # Run the application with Uvicorn if this file is executed directly
# if __name__ == "__main__":
#     import uvicorn

#     uvicorn.run(app, host="0.0.0", port=8000)
#     uvicorn app.main:app --reload  