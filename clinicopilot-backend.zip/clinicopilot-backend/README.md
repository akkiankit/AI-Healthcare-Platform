## SQLAlchemy Usage

This backend uses **SQLAlchemy** as the ORM layer for PostgreSQL.

SQLAlchemy helps us map Python classes to database tables so the application can work with Python objects instead of writing raw SQL everywhere.

### Why SQLAlchemy is used

- Provides a production-grade ORM for PostgreSQL.
- Keeps database access clean and maintainable.
- Maps tables such as `patients`, `users`, `consultations`, and `audit_logs` to Python classes.
- Supports relationships like:
  - one clinic has many patients
  - one patient has many intakes
  - one patient has many consultations
  - one consultation has many AI outputs
- Works well with FastAPI and async PostgreSQL drivers.
- Integrates with Alembic for database migrations.
- Reduces repeated raw SQL in service and repository layers.

### How it fits in the backend

```text
React Frontend
   ↓
FastAPI Router
   ↓
Service Layer
   ↓
Repository Layer
   ↓
SQLAlchemy ORM
   ↓
PostgreSQL Database
```

### Set database URL:
sqlalchemy.url = postgresql+asyncpg://username:password@localhost:5432/healthcare_db

Configure Alembic Metadata:
```Pythonfrom app.db.base_class import Base
target_metadata = Base.metadata
```

### Set database URL:
sqlalchemy.url = postgresql+asyncpg://username:password@localhost:5432/healthcare_db

Configure Alembic Metadata:
```Pythonfrom app.db.base_class import Base
target_metadata = Base.metadata

import sys
from pathlib import Path

sys.path.append(str(Path(__file__).resolve().parents[1]))
```
### Genrate / Migration:
```Linux
alembic revision --autogenerate -m "create core tables"
alembic upgrade head ## for migration
alembic current
```


### main.py is entry point
to start it: uvicorn app.main.app --reload

Router = HTTP
Service = Business rules
Repository = Database
Model = Table definition
Schema = API contract